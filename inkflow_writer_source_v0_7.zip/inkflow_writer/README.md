# 墨舟写作 InkFlow Writer v0.5

原创 Flutter 小说写作工具。v0.5 重点补齐「目标 App 类似的小说本地文件夹 + AI 创作台 + Skill 技能库 + 创作流程」。

## 主要功能

- 本地小说项目管理
- 每本小说自动创建「小说资料」和「章节内容」文件夹
- 默认资料：世界观、人物库、大纲、章节摘要、AI草稿
- Markdown 章节编辑、自动保存、字数统计
- AI 技能库和自定义技能
- AI 创作台，可绑定小说上下文
- 一键提炼章节到资料库
- 导入 TXT / MD / DOCX 为章节
- 导出 TXT / Markdown / Word DOCX
- 主题、字号、AI API Key、接口地址、模型名设置

## 运行方式

```bash
flutter create inkflow_writer_app --org com.maxlingg.inkflow --platforms=android
cp -R inkflow_writer/lib inkflow_writer_app/
cp inkflow_writer/pubspec.yaml inkflow_writer_app/pubspec.yaml
cp inkflow_writer/analysis_options.yaml inkflow_writer_app/analysis_options.yaml
cd inkflow_writer_app
flutter pub get
flutter run
```

## 打包 APK

```bash
flutter build apk --release
```

## 说明

本项目为原创 UI 和原创代码，未复制用户提供 APK 的源码、素材或图标。功能设计参考其公开可观察的功能结构，并重新实现为本地优先的小说创作工具。

## v0.6 新增

- 系统提示词管理：在「设置」里编辑 AI 助手的全局行为。
- Skill 管理：激活/停用 Skill，激活后自动注入系统提示词。
- Skill 导入：支持 JSON / Skill / Markdown / TXT / ZIP，以及目录批量导入。
- 自定义 Skill 支持核心提示词、工作流、输出格式。
