# 手机云端构建步骤

1. 删除仓库里的旧 `inkflow_writer_source_*.zip`。
2. 上传 `inkflow_writer_source_v0_5.zip`。
3. 打开 `.github/workflows/build-apk.yml`。
4. 用 `build-apk-v0.5.yml` 的内容替换旧内容。
5. Commit changes。
6. 打开 Actions，运行 Build Android APK。
7. 下载 artifact：`inkflow-writer-apk-v0-5`。
8. 解压后安装 `app-release.apk`。

## API 设置

进入 App 的「设置」页，填写：

- API Key
- 接口地址，例如 `https://api.openai.com/v1`
- 模型名，例如 `gpt-4o-mini`

未填写 API Key 时，AI 创作台和技能会返回本地模板，方便测试流程。
