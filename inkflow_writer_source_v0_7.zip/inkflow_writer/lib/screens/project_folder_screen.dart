import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../widgets/app_bottom_bar.dart';
import '../widgets/empty_state.dart';
import 'editor_screen.dart';
import 'note_editor_screen.dart';

enum ProjectFolderType { materials, chapters }

class ProjectFolderScreen extends StatefulWidget {
  const ProjectFolderScreen({
    super.key,
    required this.project,
    required this.type,
    required this.settings,
  });

  final WritingProject project;
  final ProjectFolderType type;
  final AppSettings settings;

  @override
  State<ProjectFolderScreen> createState() => _ProjectFolderScreenState();
}

class _ProjectFolderScreenState extends State<ProjectFolderScreen> {
  late WritingProject _project;

  bool get _isMaterials => widget.type == ProjectFolderType.materials;
  String get _title => _isMaterials ? '小说资料' : '章节内容';

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _refresh();
  }

  Future<void> _refresh() async {
    final projects = await StorageService.instance.loadProjects();
    final fresh = projects.where((item) => item.id == _project.id).toList();
    if (fresh.isEmpty || !mounted) return;
    setState(() => _project = fresh.first);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final itemCount = _isMaterials ? _project.notes.length : _project.chapters.length;

    return Scaffold(
      appBar: AppBar(
        leadingWidth: 72,
        leading: Padding(
          padding: const EdgeInsets.only(left: 18, top: 6, bottom: 6),
          child: IconButton.filledTonal(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        title: Text(_title),
        titleTextStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w900,
              color: colors.onSurface,
            ),
        actions: [
          IconButton.filledTonal(
            tooltip: _isMaterials ? '新建资料' : '新建章节',
            onPressed: _isMaterials ? _createMaterial : _createChapter,
            icon: const Icon(Icons.add_rounded),
          ),
          const SizedBox(width: 18),
        ],
      ),
      bottomNavigationBar: InkFlowBottomBar(settings: widget.settings),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: itemCount == 0
            ? ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.14),
                  EmptyState(
                    icon: _isMaterials ? Icons.description_rounded : Icons.edit_note_rounded,
                    title: _isMaterials ? '还没有资料文件' : '还没有章节文件',
                    message: _isMaterials
                        ? '世界观、人物库、大纲等都可以作为 Markdown 文件保存。'
                        : '每个章节都会保存成一个本地 Markdown 文件。',
                    action: FilledButton.icon(
                      onPressed: _isMaterials ? _createMaterial : _createChapter,
                      icon: const Icon(Icons.add_rounded),
                      label: Text(_isMaterials ? '新建资料' : '新建章节'),
                    ),
                  ),
                ],
              )
            : ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(24, 20, 18, 24),
                itemCount: itemCount,
                separatorBuilder: (_, __) => const SizedBox(height: 18),
                itemBuilder: (context, index) {
                  if (_isMaterials) {
                    final note = _project.notes[index];
                    return _DocumentRow(
                      title: _displayFileName(note.title),
                      onTap: () => _openMaterial(note),
                      menuItems: [
                        _DocMenuAction('rename', '重命名'),
                        _DocMenuAction('delete', '删除'),
                      ],
                      onMenuSelected: (value) {
                        if (value == 'rename') _renameMaterial(note);
                        if (value == 'delete') _deleteMaterial(note);
                      },
                    );
                  }

                  final chapter = _project.chapters[index];
                  return _DocumentRow(
                    title: _displayFileName(chapter.title),
                    onTap: () => _openChapter(chapter),
                    menuItems: [
                      if (index > 0) _DocMenuAction('up', '上移'),
                      if (index < _project.chapters.length - 1) _DocMenuAction('down', '下移'),
                      _DocMenuAction('rename', '重命名'),
                      _DocMenuAction('delete', '删除'),
                    ],
                    onMenuSelected: (value) {
                      if (value == 'up') _moveChapter(index, index - 1);
                      if (value == 'down') _moveChapter(index, index + 1);
                      if (value == 'rename') _renameChapter(chapter);
                      if (value == 'delete') _deleteChapter(chapter);
                    },
                  );
                },
              ),
      ),
      backgroundColor: colors.surfaceContainerLowest,
    );
  }

  Future<void> _openChapter(Chapter chapter) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => EditorScreen(
          project: _project,
          chapterId: chapter.id,
          settings: widget.settings,
        ),
      ),
    );
    await _refresh();
  }

  Future<void> _openMaterial(ProjectNote note) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => NoteEditorScreen(
          project: _project,
          noteId: note.id,
          settings: widget.settings,
        ),
      ),
    );
    await _refresh();
  }

  Future<void> _createChapter() async {
    final controller = TextEditingController(text: '第${_project.chapters.length + 1}章');
    final title = await _askForTitle('新建章节', '章节文件名', controller);
    if (title == null || title.isEmpty) return;

    final now = DateTime.now();
    final chapter = Chapter(
      id: newEntityId('chapter'),
      title: _stripMarkdownExtension(title),
      content: '',
      createdAt: now,
      updatedAt: now,
    );
    final next = _project.copyWith(chapters: [..._project.chapters, chapter], updatedAt: now);
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
    await _openChapter(chapter);
  }

  Future<void> _createMaterial() async {
    final controller = TextEditingController(text: '新资料');
    final title = await _askForTitle('新建资料', '资料文件名', controller);
    if (title == null || title.isEmpty) return;

    final now = DateTime.now();
    final note = ProjectNote(
      id: newEntityId('note'),
      title: _stripMarkdownExtension(title),
      body: '',
      tag: '资料',
      createdAt: now,
      updatedAt: now,
    );
    final next = _project.copyWith(notes: [..._project.notes, note], updatedAt: now);
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
    await _openMaterial(note);
  }

  Future<void> _renameChapter(Chapter chapter) async {
    final title = await _askForTitle(
      '重命名章节',
      '章节文件名',
      TextEditingController(text: chapter.title),
    );
    if (title == null || title.isEmpty) return;
    final chapters = _project.chapters
        .map((item) => item.id == chapter.id
            ? item.copyWith(title: _stripMarkdownExtension(title), updatedAt: DateTime.now())
            : item)
        .toList();
    final next = _project.copyWith(chapters: chapters, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
  }

  Future<void> _renameMaterial(ProjectNote note) async {
    final title = await _askForTitle(
      '重命名资料',
      '资料文件名',
      TextEditingController(text: note.title),
    );
    if (title == null || title.isEmpty) return;
    final notes = _project.notes
        .map((item) => item.id == note.id
            ? item.copyWith(title: _stripMarkdownExtension(title), updatedAt: DateTime.now())
            : item)
        .toList();
    final next = _project.copyWith(notes: notes, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
  }

  Future<void> _deleteChapter(Chapter chapter) async {
    final shouldDelete = await _confirmDelete('删除「${_displayFileName(chapter.title)}」？');
    if (!shouldDelete) return;
    final chapters = _project.chapters.where((item) => item.id != chapter.id).toList();
    final next = _project.copyWith(chapters: chapters, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
  }

  Future<void> _deleteMaterial(ProjectNote note) async {
    final shouldDelete = await _confirmDelete('删除「${_displayFileName(note.title)}」？');
    if (!shouldDelete) return;
    final notes = _project.notes.where((item) => item.id != note.id).toList();
    final next = _project.copyWith(notes: notes, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
  }

  Future<void> _moveChapter(int from, int to) async {
    final chapters = [..._project.chapters];
    if (from < 0 || from >= chapters.length || to < 0 || to >= chapters.length) return;
    final chapter = chapters.removeAt(from);
    chapters.insert(to, chapter);
    final next = _project.copyWith(chapters: chapters, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
  }

  Future<String?> _askForTitle(
    String title,
    String label,
    TextEditingController controller,
  ) async {
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: label),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(String title) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: const Text('本地 Markdown 文件也会从应用数据中移除。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton.tonal(onPressed: () => Navigator.pop(context, true), child: const Text('删除')),
        ],
      ),
    );
    return result == true;
  }

  String _displayFileName(String title) {
    final trimmed = title.trim();
    return trimmed.toLowerCase().endsWith('.md') ? trimmed : '$trimmed.md';
  }

  String _stripMarkdownExtension(String title) {
    final trimmed = title.trim();
    return trimmed.toLowerCase().endsWith('.md')
        ? trimmed.substring(0, trimmed.length - 3)
        : trimmed;
  }
}

class _DocMenuAction {
  const _DocMenuAction(this.value, this.label);

  final String value;
  final String label;
}

class _DocumentRow extends StatelessWidget {
  const _DocumentRow({
    required this.title,
    required this.onTap,
    required this.menuItems,
    required this.onMenuSelected,
  });

  final String title;
  final VoidCallback onTap;
  final List<_DocMenuAction> menuItems;
  final ValueChanged<String> onMenuSelected;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: colors.secondaryContainer.withOpacity(0.48),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(Icons.description_rounded, color: colors.secondary, size: 28),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                      color: colors.onSurface,
                    ),
              ),
            ),
            PopupMenuButton<String>(
              icon: Icon(Icons.more_vert_rounded, color: colors.onSurfaceVariant),
              onSelected: onMenuSelected,
              itemBuilder: (context) => menuItems
                  .map((item) => PopupMenuItem(value: item.value, child: Text(item.label)))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}
