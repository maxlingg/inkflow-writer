import 'package:flutter/material.dart';

import '../models/ai_skill.dart';

class SkillsScreen extends StatefulWidget {
  const SkillsScreen({super.key});

  @override
  State<SkillsScreen> createState() => _SkillsScreenState();
}

class _SkillsScreenState extends State<SkillsScreen> {
  List<AiSkill> _skills = const [];
  Set<String> _activeIds = const {};
  String _category = '全部';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final skills = await AiSkillStore.loadAllSkills();
    final activeIds = await AiSkillStore.loadActiveSkillIds();
    if (!mounted) return;
    setState(() {
      _skills = skills;
      _activeIds = activeIds;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _category == '全部'
        ? _skills
        : _skills.where((skill) => skill.category == _category).toList();
    final activeCount = _skills.where((skill) => _activeIds.contains(skill.id)).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 技能库'),
        actions: [
          IconButton(
            tooltip: '新建自定义技能',
            onPressed: () => _editCustomSkill(),
            icon: const Icon(Icons.add_circle_outline_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editCustomSkill(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('自定义 Skill'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: Text('激活 $activeCount / ${_skills.length} 个 Skill。激活项会自动注入系统提示词。'),
                ),
                SizedBox(
                  height: 54,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    itemCount: skillCategories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final category = skillCategories[index];
                      final count = category == '全部'
                          ? _skills.length
                          : _skills.where((item) => item.category == category).length;
                      return ChoiceChip(
                        selected: _category == category,
                        label: Text('$category $count'),
                        onSelected: (_) => setState(() => _category = category),
                      );
                    },
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final skill = filtered[index];
                      return _SkillCard(
                        skill: skill,
                        active: _activeIds.contains(skill.id),
                        onToggle: (active) async {
                          await AiSkillStore.setSkillActive(skill.id, active);
                          await _load();
                        },
                        onEdit: skill.isCustom ? () => _editCustomSkill(skill) : null,
                        onDelete: skill.isCustom ? () => _deleteCustomSkill(skill) : null,
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _editCustomSkill([AiSkill? skill]) async {
    final nameController = TextEditingController(text: skill?.name ?? '');
    final iconController = TextEditingController(text: skill?.icon ?? '✨');
    final descriptionController = TextEditingController(text: skill?.shortDescription ?? '');
    final promptController = TextEditingController(text: skill?.prompt ?? '');
    final workflowController = TextEditingController(text: skill?.workflow ?? '');
    final outputController = TextEditingController(text: skill?.outputFormat ?? '');
    String category = skill?.category == null || skill?.category == '全部' || !skillCategories.contains(skill!.category)
        ? '自定义'
        : skill!.category;

    final result = await showDialog<AiSkill>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: Text(skill == null ? '新建自定义 Skill' : '编辑自定义 Skill'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 76,
                        child: TextField(
                          controller: iconController,
                          decoration: const InputDecoration(labelText: '图标'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: nameController,
                          autofocus: true,
                          decoration: const InputDecoration(labelText: 'Skill 名'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: category,
                    decoration: const InputDecoration(labelText: '分类'),
                    items: skillCategories
                        .where((item) => item != '全部')
                        .map((item) => DropdownMenuItem(value: item, child: Text(item)))
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      setDialogState(() => category = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: descriptionController,
                    decoration: const InputDecoration(labelText: '一句话说明'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: promptController,
                    minLines: 5,
                    maxLines: 8,
                    decoration: const InputDecoration(
                      labelText: '核心提示词',
                      hintText: '写清楚这个技能要怎么处理文本、遵守什么规则……',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: workflowController,
                    minLines: 3,
                    maxLines: 6,
                    decoration: const InputDecoration(
                      labelText: '工作流，可不填',
                      hintText: '例如：先检查上下文 → 提取冲突 → 生成三个方案 → 推荐一个。',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: outputController,
                    minLines: 2,
                    maxLines: 5,
                    decoration: const InputDecoration(
                      labelText: '输出格式，可不填',
                      hintText: '例如：只输出正文；或按【问题】【建议】【改稿】输出。',
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: () {
                  final name = nameController.text.trim();
                  final prompt = promptController.text.trim();
                  if (name.isEmpty || prompt.isEmpty) return;
                  Navigator.pop(
                    context,
                    AiSkill(
                      id: skill?.id ?? '',
                      name: name,
                      icon: iconController.text.trim().isEmpty ? '✨' : iconController.text.trim(),
                      category: category,
                      shortDescription: descriptionController.text.trim().isEmpty
                          ? '自定义写作 Skill'
                          : descriptionController.text.trim(),
                      prompt: prompt,
                      workflow: workflowController.text.trim(),
                      outputFormat: outputController.text.trim(),
                      isCustom: true,
                    ),
                  );
                },
                child: const Text('保存并激活'),
              ),
            ],
          ),
        );
      },
    );

    if (result == null) return;
    await AiSkillStore.upsertCustomSkill(result, activate: true);
    await _load();
  }

  Future<void> _deleteCustomSkill(AiSkill skill) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${skill.name}」？'),
        content: const Text('只会删除你创建或导入的 Skill，不影响内置 Skill。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (shouldDelete != true) return;
    await AiSkillStore.deleteCustomSkill(skill.id);
    await _load();
  }
}

class _SkillCard extends StatelessWidget {
  const _SkillCard({
    required this.skill,
    required this.active,
    required this.onToggle,
    this.onEdit,
    this.onDelete,
  });

  final AiSkill skill;
  final bool active;
  final ValueChanged<bool> onToggle;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: active
          ? colors.primaryContainer.withOpacity(0.20)
          : colors.surfaceContainerHighest.withOpacity(0.42),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 38,
              height: 38,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: colors.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(skill.icon, style: const TextStyle(fontSize: 20)),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          skill.name,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                        ),
                      ),
                      _Badge(text: skill.isCustom ? '自定义' : '内置'),
                      if (active) ...[
                        const SizedBox(width: 6),
                        _Badge(text: '激活'),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${skill.category} · ${skill.shortDescription}',
                    style: TextStyle(color: colors.onSurfaceVariant),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    skill.prompt,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: colors.onSurfaceVariant,
                        ),
                  ),
                  if (skill.workflow.trim().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      '工作流：${skill.workflow}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.primary),
                    ),
                  ],
                ],
              ),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'toggle') onToggle(!active);
                if (value == 'edit') onEdit?.call();
                if (value == 'delete') onDelete?.call();
              },
              itemBuilder: (context) => [
                PopupMenuItem(value: 'toggle', child: Text(active ? '停用 Skill' : '激活 Skill')),
                if (onEdit != null) const PopupMenuItem(value: 'edit', child: Text('编辑')),
                if (onDelete != null) const PopupMenuItem(value: 'delete', child: Text('删除')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: colors.primaryContainer.withOpacity(0.75),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w800),
      ),
    );
  }
}
