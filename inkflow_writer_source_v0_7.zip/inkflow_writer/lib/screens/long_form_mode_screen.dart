import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import 'note_editor_screen.dart';

class LongFormModeScreen extends StatefulWidget {
  const LongFormModeScreen({
    super.key,
    required this.project,
    required this.settings,
  });

  final WritingProject project;
  final AppSettings settings;

  @override
  State<LongFormModeScreen> createState() => _LongFormModeScreenState();
}

class _LongFormModeScreenState extends State<LongFormModeScreen> {
  late WritingProject _project;
  String? _chapterId;
  final _instructionController = TextEditingController();
  bool _loading = false;
  String _status = '';
  String _output = '';
  int _batchCount = 3;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _chapterId = _project.chapters.isEmpty ? null : _project.chapters.first.id;
    _refresh();
  }

  @override
  void dispose() {
    _instructionController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    final projects = await StorageService.instance.loadProjects();
    final fresh = projects.where((item) => item.id == _project.id).toList();
    if (fresh.isEmpty || !mounted) return;
    setState(() {
      _project = fresh.first;
      if (_chapterId == null || !_project.chapters.any((item) => item.id == _chapterId)) {
        _chapterId = _project.chapters.isEmpty ? null : _project.chapters.first.id;
      }
    });
  }

  Chapter? get _selectedChapter {
    final id = _chapterId;
    if (id == null) return _project.chapters.isEmpty ? null : _project.chapters.first;
    return _project.chapters.where((item) => item.id == id).cast<Chapter?>().firstOrNull ??
        (_project.chapters.isEmpty ? null : _project.chapters.first);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          leadingWidth: 72,
          leading: Padding(
            padding: const EdgeInsets.only(left: 18, top: 6, bottom: 6),
            child: IconButton.filledTonal(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
          ),
          title: const Text('AI 长篇创作模式'),
          titleTextStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
                color: colors.onSurface,
              ),
          actions: [
            IconButton(
              tooltip: '刷新本地文件',
              onPressed: _loading ? null : _refresh,
              icon: const Icon(Icons.refresh_rounded),
            ),
            const SizedBox(width: 8),
          ],
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: '小说大脑'),
              Tab(text: '章节卡'),
              Tab(text: '归档质检'),
              Tab(text: '连续写作'),
            ],
          ),
        ),
        body: Column(
          children: [
            if (_loading || _status.isNotEmpty)
              Material(
                color: colors.primaryContainer.withOpacity(0.42),
                child: ListTile(
                  leading: _loading
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 3))
                      : const Icon(Icons.info_outline_rounded),
                  title: Text(_status.isEmpty ? '处理中…' : _status),
                  dense: true,
                ),
              ),
            Expanded(
              child: TabBarView(
                children: [
                  _buildBrainTab(),
                  _buildChapterCardTab(),
                  _buildArchiveTab(),
                  _buildBatchTab(),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: colors.surfaceContainerLowest,
      ),
    );
  }

  Widget _buildBrainTab() {
    final materialNames = const [
      '世界观',
      '人物库',
      '大纲',
      '章节摘要',
      '伏笔库',
      '时间线',
      '禁止改动设定',
      '文风模板',
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        _ActionCard(
          icon: Icons.psychology_rounded,
          title: '小说大脑',
          subtitle: '把长篇记忆拆成角色、世界、主线、伏笔、时间线、硬设定和文风模板。AI 写作时会优先读取这些内容。',
          primaryText: 'AI 补齐小说大脑',
          onPrimary: _loading ? null : _buildBrain,
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            Chip(label: Text('${_project.chapters.length} 章')),
            Chip(label: Text('${_project.notes.length} 份资料')),
            Chip(label: Text('${_project.totalCharacters} 字符')),
          ],
        ),
        const SizedBox(height: 14),
        ...materialNames.map((name) => _MaterialTile(
              name: name,
              note: _noteByTitle(name),
              onTap: () => _openMaterial(name),
            )),
        const SizedBox(height: 16),
        _OutputBox(text: _output, onCopy: _copyOutput),
      ],
    );
  }

  Widget _buildChapterCardTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        _ChapterPicker(
          project: _project,
          chapterId: _chapterId,
          onChanged: (id) => setState(() => _chapterId = id),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _instructionController,
          minLines: 2,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: '本章额外要求',
            hintText: '例如：本章要暴露身份、结尾留下地府通缉令、偏爽文节奏……',
          ),
        ),
        const SizedBox(height: 12),
        _ActionCard(
          icon: Icons.view_agenda_rounded,
          title: '章节卡片',
          subtitle: '先生成章节任务单，再写正文。字段包含本章目标、出场人物、核心冲突、爽点、关键场景和结尾钩子。',
          primaryText: '生成并保存章节卡',
          onPrimary: _loading ? null : _generateChapterCard,
        ),
        const SizedBox(height: 12),
        _ActionCard(
          icon: Icons.menu_book_rounded,
          title: '按章节卡写正文',
          subtitle: '读取「章节卡片.md」最后一次任务单，结合小说大脑生成当前章节正文。替换前会自动备份当前章节。',
          primaryText: '生成正文并写入本章',
          onPrimary: _loading ? null : _writeCurrentChapterFromLatestCard,
        ),
        const SizedBox(height: 16),
        _OutputBox(text: _output, onCopy: _copyOutput),
      ],
    );
  }

  Widget _buildArchiveTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        _ChapterPicker(
          project: _project,
          chapterId: _chapterId,
          onChanged: (id) => setState(() => _chapterId = id),
        ),
        const SizedBox(height: 12),
        _ActionCard(
          icon: Icons.inventory_2_rounded,
          title: '写完自动归档',
          subtitle: '写完一章后生成章节摘要、人物变化、新增设定、伏笔、时间线和下一章承接点，并保存到「章节摘要.md」。',
          primaryText: '总结并更新资料库',
          onPrimary: _loading ? null : _archiveSelectedChapter,
        ),
        const SizedBox(height: 12),
        _ActionCard(
          icon: Icons.rule_rounded,
          title: '长篇一致性检查',
          subtitle: '检查人物设定、时间线、能力规则、伏笔回收、章节节奏和文风漂移，保存到「长篇质检报告.md」。',
          primaryText: '开始一致性检查',
          onPrimary: _loading ? null : _consistencyCheck,
        ),
        const SizedBox(height: 16),
        _OutputBox(text: _output, onCopy: _copyOutput),
      ],
    );
  }

  Widget _buildBatchTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        _ActionCard(
          icon: Icons.all_inclusive_rounded,
          title: '连续写作模式',
          subtitle: '每一章都会执行：章节卡 → 正文 → 自动备份 → 章节摘要 → 更新日志。适合先小批量生成 1～3 章再人工审稿。',
          primaryText: '开始连续写作',
          onPrimary: _loading ? null : _runBatchWriting,
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          value: _batchCount,
          decoration: const InputDecoration(labelText: '连续生成章数'),
          items: const [1, 2, 3, 5]
              .map((count) => DropdownMenuItem(value: count, child: Text('$count 章')))
              .toList(),
          onChanged: _loading ? null : (value) => setState(() => _batchCount = value ?? 3),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _instructionController,
          minLines: 3,
          maxLines: 5,
          decoration: const InputDecoration(
            labelText: '连续写作要求',
            hintText: '例如：围绕主角第一次被地府通缉展开，每章 2500 字，轻松悬疑爽文风……',
          ),
        ),
        const SizedBox(height: 12),
        _WarningCard(
          text: '建议第一次只生成 1 章测试。连续写作会修改章节内容，但每次写入前都会保存版本历史。',
        ),
        const SizedBox(height: 16),
        _OutputBox(text: _output, onCopy: _copyOutput),
      ],
    );
  }

  Future<void> _buildBrain() async {
    await _runWithStatus('正在补齐小说大脑…', () async {
      final text = await AiService.instance.runLongFormTask(
        settings: widget.settings,
        project: _project,
        taskName: '补齐小说大脑',
        instruction: _instructionController.text,
        maxTokens: 3600,
      );
      _project = await StorageService.instance.appendMaterial(
        project: _project,
        title: 'AI草稿',
        content: '\n\n## 小说大脑补全建议 ${DateTime.now().toIso8601String()}\n\n$text',
        tag: 'AI草稿',
      );
      _output = text;
      _status = '已生成，并保存到 AI草稿.md。请人工确认后再粘贴到对应资料文件。';
    });
  }

  Future<void> _generateChapterCard() async {
    final chapter = _selectedChapter;
    if (chapter == null) return;
    await _runWithStatus('正在生成章节卡…', () async {
      final text = await AiService.instance.runLongFormTask(
        settings: widget.settings,
        project: _project,
        chapter: chapter,
        taskName: '生成章节卡',
        instruction: _instructionController.text,
        maxTokens: 2600,
      );
      _project = await StorageService.instance.appendMaterial(
        project: _project,
        title: '章节卡片',
        content: '\n\n---\n\n## ${chapter.title}｜${DateTime.now().toIso8601String()}\n\n$text',
        tag: '章节卡',
      );
      _output = text;
      _status = '章节卡已保存到 小说资料/章节卡片.md';
    });
  }

  Future<void> _writeCurrentChapterFromLatestCard() async {
    final chapter = _selectedChapter;
    if (chapter == null) return;
    final card = _noteByTitle('章节卡片')?.body ?? '';
    await _runWithStatus('正在根据章节卡生成正文…', () async {
      final text = await AiService.instance.runLongFormTask(
        settings: widget.settings,
        project: _project,
        chapter: chapter,
        taskName: '根据章节卡写正文',
        instruction: _instructionController.text,
        draftCard: card,
        maxTokens: 5200,
      );
      final nextChapter = chapter.copyWith(content: text, updatedAt: DateTime.now());
      _project = await StorageService.instance.upsertChapter(
        project: _project,
        chapter: nextChapter,
        backupReason: 'AI写正文前备份',
      );
      _chapterId = nextChapter.id;
      _output = text;
      _status = '正文已写入「${chapter.title}」，旧版本已备份。';
    });
  }

  Future<void> _archiveSelectedChapter() async {
    final chapter = _selectedChapter;
    if (chapter == null) return;
    await _runWithStatus('正在总结并归档…', () async {
      final text = await AiService.instance.runLongFormTask(
        settings: widget.settings,
        project: _project,
        chapter: chapter,
        taskName: '写完自动总结归档',
        instruction: _instructionController.text,
        maxTokens: 2800,
      );
      _project = await StorageService.instance.appendMaterial(
        project: _project,
        title: '章节摘要',
        content: '\n\n## ${chapter.title}｜${DateTime.now().toIso8601String()}\n\n$text',
        tag: 'AI归档',
      );
      _output = text;
      _status = '已追加到 小说资料/章节摘要.md';
    });
  }

  Future<void> _consistencyCheck() async {
    await _runWithStatus('正在做长篇一致性检查…', () async {
      final text = await AiService.instance.runLongFormTask(
        settings: widget.settings,
        project: _project,
        taskName: '长篇一致性质检',
        instruction: _instructionController.text,
        maxTokens: 3600,
      );
      _project = await StorageService.instance.appendMaterial(
        project: _project,
        title: '长篇质检报告',
        content: '\n\n## 质检报告 ${DateTime.now().toIso8601String()}\n\n$text',
        tag: '质检',
      );
      _output = text;
      _status = '质检报告已保存到 小说资料/长篇质检报告.md';
    });
  }

  Future<void> _runBatchWriting() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('开始连续写作？'),
        content: Text('将连续生成 $_batchCount 章。每章会自动生成章节卡、正文和章节摘要，并在写入前备份旧版本。建议先生成 1 章测试。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('开始')),
        ],
      ),
    );
    if (confirmed != true) return;

    await _runWithStatus('准备连续写作…', () async {
      final log = StringBuffer();
      var working = _project;
      for (var i = 0; i < _batchCount; i++) {
        final chapterNo = working.chapters.length + 1;
        final now = DateTime.now();
        final chapter = Chapter(
          id: newEntityId('chapter'),
          title: '第$chapterNo章',
          content: '',
          createdAt: now,
          updatedAt: now,
        );

        setState(() => _status = '第 ${i + 1}/$_batchCount 章：生成章节卡…');
        final card = await AiService.instance.runLongFormTask(
          settings: widget.settings,
          project: working,
          chapter: chapter,
          taskName: '生成章节卡',
          instruction: _instructionController.text,
          maxTokens: 2200,
        );

        setState(() => _status = '第 ${i + 1}/$_batchCount 章：写正文…');
        final draft = await AiService.instance.runLongFormTask(
          settings: widget.settings,
          project: working,
          chapter: chapter,
          taskName: '根据章节卡写正文',
          instruction: _instructionController.text,
          draftCard: card,
          maxTokens: 5200,
        );

        final written = chapter.copyWith(content: draft, updatedAt: DateTime.now());
        working = await StorageService.instance.upsertChapter(
          project: working,
          chapter: written,
          backupReason: '连续写作写入前备份',
        );

        setState(() => _status = '第 ${i + 1}/$_batchCount 章：总结归档…');
        final summary = await AiService.instance.runLongFormTask(
          settings: widget.settings,
          project: working,
          chapter: written,
          taskName: '写完自动总结归档',
          instruction: '连续写作自动归档，请输出简洁、可追加到资料库的内容。',
          maxTokens: 2200,
        );

        working = await StorageService.instance.appendMaterial(
          project: working,
          title: '章节卡片',
          content: '\n\n---\n\n## ${written.title}｜${DateTime.now().toIso8601String()}\n\n$card',
          tag: '章节卡',
        );
        working = await StorageService.instance.appendMaterial(
          project: working,
          title: '章节摘要',
          content: '\n\n## ${written.title}｜${DateTime.now().toIso8601String()}\n\n$summary',
          tag: 'AI归档',
        );
        log.writeln('- ${written.title}：已生成章节卡、正文和摘要。');
        _output = '${log.toString()}\n\n最后一章正文预览：\n\n${draft.substring(0, draft.length.clamp(0, 1200).toInt())}';
      }

      working = await StorageService.instance.appendMaterial(
        project: working,
        title: '连续写作日志',
        content: '\n\n## ${DateTime.now().toIso8601String()}\n\n${log.toString()}',
        tag: '连续写作',
      );

      _project = working;
      _chapterId = working.chapters.isEmpty ? null : working.chapters.last.id;
      _status = '连续写作完成：已生成 $_batchCount 章。';
    });
  }

  Future<void> _runWithStatus(String status, Future<void> Function() action) async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _status = status;
      _output = '';
    });
    try {
      await action();
      await _refresh();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _status = '失败：$error';
        _output = error.toString();
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  ProjectNote? _noteByTitle(String title) {
    final target = title.trim();
    for (final note in _project.notes) {
      if (note.title == target) return note;
    }
    return null;
  }

  Future<void> _openMaterial(String title) async {
    final note = _noteByTitle(title);
    if (note == null) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => NoteEditorScreen(project: _project, noteId: note.id, settings: widget.settings)),
    );
    await _refresh();
  }

  Future<void> _copyOutput() async {
    if (_output.trim().isEmpty) return;
    await Clipboard.setData(ClipboardData(text: _output));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制')));
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.primaryText,
    required this.onPrimary,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String primaryText;
  final VoidCallback? onPrimary;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: colors.surface,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              CircleAvatar(
                backgroundColor: colors.primaryContainer,
                foregroundColor: colors.primary,
                child: Icon(icon),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
              ),
            ]),
            const SizedBox(height: 10),
            Text(subtitle, style: TextStyle(color: colors.onSurfaceVariant, height: 1.55)),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: onPrimary,
                icon: const Icon(Icons.auto_awesome_rounded),
                label: Text(primaryText),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChapterPicker extends StatelessWidget {
  const _ChapterPicker({
    required this.project,
    required this.chapterId,
    required this.onChanged,
  });

  final WritingProject project;
  final String? chapterId;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: project.chapters.any((item) => item.id == chapterId) ? chapterId : (project.chapters.isEmpty ? null : project.chapters.first.id),
      decoration: const InputDecoration(labelText: '当前章节'),
      items: project.chapters
          .map((chapter) => DropdownMenuItem(value: chapter.id, child: Text(chapter.title)))
          .toList(),
      onChanged: onChanged,
    );
  }
}

class _MaterialTile extends StatelessWidget {
  const _MaterialTile({
    required this.name,
    required this.note,
    required this.onTap,
  });

  final String name;
  final ProjectNote? note;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final body = note?.body.trim() ?? '';
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      leading: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: colors.primaryContainer.withOpacity(0.55),
          borderRadius: BorderRadius.circular(13),
        ),
        child: Icon(Icons.description_rounded, color: colors.primary),
      ),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text(body.isEmpty ? '空文件' : '${body.length} 字符'),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: onTap,
    );
  }
}

class _OutputBox extends StatelessWidget {
  const _OutputBox({required this.text, required this.onCopy});

  final String text;
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) {
      return const SizedBox.shrink();
    }
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest.withOpacity(0.55),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('输出结果', style: TextStyle(fontWeight: FontWeight.w900))),
              IconButton(onPressed: onCopy, icon: const Icon(Icons.copy_rounded), tooltip: '复制'),
            ],
          ),
          SelectableText(text, style: const TextStyle(height: 1.6)),
        ],
      ),
    );
  }
}

class _WarningCard extends StatelessWidget {
  const _WarningCard({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colors.errorContainer.withOpacity(0.45),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.warning_amber_rounded, color: colors.error),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: TextStyle(color: colors.onErrorContainer, height: 1.45))),
        ],
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
