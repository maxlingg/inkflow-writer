import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/storage_service.dart';

class VersionHistoryScreen extends StatefulWidget {
  const VersionHistoryScreen({
    super.key,
    required this.project,
    required this.chapter,
  });

  final WritingProject project;
  final Chapter chapter;

  @override
  State<VersionHistoryScreen> createState() => _VersionHistoryScreenState();
}

class _VersionHistoryScreenState extends State<VersionHistoryScreen> {
  bool _loading = true;
  List<ChapterBackup> _backups = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final backups = await StorageService.instance.loadChapterBackups(
      project: widget.project,
      chapter: widget.chapter,
    );
    if (!mounted) return;
    setState(() {
      _backups = backups;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('版本历史｜${widget.chapter.title}'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _backups.isEmpty
              ? const Center(child: Text('还没有版本备份。AI 替换正文或手动备份后会出现在这里。'))
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _backups.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final backup = _backups[index];
                    return Card(
                      color: colors.surface,
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: colors.primaryContainer,
                          foregroundColor: colors.primary,
                          child: const Icon(Icons.history_rounded),
                        ),
                        title: Text(backup.reason, style: const TextStyle(fontWeight: FontWeight.w900)),
                        subtitle: Text('${backup.createdAt}\n${backup.title}'),
                        isThreeLine: true,
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () => _openBackup(backup),
                      ),
                    );
                  },
                ),
      backgroundColor: colors.surfaceContainerLowest,
    );
  }

  Future<void> _openBackup(ChapterBackup backup) async {
    final text = await StorageService.instance.readBackup(backup.path);
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.82,
          child: Column(
            children: [
              ListTile(
                title: Text(backup.reason, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(backup.title),
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.45),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: SingleChildScrollView(
                    child: SelectableText(text, style: const TextStyle(height: 1.65)),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: FilledButton.tonal(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('关闭'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.pop(context, text);
                        },
                        child: const Text('恢复此版本'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
