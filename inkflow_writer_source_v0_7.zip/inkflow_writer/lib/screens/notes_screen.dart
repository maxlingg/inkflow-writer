import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/storage_service.dart';
import '../widgets/empty_state.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key, required this.project});

  final WritingProject project;

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  late WritingProject _project;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设定备忘')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editNote(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('新备忘'),
      ),
      body: _project.notes.isEmpty
          ? EmptyState(
              icon: Icons.lightbulb_rounded,
              title: '收集故事零件',
              message: '人物、地点、世界观、伏笔都可以先记在这里。',
              action: FilledButton.icon(
                onPressed: () => _editNote(),
                icon: const Icon(Icons.add_rounded),
                label: const Text('添加备忘'),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
              itemCount: _project.notes.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final note = _project.notes[index];
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    leading: const Icon(Icons.sticky_note_2_rounded),
                    title: Text(
                      note.title,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 6),
                        Text(note.body, maxLines: 3, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 8),
                        Chip(label: Text(note.tag)),
                      ],
                    ),
                    onTap: () => _editNote(note),
                    trailing: IconButton(
                      tooltip: '删除',
                      icon: const Icon(Icons.delete_outline_rounded),
                      onPressed: () => _deleteNote(note),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Future<void> _editNote([ProjectNote? note]) async {
    final titleController = TextEditingController(text: note?.title ?? '');
    final bodyController = TextEditingController(text: note?.body ?? '');
    final tagController = TextEditingController(text: note?.tag ?? '灵感');

    final result = await showDialog<ProjectNote>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(note == null ? '新建备忘' : '编辑备忘'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                autofocus: true,
                decoration: const InputDecoration(labelText: '标题'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: tagController,
                decoration: const InputDecoration(labelText: '标签'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bodyController,
                minLines: 5,
                maxLines: 8,
                decoration: const InputDecoration(labelText: '内容'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () {
              final now = DateTime.now();
              final title = titleController.text.trim();
              if (title.isEmpty) return;
              Navigator.pop(
                context,
                ProjectNote(
                  id: note?.id ?? newEntityId('note'),
                  title: title,
                  body: bodyController.text.trim(),
                  tag: tagController.text.trim().isEmpty ? '灵感' : tagController.text.trim(),
                  createdAt: note?.createdAt ?? now,
                  updatedAt: now,
                ),
              );
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );

    if (result == null) return;
    final notes = [..._project.notes];
    final index = notes.indexWhere((item) => item.id == result.id);
    if (index == -1) {
      notes.add(result);
    } else {
      notes[index] = result;
    }
    await _saveNotes(notes);
  }

  Future<void> _deleteNote(ProjectNote note) async {
    final notes = _project.notes.where((item) => item.id != note.id).toList();
    await _saveNotes(notes);
  }

  Future<void> _saveNotes(List<ProjectNote> notes) async {
    final next = _project.copyWith(notes: notes, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);
  }
}
