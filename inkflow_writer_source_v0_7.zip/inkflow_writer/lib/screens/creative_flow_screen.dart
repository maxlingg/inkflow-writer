import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import 'chat_screen.dart';
import 'project_folder_screen.dart';

class CreativeFlowScreen extends StatefulWidget {
  const CreativeFlowScreen({super.key, required this.project, required this.settings});

  final WritingProject project;
  final AppSettings settings;

  @override
  State<CreativeFlowScreen> createState() => _CreativeFlowScreenState();
}

class _CreativeFlowScreenState extends State<CreativeFlowScreen> {
  late WritingProject _project;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _refresh();
  }

  Future<void> _refresh() async {
    final projects = await StorageService.instance.loadProjects();
    final matches = projects.where((item) => item.id == _project.id).toList();
    if (matches.isEmpty || !mounted) return;
    setState(() => _project = matches.first);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final steps = [
      _FlowStep(
        number: 1,
        title: '建项目与资料库',
        subtitle: '创建小说文件夹，默认生成世界观、人物库、大纲、章节摘要、AI草稿。',
        icon: Icons.create_new_folder_rounded,
        done: _project.notes.length >= 4,
        actionText: '打开资料',
        onTap: () => _openFolder(ProjectFolderType.materials),
      ),
      _FlowStep(
        number: 2,
        title: '补世界观与人物',
        subtitle: '先写规则、限制、角色目标、秘密和人物关系，避免越写越散。',
        icon: Icons.public_rounded,
        done: _nonEmptyNote('世界观') || _nonEmptyNote('人物库'),
        actionText: '编辑资料',
        onTap: () => _openFolder(ProjectFolderType.materials),
      ),
      _FlowStep(
        number: 3,
        title: '做主线大纲',
        subtitle: '确定主线目标、阶段目标、反转点、爽点和结局方向。',
        icon: Icons.account_tree_rounded,
        done: _nonEmptyNote('大纲'),
        actionText: 'AI 拆大纲',
        onTap: _openChat,
      ),
      _FlowStep(
        number: 4,
        title: '拆章与写正文',
        subtitle: '章节内容保存为 Markdown 文件；每章可自动保存、拆分、续写和润色。',
        icon: Icons.article_rounded,
        done: _project.chapters.any((item) => item.content.trim().isNotEmpty),
        actionText: '打开章节',
        onTap: () => _openFolder(ProjectFolderType.chapters),
      ),
      _FlowStep(
        number: 5,
        title: '提炼与归档',
        subtitle: '写完一章后，把剧情摘要、人物变化、伏笔和设定沉淀回资料库。',
        icon: Icons.move_to_inbox_rounded,
        done: _nonEmptyNote('章节摘要'),
        actionText: '资料入库',
        onTap: () => _openFolder(ProjectFolderType.materials),
      ),
      _FlowStep(
        number: 6,
        title: '导出与备份',
        subtitle: '支持 TXT、Markdown、Word DOCX 导出；原始章节仍保留本地文件夹。',
        icon: Icons.ios_share_rounded,
        done: false,
        actionText: '返回导出',
        onTap: () => Navigator.pop(context),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('创作流程')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            Card(
              color: colors.primaryContainer.withOpacity(0.55),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('《${_project.title}》工作流', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Text('参考目标 App 的“AI + 本地文件 + 技能库”思路，但保留原创 UI 和原创实现。', style: TextStyle(color: colors.onPrimaryContainer)),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        Chip(label: Text('${_project.chapters.length} 章')),
                        Chip(label: Text('${_project.notes.length} 份资料')),
                        Chip(label: Text('${_project.totalCharacters} 字符')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            for (final step in steps) ...[
              _StepCard(step: step),
              const SizedBox(height: 10),
            ],
          ],
        ),
      ),
    );
  }

  bool _nonEmptyNote(String title) {
    final note = _project.notes.where((item) => item.title == title).toList();
    if (note.isEmpty) return false;
    final plain = note.first.body.replaceAll(RegExp(r'[#\s\-｜|:：]'), '');
    if (title == '世界观') return plain.length > 12;
    if (title == '人物库') return plain.length > 12;
    if (title == '大纲') return plain.length > 12;
    if (title == '章节摘要') return plain.length > 30;
    return plain.isNotEmpty;
  }

  Future<void> _openFolder(ProjectFolderType type) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProjectFolderScreen(project: _project, type: type, settings: widget.settings)));
    await _refresh();
  }

  Future<void> _openChat() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(settings: widget.settings, initialProject: _project)));
    await _refresh();
  }
}

class _FlowStep {
  const _FlowStep({
    required this.number,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.done,
    required this.actionText,
    required this.onTap,
  });

  final int number;
  final String title;
  final String subtitle;
  final IconData icon;
  final bool done;
  final String actionText;
  final VoidCallback onTap;
}

class _StepCard extends StatelessWidget {
  const _StepCard({required this.step});

  final _FlowStep step;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.fromLTRB(14, 10, 12, 10),
        leading: CircleAvatar(
          backgroundColor: step.done ? colors.primary : colors.surfaceContainerHighest,
          foregroundColor: step.done ? colors.onPrimary : colors.primary,
          child: step.done ? const Icon(Icons.check_rounded) : Text('${step.number}'),
        ),
        title: Text(step.title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(step.subtitle),
        ),
        trailing: FilledButton.tonal(onPressed: step.onTap, child: Text(step.actionText)),
      ),
    );
  }
}
