import 'package:flutter/material.dart';

import '../screens/chat_screen.dart';
import '../screens/settings_screen.dart';
import '../services/app_settings.dart';

class InkFlowBottomBar extends StatelessWidget {
  const InkFlowBottomBar({
    super.key,
    required this.settings,
    this.selectedIndex = 1,
  });

  final AppSettings settings;
  final int selectedIndex;

  @override
  Widget build(BuildContext context) {
    return NavigationBar(
      selectedIndex: selectedIndex,
      height: 72,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      onDestinationSelected: (index) async {
        if (index == selectedIndex) return;
        if (index == 0) {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => ChatScreen(settings: settings)),
          );
        } else if (index == 1) {
          Navigator.of(context).popUntil((route) => route.isFirst);
        } else if (index == 2) {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => SettingsScreen(settings: settings)),
          );
        }
      },
      destinations: const [
        NavigationDestination(
          selectedIcon: Icon(Icons.chat_bubble_rounded),
          icon: Icon(Icons.chat_bubble_outline_rounded),
          label: 'AI',
        ),
        NavigationDestination(
          selectedIcon: Icon(Icons.auto_stories_rounded),
          icon: Icon(Icons.auto_stories_outlined),
          label: '小说',
        ),
        NavigationDestination(
          selectedIcon: Icon(Icons.settings_rounded),
          icon: Icon(Icons.settings_outlined),
          label: '设置',
        ),
      ],
    );
  }
}
