class TextStats {
  const TextStats._();

  static int characters(String text) {
    return text.trim().replaceAll(RegExp(r'\s+'), '').length;
  }

  static int words(String text) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return 0;

    final latinWords = RegExp(r'[A-Za-z0-9_]+').allMatches(trimmed).length;
    final cjkChars = RegExp(r'[\u4e00-\u9fff]').allMatches(trimmed).length;
    return latinWords + cjkChars;
  }

  static String readingTimeLabel(String text) {
    final count = words(text);
    final minutes = (count / 450).ceil().clamp(1, 9999);
    return '约 $minutes 分钟阅读';
  }
}
