import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/chat_session.dart';

class ChatSessionStore {
  ChatSessionStore._();

  static const _key = 'chatSessionsV1';

  static Future<List<ChatSession>> loadSessions() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.trim().isEmpty) return [];
    try {
      final decoded = jsonDecode(raw) as List;
      final sessions = decoded
          .whereType<Map>()
          .map((item) => ChatSession.fromJson(Map<String, dynamic>.from(item)))
          .toList();
      sessions.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return sessions;
    } on FormatException {
      await prefs.remove(_key);
      return [];
    }
  }

  static Future<void> saveSessions(List<ChatSession> sessions) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(sessions.map((item) => item.toJson()).toList()));
  }

  static Future<void> upsert(ChatSession session) async {
    final sessions = await loadSessions();
    final index = sessions.indexWhere((item) => item.id == session.id);
    if (index == -1) {
      sessions.insert(0, session);
    } else {
      sessions[index] = session;
    }
    await saveSessions(sessions);
  }

  static Future<void> delete(String id) async {
    final sessions = await loadSessions();
    sessions.removeWhere((item) => item.id == id);
    await saveSessions(sessions);
  }
}
