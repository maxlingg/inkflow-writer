import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';

import '../models/writing_project.dart';

class DocxExportService {
  DocxExportService._();

  static Future<String> exportProject(WritingProject project, String outputPath) async {
    final archive = Archive();

    void addTextFile(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    addTextFile('[Content_Types].xml', _contentTypesXml);
    addTextFile('_rels/.rels', _relsXml);
    addTextFile('word/_rels/document.xml.rels', _documentRelsXml);
    addTextFile('word/styles.xml', _stylesXml);
    addTextFile('word/document.xml', _documentXml(project));

    final bytes = ZipEncoder().encode(archive);
    if (bytes == null) {
      throw const FileSystemException('DOCX 打包失败');
    }

    final file = File(outputPath);
    if (!await file.parent.exists()) await file.parent.create(recursive: true);
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  static Future<String> readDocxText(String inputPath) async {
    final bytes = await File(inputPath).readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final document = archive.files.where((file) => file.name == 'word/document.xml').toList();
    if (document.isEmpty) return '';
    final xml = utf8.decode(document.first.content as List<int>, allowMalformed: true);
    final parts = <String>[];
    final reg = RegExp(r'<w:t[^>]*>(.*?)</w:t>|<w:br\s*/>|</w:p>', dotAll: true);
    for (final match in reg.allMatches(xml)) {
      final value = match.group(1);
      if (value != null) {
        parts.add(_unescapeXml(value));
      } else {
        parts.add('\n');
      }
    }
    return parts.join().replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
  }

  static String _documentXml(WritingProject project) {
    final body = StringBuffer();
    body.writeln(_paragraph(project.title, style: 'Title'));
    if (project.description.trim().isNotEmpty) {
      body.writeln(_paragraph(project.description.trim()));
    }
    body.writeln(_paragraph(''));

    for (final chapter in project.chapters) {
      body.writeln(_paragraph(chapter.title, style: 'Heading1'));
      for (final paragraph in _paragraphs(chapter.content)) {
        body.writeln(_paragraph(paragraph));
      }
      body.writeln(_paragraph(''));
    }

    if (project.notes.isNotEmpty) {
      body.writeln(_paragraph('小说资料', style: 'Heading1'));
      for (final note in project.notes) {
        body.writeln(_paragraph(note.title, style: 'Heading2'));
        for (final paragraph in _paragraphs(note.body)) {
          body.writeln(_paragraph(paragraph));
        }
      }
    }

    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    $body
    <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>
  </w:body>
</w:document>''';
  }

  static Iterable<String> _paragraphs(String text) sync* {
    final normalized = text.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    for (final part in normalized.split('\n')) {
      yield part;
    }
  }

  static String _paragraph(String text, {String? style}) {
    final styleXml = style == null ? '' : '<w:pPr><w:pStyle w:val="$style"/></w:pPr>';
    return '<w:p>$styleXml<w:r><w:t xml:space="preserve">${_escapeXml(text)}</w:t></w:r></w:p>';
  }

  static String _escapeXml(String value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&apos;');
  }

  static String _unescapeXml(String value) {
    return value
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&amp;', '&');
  }

  static const _contentTypesXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>''';

  static const _relsXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''';

  static const _documentRelsXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>''';

  static const _stylesXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:sz w:val="24"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:rPr><w:b/><w:sz w:val="44"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="Heading 1"/><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="Heading 2"/><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>
</w:styles>''';
}
