import 'dart:math';

String newEntityId(String prefix) {
  final time = DateTime.now().microsecondsSinceEpoch;
  final suffix = Random().nextInt(1 << 32).toRadixString(16);
  return '$prefix-$time-$suffix';
}

class WritingProject {
  const WritingProject({
    required this.id,
    required this.title,
    required this.description,
    required this.genre,
    required this.createdAt,
    required this.updatedAt,
    required this.chapters,
    required this.notes,
  });

  final String id;
  final String title;
  final String description;
  final String genre;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<Chapter> chapters;
  final List<ProjectNote> notes;

  int get totalCharacters => chapters.fold<int>(
        0,
        (value, chapter) => value + chapter.content.trim().length,
      );

  int get totalChapters => chapters.length;

  WritingProject copyWith({
    String? title,
    String? description,
    String? genre,
    DateTime? updatedAt,
    List<Chapter>? chapters,
    List<ProjectNote>? notes,
  }) {
    return WritingProject(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      genre: genre ?? this.genre,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      chapters: chapters ?? this.chapters,
      notes: notes ?? this.notes,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'genre': genre,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'chapters': chapters.map((chapter) => chapter.toJson()).toList(),
      'notes': notes.map((note) => note.toJson()).toList(),
    };
  }

  factory WritingProject.fromJson(Map<String, dynamic> json) {
    return WritingProject(
      id: json['id'] as String? ?? newEntityId('project'),
      title: json['title'] as String? ?? '未命名作品',
      description: json['description'] as String? ?? '',
      genre: json['genre'] as String? ?? '原创',
      createdAt: _parseDate(json['createdAt']),
      updatedAt: _parseDate(json['updatedAt']),
      chapters: ((json['chapters'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => Chapter.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      notes: ((json['notes'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => ProjectNote.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
    );
  }
}

class Chapter {
  const Chapter({
    required this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String title;
  final String content;
  final DateTime createdAt;
  final DateTime updatedAt;

  Chapter copyWith({
    String? title,
    String? content,
    DateTime? updatedAt,
  }) {
    return Chapter(
      id: id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      id: json['id'] as String? ?? newEntityId('chapter'),
      title: json['title'] as String? ?? '未命名章节',
      content: json['content'] as String? ?? '',
      createdAt: _parseDate(json['createdAt']),
      updatedAt: _parseDate(json['updatedAt']),
    );
  }
}

class ProjectNote {
  const ProjectNote({
    required this.id,
    required this.title,
    required this.body,
    required this.tag,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String title;
  final String body;
  final String tag;
  final DateTime createdAt;
  final DateTime updatedAt;

  ProjectNote copyWith({
    String? title,
    String? body,
    String? tag,
    DateTime? updatedAt,
  }) {
    return ProjectNote(
      id: id,
      title: title ?? this.title,
      body: body ?? this.body,
      tag: tag ?? this.tag,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'body': body,
      'tag': tag,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory ProjectNote.fromJson(Map<String, dynamic> json) {
    return ProjectNote(
      id: json['id'] as String? ?? newEntityId('note'),
      title: json['title'] as String? ?? '未命名笔记',
      body: json['body'] as String? ?? '',
      tag: json['tag'] as String? ?? '灵感',
      createdAt: _parseDate(json['createdAt']),
      updatedAt: _parseDate(json['updatedAt']),
    );
  }
}

DateTime _parseDate(Object? value) {
  if (value is String) {
    return DateTime.tryParse(value) ?? DateTime.now();
  }
  return DateTime.now();
}
