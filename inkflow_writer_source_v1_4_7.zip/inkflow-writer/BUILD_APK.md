# InkFlow 写作应用 - APK 打包指南

版本：v1.4.7

---

## 🚀 方式一：GitHub Actions 自动构建（推荐）

### 步骤

1. **推送到 GitHub**
   ```bash
   git add .
   git commit -m "v1.4.7 更新"
   git push
   ```

2. **触发构建**
   - 前往仓库的 GitHub 页面
   - 点击 **Actions** 标签页
   - 选择 **Build Android APK** 工作流
   - 点击 **Run workflow** → 选择分支 → 点击绿色按钮
   - 等待 5-10 分钟

3. **下载 APK**
   - 构建完成后，在工作流详情页面底部
   - 找到 **Artifacts** 区域
   - 点击 `inkflow-writer-apk-v1-4-7` 下载

---

## 💻 方式二：本地构建

### 前置要求
- 已安装 Flutter SDK (>=3.5.0)
- 已安装 Android SDK

### 快速开始

```bash
cd inkflow-writer
./build-android.sh
```

### 详细步骤

```bash
# 1. 进入项目目录
cd inkflow-writer

# 2. 创建临时项目
flutter create inkflow_writer_app --org com.maxlingg.inkflow --platforms=android

# 3. 复制源代码
cp -R source/inkflow_writer/lib inkflow_writer_app/
cp source/inkflow_writer/pubspec.yaml inkflow_writer_app/pubspec.yaml

# 4. 添加权限
# 编辑 inkflow_writer_app/android/app/src/main/AndroidManifest.xml
# 添加 <uses-permission android:name="android.permission.INTERNET" />

# 5. 构建
cd inkflow_writer_app
flutter pub get
flutter build apk --release

# 6. 获取 APK
# 位置：inkflow_writer_app/build/app/outputs/flutter-apk/app-release.apk
```

---

## 📦 新增功能（v1.4.7）

1. **抽卡功能** - 灵感成书新增3种世界观选项
2. **筛选功能** - 项目列表支持4种筛选方式
3. **骨架屏加载** - 优化加载体验
4. **FAB悬浮按钮** - 快速访问灵感成书
5. **空状态动画** - 提升使用体验

---

## 📝 常见问题

### Q: 如何安装到设备？
```bash
cd inkflow_writer_app
flutter install
```

### Q: 如何修改应用图标和名称？
编辑：`inkflow_writer_app/android/app/src/main/AndroidManifest.xml`
和：`inkflow_writer_app/android/app/src/main/res/`

### Q: 构建失败？
1. 检查Flutter版本：`flutter --version`
2. 确保有足够的磁盘空间
3. 运行 `flutter clean` 后重试
