#!/bin/bash

# InkFlow 写作应用 Android APK 构建脚本
# 版本：v1.4.7

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/source/inkflow_writer"
BUILD_DIR="$SCRIPT_DIR/inkflow_writer_app"

echo "=========================================="
echo "  InkFlow 写作应用 - Android APK 构建"
echo "  版本：v1.4.7"
echo "=========================================="

# 检查Flutter
if ! command -v flutter &> /dev/null; then
    echo "❌ 错误：未找到Flutter命令"
    echo "请先安装Flutter：https://flutter.dev/docs/get-started/install"
    exit 1
fi

echo "✅ Flutter 版本："
flutter --version
echo ""

# 清理旧构建
if [ -d "$BUILD_DIR" ]; then
    echo "🗑️  清理旧构建目录..."
    rm -rf "$BUILD_DIR"
fi

# 创建Flutter项目
echo "🚀 创建Flutter项目..."
cd "$SCRIPT_DIR"
flutter create inkflow_writer_app --org com.maxlingg.inkflow --platforms=android

# 复制源代码
echo "📁 复制源代码..."
cp -R "$SOURCE_DIR/lib" "$BUILD_DIR/"
cp "$SOURCE_DIR/pubspec.yaml" "$BUILD_DIR/pubspec.yaml"
cp "$SOURCE_DIR/analysis_options.yaml" "$BUILD_DIR/analysis_options.yaml"

# 移除测试目录
rm -rf "$BUILD_DIR/test"

# 添加Android权限
echo "🔧 配置Android权限..."
ANDROID_MANIFEST="$BUILD_DIR/android/app/src/main/AndroidManifest.xml"
if [ -f "$ANDROID_MANIFEST" ]; then
    # 添加Internet权限
    if ! grep -q "android.permission.INTERNET" "$ANDROID_MANIFEST"; then
        sed -i 's/<manifest xmlns:android="http:\/\/schemas.android.com\/apk\/res\/android">/<manifest xmlns:android="http:\/\/schemas.android.com\/apk\/res\/android">\
    <uses-permission android:name="android.permission.INTERNET" \/>/' "$ANDROID_MANIFEST"
        echo "   ✓ 添加INTERNET权限"
    else
        echo "   - INTERNET权限已存在"
    fi
fi

# 安装依赖
echo "📦 安装依赖..."
cd "$BUILD_DIR"
flutter pub get

# 运行代码分析
echo "🔍 代码分析..."
set +e
flutter analyze lib --no-fatal-infos --no-fatal-warnings 2>&1 | tee analyze.log
ANALYZE_STATUS=${PIPESTATUS[0]}
set -e

# 检查分析结果
if grep -E '^[[:space:]]*error •|^error •' analyze.log; then
    echo "❌ 发现代码分析错误"
    exit 1
else
    echo "✅ 代码分析通过"
fi

# 构建APK
echo ""
echo "🏗️  构建APK..."
flutter build apk --release

# 查找生成的APK
APK_PATH="$BUILD_DIR/build/app/outputs/flutter-apk/app-release.apk"

if [ -f "$APK_PATH" ]; then
    APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
    
    echo ""
    echo "=========================================="
    echo "  ✅ APK构建成功！"
    echo "=========================================="
    echo ""
    echo "APK位置：$APK_PATH"
    echo "APK大小：$APK_SIZE"
    echo ""
    echo "复制到项目根目录..."
    
    cp "$APK_PATH" "$SCRIPT_DIR/inkflow-writer-v1.4.7-release.apk"
    
    echo "📦 已复制：$SCRIPT_DIR/inkflow-writer-v1.4.7-release.apk"
    echo ""
    echo "🚀 可以直接安装：flutter install"
    echo ""
else
    echo "❌ APK构建失败，请检查错误"
    exit 1
fi
