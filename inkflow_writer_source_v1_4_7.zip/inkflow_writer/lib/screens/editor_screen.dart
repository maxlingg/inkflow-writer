import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/ai_skill.dart';
import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../utils/text_stats.dart';
import 'version_history_screen.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({
    super.key,
    required this.project,
    required this.chapterId,
    required this.settings,
  });

  final WritingProject project;
  final String chapterId;
  final AppSettings settings;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> with WidgetsBindingObserver {
  late WritingProject _project;
  late Chapter _chapter;
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  Timer? _saveTimer;
  bool _saving = false;
  bool _saveAgain = false;
  bool _dirty = false;

  // Undo/Redo functionality
  static const int _maxHistory = 100;
  final List<String> _undoStack = [];
  final List<String> _redoStack = [];
  bool _isUserTyping = false;
  Timer? _undoStackTimer;
  String _lastSavedContent = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _project = widget.project;
    _chapter = _project.chapters.firstWhere((item) => item.id == widget.chapterId);
    _titleController = TextEditingController(text: _chapter.title);
    _contentController = TextEditingController(text: _chapter.content);
    _lastSavedContent = _chapter.content;
    _undoStack.add(_chapter.content);
    _titleController.addListener(_scheduleSave);
    _contentController.addListener(_onContentChanged);
    _contentController.addListener(_scheduleSave);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    _undoStackTimer?.cancel();
    unawaited(_saveNow());
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  void _onContentChanged() {
    if (_isUserTyping) return;
    
    _isUserTyping = true;
    _undoStackTimer?.cancel();
    _undoStackTimer = Timer(const Duration(milliseconds: 500), () {
      _saveUndoState();
      _isUserTyping = false;
    });
  }

  void _saveUndoState() {
    final currentText = _contentController.text;
    if (currentText == _lastSavedContent) return;
    
    if (_undoStack.length >= _maxHistory) {
      _undoStack.removeAt(0);
    }
    _undoStack.add(currentText);
    _redoStack.clear();
    _lastSavedContent = currentText;
  }

  void _undo() {
    if (_undoStack.length <= 1) return;
    
    final current = _undoStack.removeLast();
    _redoStack.add(current);
    
    final previous = _undoStack.last;
    _lastSavedContent = previous;
    
    final selection = _contentController.selection;
    _contentController.text = previous;
    
    // Try to maintain cursor position
    final offset = selection.baseOffset.clamp(0, previous.length);
    _contentController.selection = TextSelection.collapsed(offset: offset);
  }

  void _redo() {
    if (_redoStack.isEmpty) return;
    
    final next = _redoStack.removeLast();
    _undoStack.add(next);
    _lastSavedContent = next;
    
    final selection = _contentController.selection;
    _contentController.text = next;
    
    final offset = selection.baseOffset.clamp(0, next.length);
    _contentController.selection = TextSelection.collapsed(offset: offset);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden) {
      unawaited(_saveNow());
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final content = _contentController.text;
    final hasSelection = _selectedText().trim().isNotEmpty;

    return WillPopScope(
      onWillPop: () async {
        await _saveNow();
        return true;
      },
      child: AnimatedBuilder(
        animation: widget.settings,
        builder: (context, _) {
          return Scaffold(
            appBar: AppBar(
              title: _saving
                  ? const Text('正在保存…')
                  : Text(_dirty ? '未保存更改' : '已自动保存'),
              actions: [
                IconButton(
                  tooltip: '撤销',
                  onPressed: _undoStack.length <= 1 ? null : _undo,
                  icon: const Icon(Icons.undo_rounded),
                ),
                IconButton(
                  tooltip: '重做',
                  onPressed: _redoStack.isEmpty ? null : _redo,
                  icon: const Icon(Icons.redo_rounded),
                ),
                IconButton(
                  tooltip: hasSelection ? 'AI 处理选中文本' : 'AI 技能',
                  onPressed: _openAiAssistant,
                  icon: const Icon(Icons.auto_awesome_rounded),
                ),
                PopupMenuButton<String>(
                  tooltip: '章节工具',
                  onSelected: (value) async {
                    if (value == 'save') await _saveNow();
                    if (value == 'copy') await _copyChapter();
                    if (value == 'split') await _splitAtCursor();
                    if (value == 'distill') await _distillToMaterials();
                    if (value == 'backup') await _backupChapter();
                    if (value == 'history') await _openVersionHistory();
                  },
                  itemBuilder: (context) => const [
                    PopupMenuItem(value: 'save', child: Text('立即保存')),
                    PopupMenuItem(value: 'copy', child: Text('复制本章全文')),
                    PopupMenuItem(value: 'split', child: Text('从光标拆分新章节')),
                    PopupMenuItem(value: 'distill', child: Text('提炼到小说资料')),
                    PopupMenuItem(value: 'backup', child: Text('备份当前版本')),
                    PopupMenuItem(value: 'history', child: Text('查看版本历史')),
                  ],
                ),
              ],
            ),
            body: Column(
              children: [
                // Quick format toolbar
                _buildFormatToolbar(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
                  child: TextField(
                    controller: _titleController,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                    decoration: const InputDecoration(
                      hintText: '章节标题',
                      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
                    child: TextField(
                      controller: _contentController,
                      expands: true,
                      maxLines: null,
                      minLines: null,
                      textAlignVertical: TextAlignVertical.top,
                      keyboardType: TextInputType.multiline,
                      style: TextStyle(
                        fontSize: widget.settings.editorFontSize,
                        height: 1.75,
                      ),
                      decoration: InputDecoration(
                        hintText: '写下这一章发生了什么…',
                        filled: true,
                        fillColor: colors.surfaceContainerHighest.withOpacity(0.34),
                        contentPadding: const EdgeInsets.all(16),
                      ),
                    ),
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: colors.outlineVariant.withOpacity(0.5)),
                      ),
                    ),
                    child: Row(
                      children: [
                        _EditorStat(label: '字符', value: '${TextStats.characters(content)}'),
                        const SizedBox(width: 8),
                        _EditorStat(label: '词/字', value: '${TextStats.words(content)}'),
                        const Spacer(),
                        FilledButton.tonalIcon(
                          onPressed: _openAiAssistant,
                          icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                          label: Text(hasSelection ? 'AI选中' : 'AI技能'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildFormatToolbar() {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        border: Border(
          bottom: BorderSide(color: colors.outlineVariant.withOpacity(0.3)),
        ),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _ToolbarButton(
              icon: Icons.format_bold,
              tooltip: '加粗',
              onPressed: () => _insertSurrounding('**', '**'),
            ),
            _ToolbarButton(
              icon: Icons.format_italic,
              tooltip: '斜体',
              onPressed: () => _insertSurrounding('*', '*'),
            ),
            _ToolbarButton(
              icon: Icons.format_underlined,
              tooltip: '下划线',
              onPressed: () => _insertSurrounding('__', '__'),
            ),
            const SizedBox(width: 8),
            _ToolbarButton(
              icon: Icons.title,
              tooltip: '标题',
              onPressed: () => _insertAtLineStart('## '),
            ),
            _ToolbarButton(
              icon: Icons.format_list_bulleted,
              tooltip: '列表',
              onPressed: () => _insertAtLineStart('- '),
            ),
            _ToolbarButton(
              icon: Icons.format_list_numbered,
              tooltip: '有序列表',
              onPressed: () => _insertAtLineStart('1. '),
            ),
            const SizedBox(width: 8),
            _ToolbarButton(
              icon: Icons.horizontal_rule,
              tooltip: '分割线',
              onPressed: () => _insertLine('---\n'),
            ),
            _ToolbarButton(
              icon: Icons.format_quote_rounded,
              tooltip: '引用',
              onPressed: () => _insertAtLineStart('> '),
            ),
            _ToolbarButton(
              icon: Icons.code,
              tooltip: '代码',
              onPressed: () => _insertSurrounding('`', '`'),
            ),
          ],
        ),
      ),
    );
  }

  void _insertSurrounding(String before, String after) {
    final value = _contentController.value;
    final selection = value.selection;
    
    if (!selection.isValid || selection.isCollapsed) {
      // No selection, just insert both markers
      _contentController.value = TextEditingValue(
        text: value.text.replaceRange(selection.start, selection.end, before + after),
        selection: TextSelection.collapsed(offset: selection.start + before.length),
      );
    } else {
      // Wrap selection
      final selectedText = selection.textInside(value.text);
      _contentController.value = TextEditingValue(
        text: value.text.replaceRange(
          selection.start,
          selection.end,
          before + selectedText + after,
        ),
        selection: TextSelection(
          baseOffset: selection.start,
          extentOffset: selection.start + before.length + selectedText.length + after.length,
        ),
      );
    }
  }

  void _insertAtLineStart(String prefix) {
    final value = _contentController.value;
    final selection = value.selection;
    final text = value.text;
    
    // Find line start
    int lineStart = 0;
    for (int i = selection.start - 1; i >= 0; i--) {
      if (text[i] == '\n') {
        lineStart = i + 1;
        break;
      }
    }
    
    _contentController.value = TextEditingValue(
      text: text.replaceRange(lineStart, lineStart, prefix),
      selection: TextSelection.collapsed(offset: selection.start + prefix.length),
    );
  }

  void _insertLine(String line) {
    final value = _contentController.value;
    final selection = value.selection;
    
    _contentController.value = TextEditingValue(
      text: value.text.replaceRange(selection.start, selection.end, line),
      selection: TextSelection.collapsed(offset: selection.start + line.length),
    );
  }

  void _scheduleSave() {
    if (!_dirty && mounted) {
      setState(() => _dirty = true);
    }
    if (_saving) {
      _saveAgain = true;
      return;
    }
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 650), _saveNow);
  }

  Future<void> _saveNow() async {
    _saveTimer?.cancel();
    if (_saving) {
      _saveAgain = true;
      return;
    }

    if (mounted) setState(() => _saving = true);
    try {
      do {
        _saveAgain = false;
        final now = DateTime.now();
        final nextChapter = _chapter.copyWith(
          title: _titleController.text.trim().isEmpty
              ? '未命名章节'
              : _titleController.text.trim(),
          content: _contentController.text,
          updatedAt: now,
        );
        final nextProject = await StorageService.instance.upsertChapter(
          project: _project,
          chapter: nextChapter,
        );
        _chapter = nextChapter;
        _project = nextProject;
      } while (_saveAgain);
    } finally {
      if (!mounted) return;
      setState(() {
        final currentTitle = _titleController.text.trim().isEmpty
            ? '未命名章节'
            : _titleController.text.trim();
        _saving = false;
        _dirty = currentTitle != _chapter.title ||
            _contentController.text != _chapter.content;
      });
    }
  }

  Future<void> _openAiAssistant() async {
    await _saveNow();
    if (!mounted) return;

    final result = await showModalBottomSheet<_AiAssistantResult>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => _AiAssistantSheet(
        settings: widget.settings,
        project: _project,
        chapter: _chapter,
        selectedText: _selectedText(),
      ),
    );

    if (result == null || result.text.trim().isEmpty) return;
    await _applyAiText(result);
  }

  Future<void> _applyAiText(_AiAssistantResult result) async {
    final text = result.text.trimRight();

    if (result.mode == _AiInsertMode.saveNote) {
      final now = DateTime.now();
      final note = ProjectNote(
        id: newEntityId('note'),
        title: 'AI草稿-${_chapter.title}',
        body: text,
        tag: 'AI草稿',
        createdAt: now,
        updatedAt: now,
      );
      final nextProject = _project.copyWith(
        notes: [note, ..._project.notes],
        updatedAt: now,
      );
      await StorageService.instance.upsertProject(nextProject);
      if (!mounted) return;
      setState(() => _project = nextProject);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已保存到设定备忘 / AI草稿')),
      );
      return;
    }

    await StorageService.instance.backupChapter(
      project: _project,
      chapter: _chapter.copyWith(
        title: _titleController.text.trim().isEmpty ? _chapter.title : _titleController.text.trim(),
        content: _contentController.text,
        updatedAt: DateTime.now(),
      ),
      reason: 'AI写入前备份',
    );

    final value = _contentController.value;
    final selection = value.selection;
    final hasSelection = selection.isValid && !selection.isCollapsed;

    if ((result.mode == _AiInsertMode.insert || result.mode == _AiInsertMode.replaceSelection) && selection.isValid) {
      final start = selection.start.clamp(0, value.text.length).toInt();
      final end = selection.end.clamp(0, value.text.length).toInt();
      final nextText = value.text.replaceRange(
        start,
        result.mode == _AiInsertMode.replaceSelection && hasSelection ? end : start,
        text,
      );
      _contentController.value = TextEditingValue(
        text: nextText,
        selection: TextSelection.collapsed(offset: start + text.length),
      );
    } else {
      final prefix = value.text.trim().isEmpty ? '' : '\n\n';
      final nextText = '${value.text}$prefix$text';
      _contentController.value = TextEditingValue(
        text: nextText,
        selection: TextSelection.collapsed(offset: nextText.length),
      );
    }
    _scheduleSave();
  }

  String _selectedText() {
    final value = _contentController.value;
    final selection = value.selection;
    if (!selection.isValid || selection.isCollapsed) return '';
    final start = selection.start.clamp(0, value.text.length).toInt();
    final end = selection.end.clamp(0, value.text.length).toInt();
    if (start >= end) return '';
    return value.text.substring(start, end);
  }

  Future<void> _distillToMaterials() async {
    await _saveNow();
    if (_contentController.text.trim().isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('本章还没有内容可提炼')),
      );
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('正在提炼到小说资料…')),
    );
    try {
      final text = await AiService.instance.runSkill(
        settings: widget.settings,
        skill: builtInSkillById('draft_to_files'),
        project: _project,
        chapter: _chapter,
        extraInstruction: '把本章提炼成章节摘要、人物变化、世界观新增信息和伏笔清单，适合追加到资料库。',
        contextMode: AiContextMode.chapter,
        selectedText: '',
      );
      final next = await StorageService.instance.appendMaterial(
        project: _project,
        title: '章节摘要',
        content: '\n## ${_chapter.title}\n\n$text',
        tag: 'AI提炼',
      );
      if (!mounted) return;
      setState(() => _project = next);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已追加到 小说资料/章节摘要.md')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('提炼失败：$error')),
      );
    }
  }

  Future<void> _backupChapter() async {
    await _saveNow();
    final path = await StorageService.instance.backupChapter(
      project: _project,
      chapter: _chapter,
      reason: '手动备份',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已备份：$path')),
    );
  }

  Future<void> _openVersionHistory() async {
    await _saveNow();
    if (!mounted) return;
    final restoredText = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => VersionHistoryScreen(project: _project, chapter: _chapter)),
    );
    if (restoredText == null) return;
    await StorageService.instance.backupChapter(
      project: _project,
      chapter: _chapter,
      reason: '恢复历史前备份',
    );
    _contentController.text = restoredText;
    _scheduleSave();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已恢复历史版本，并自动保存')),
    );
  }

  Future<void> _copyChapter() async {
    await Clipboard.setData(ClipboardData(text: _contentController.text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已复制本章全文')),
    );
  }

  Future<void> _splitAtCursor() async {
    final value = _contentController.value;
    final offset = value.selection.baseOffset;
    if (offset <= 0 || offset >= value.text.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请把光标放在要拆分的位置')),
      );
      return;
    }

    final before = value.text.substring(0, offset).trimRight();
    final after = value.text.substring(offset).trimLeft();
    if (after.isEmpty) return;

    final titleController = TextEditingController(text: '${_chapter.title} 下');
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('拆分为新章节'),
        content: TextField(
          controller: titleController,
          autofocus: true,
          decoration: const InputDecoration(labelText: '新章节标题'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, titleController.text.trim()),
            child: const Text('拆分'),
          ),
        ],
      ),
    );
    if (title == null || title.isEmpty) return;

    final now = DateTime.now();
    final current = _chapter.copyWith(content: before, updatedAt: now);
    final newChapter = Chapter(
      id: newEntityId('chapter'),
      title: title,
      content: after,
      createdAt: now,
      updatedAt: now,
    );

    final chapters = <Chapter>[];
    for (final item in _project.chapters) {
      if (item.id == _chapter.id) {
        chapters.add(current);
        chapters.add(newChapter);
      } else {
        chapters.add(item);
      }
    }

    final nextProject = _project.copyWith(chapters: chapters, updatedAt: now);
    await StorageService.instance.upsertProject(nextProject);
    if (!mounted) return;
    setState(() {
      _project = nextProject;
      _chapter = current;
      _contentController.text = before;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已拆分出「$title」')),
    );
  }
}

class _AiAssistantSheet extends StatefulWidget {
  const _AiAssistantSheet({
    required this.settings,
    required this.project,
    required this.chapter,
    required this.selectedText,
  });

  final AppSettings settings;
  final WritingProject project;
  final Chapter chapter;
  final String selectedText;

  @override
  State<_AiAssistantSheet> createState() => _AiAssistantSheetState();
}

class _AiAssistantSheetState extends State<_AiAssistantSheet> {
  List<AiSkill> _skills = const [];
  AiSkill? _skill;
  String _category = '全部';
  AiContextMode _contextMode = AiContextMode.chapter;
  final _instructionController = TextEditingController();
  bool _loading = false;
  bool _loadingSkills = true;
  String? _output;
  String? _error;

  @override
  void initState() {
    super.initState();
    _contextMode = widget.selectedText.trim().isNotEmpty
        ? AiContextMode.selection
        : AiContextMode.chapter;
    _loadSkills();
  }

  Future<void> _loadSkills() async {
    final skills = await AiSkillStore.loadActiveSkills();
    if (!mounted) return;
    setState(() {
      _skills = skills;
      _skill = skills.isEmpty ? null : skills.first;
      _loadingSkills = false;
    });
  }

  @override
  void dispose() {
    _instructionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    final filtered = _category == '全部'
        ? _skills
        : _skills.where((skill) => skill.category == _category).toList();
    final selectedSkill = _skill;

    return AnimatedPadding(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(bottom: bottom),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.9,
          child: _loadingSkills
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'AI 技能工作台',
                                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                        fontWeight: FontWeight.w900,
                                      ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  widget.settings.hasAiApiKey
                                      ? '联网生成：${widget.settings.aiModel}'
                                      : '未配置 API Key：当前使用本地模板',
                                  style: TextStyle(color: colors.onSurfaceVariant),
                                ),
                              ],
                            ),
                          ),
                          if (_loading)
                            const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(strokeWidth: 3),
                            ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 46,
                      child: ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        scrollDirection: Axis.horizontal,
                        itemCount: skillCategories.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (context, index) {
                          final category = skillCategories[index];
                          return ChoiceChip(
                            selected: _category == category,
                            label: Text(category),
                            onSelected: _loading
                                ? null
                                : (_) => setState(() {
                                      _category = category;
                                      final next = category == '全部'
                                          ? _skills
                                          : _skills.where((item) => item.category == category).toList();
                                      if (next.isNotEmpty) _skill = next.first;
                                      _output = null;
                                      _error = null;
                                    }),
                          );
                        },
                      ),
                    ),
                    SizedBox(
                      height: 58,
                      child: ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        scrollDirection: Axis.horizontal,
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (context, index) {
                          final skill = filtered[index];
                          return ChoiceChip(
                            selected: selectedSkill?.id == skill.id,
                            label: Text('${skill.icon} ${skill.name}'),
                            onSelected: _loading
                                ? null
                                : (_) => setState(() {
                                      _skill = skill;
                                      _output = null;
                                      _error = null;
                                    }),
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (selectedSkill != null) ...[
                            Text(
                              selectedSkill.shortDescription,
                              style: TextStyle(color: colors.onSurfaceVariant),
                            ),
                            const SizedBox(height: 8),
                          ],
                          Wrap(
                            spacing: 8,
                            children: AiContextMode.values.map((mode) {
                              final disabled = mode == AiContextMode.selection &&
                                  widget.selectedText.trim().isEmpty;
                              return ChoiceChip(
                                selected: _contextMode == mode,
                                label: Text(mode.label),
                                onSelected: disabled || _loading
                                    ? null
                                    : (_) => setState(() => _contextMode = mode),
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _instructionController,
                            minLines: 2,
                            maxLines: 4,
                            decoration: const InputDecoration(
                              labelText: '补充要求，可不填',
                              hintText: '例如：更热血一点、控制在300字、偏悬疑氛围……',
                            ),
                          ),
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton.icon(
                              onPressed: _loading || selectedSkill == null ? null : _generate,
                              icon: const Icon(Icons.auto_awesome_rounded),
                              label: Text(_loading ? '生成中…' : '运行「${selectedSkill?.name ?? '技能'}」'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: colors.surfaceContainerHighest.withOpacity(0.48),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: _buildOutput(context),
                      ),
                    ),
                    if ((_output ?? '').trim().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                        child: Row(
                          children: [
                            IconButton.outlined(
                              onPressed: _copyOutput,
                              icon: const Icon(Icons.copy_rounded),
                              tooltip: '复制',
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton.tonal(
                                onPressed: () => Navigator.pop(
                                  context,
                                  _AiAssistantResult(text: _output!, mode: _AiInsertMode.saveNote),
                                ),
                                child: const Text('存草稿'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton.tonal(
                                onPressed: () => Navigator.pop(
                                  context,
                                  _AiAssistantResult(text: _output!, mode: _AiInsertMode.insert),
                                ),
                                child: const Text('插入'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton(
                                onPressed: () => Navigator.pop(
                                  context,
                                  _AiAssistantResult(
                                    text: _output!,
                                    mode: widget.selectedText.trim().isEmpty
                                        ? _AiInsertMode.append
                                        : _AiInsertMode.replaceSelection,
                                  ),
                                ),
                                child: Text(widget.selectedText.trim().isEmpty ? '追加' : '替换'),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildOutput(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    if (_error != null) {
      return SingleChildScrollView(
        child: Text(
          _error!,
          style: TextStyle(color: colors.error),
        ),
      );
    }
    if ((_output ?? '').trim().isEmpty) {
      return Center(
        child: Text(
          '先选分类和技能，再选择上下文范围。\n生成后可复制、插入、追加、替换选中或存入 AI 草稿。',
          textAlign: TextAlign.center,
          style: TextStyle(color: colors.onSurfaceVariant),
        ),
      );
    }
    return SingleChildScrollView(
      child: SelectableText(
        _output!,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.65),
      ),
    );
  }

  Future<void> _generate() async {
    final selectedSkill = _skill;
    if (selectedSkill == null) return;

    setState(() {
      _loading = true;
      _error = null;
      _output = null;
    });

    try {
      final output = await AiService.instance.runSkill(
        settings: widget.settings,
        skill: selectedSkill,
        project: widget.project,
        chapter: widget.chapter,
        extraInstruction: _instructionController.text,
        contextMode: _contextMode,
        selectedText: widget.selectedText,
      );
      if (!mounted) return;
      setState(() => _output = output);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _copyOutput() async {
    final output = _output;
    if (output == null || output.trim().isEmpty) return;
    await Clipboard.setData(ClipboardData(text: output));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已复制到剪贴板')),
    );
  }
}

class _AiAssistantResult {
  const _AiAssistantResult({required this.text, required this.mode});

  final String text;
  final _AiInsertMode mode;
}

enum _AiInsertMode { insert, append, replaceSelection, saveNote }

class _EditorStat extends StatelessWidget {
  const _EditorStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(11),
      ),
      child: Text('$label $value'),
    );
  }
}

class _ToolbarButton extends StatelessWidget {
  const _ToolbarButton({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return IconButton(
      icon: Icon(icon, size: 20),
      tooltip: tooltip,
      constraints: const BoxConstraints.tightFor(width: 36, height: 36),
      style: IconButton.styleFrom(
        backgroundColor: colors.surfaceContainerHighest.withOpacity(0.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
      onPressed: onPressed,
    );
  }
}
