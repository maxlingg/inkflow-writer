import 'package:flutter/material.dart';

import '../models/inspiration_book_draft.dart';
import '../models/writing_project.dart';
import '../services/ai_inspiration_service.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../widgets/gacha_widget.dart';
import 'project_screen.dart';

class InspirationToBookScreen extends StatefulWidget {
  const InspirationToBookScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  State<InspirationToBookScreen> createState() => _InspirationToBookScreenState();
}

class _InspirationToBookScreenState extends State<InspirationToBookScreen> {
  final _inspirationController = TextEditingController();
  final _expandedInspirationController = TextEditingController();
  final _worldviewController = TextEditingController();
  final _coreConflictController = TextEditingController();
  final _protagonistController = TextEditingController();
  final _uniqueSettingsController = TextEditingController();
  final _readerPromiseController = TextEditingController();
  final _titleController = TextEditingController();
  final _genreController = TextEditingController();
  final _styleController = TextEditingController();

  bool _generateFirstChapter = true;
  bool _working = false;
  bool _worldAccepted = false;
  bool _showGachaOptions = false;
  String _status = '';
  InspirationWorldSeed? _worldSeed;
  InspirationBookDraft? _lastDraft;
  WritingProject? _lastProject;
  List<WorldOption> _gachaOptions = [];
  WorldOption? _selectedGachaOption;

  @override
  void dispose() {
    _inspirationController.dispose();
    _expandedInspirationController.dispose();
    _worldviewController.dispose();
    _coreConflictController.dispose();
    _protagonistController.dispose();
    _uniqueSettingsController.dispose();
    _readerPromiseController.dispose();
    _titleController.dispose();
    _genreController.dispose();
    _styleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('灵感成书'),
        actions: [
          IconButton(
            tooltip: '示例灵感',
            onPressed: _working ? null : _fillExample,
            icon: const Icon(Icons.tips_and_updates_rounded),
          ),
          IconButton(
            tooltip: '重置流程',
            onPressed: _working ? null : _resetFlow,
            icon: const Icon(Icons.restart_alt_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        children: [
          _HeroCard(hasApiKey: widget.settings.hasAiApiKey),
          const SizedBox(height: 16),
          _StepBanner(
            activeStep: _worldSeed == null ? 1 : (_worldAccepted ? 3 : 2),
          ),
          const SizedBox(height: 16),
          _SectionCard(
            title: '1. 输入原始灵感',
            subtitle: '先只输入脑洞，不急着选书名、类型和文风。可以试试抽卡功能！',
            child: Column(
              children: [
                TextField(
                  controller: _inspirationController,
                  minLines: 5,
                  maxLines: 9,
                  textInputAction: TextInputAction.newline,
                  decoration: const InputDecoration(
                    labelText: '原始灵感',
                    hintText: '例如：一个现代人死后成了地府代理人，用现代法律和职场规则整顿阴间。',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: GachaDrawButton(
                        onPressed: _working ? null : _gachaWorldOptions,
                        isLoading: _working && _showGachaOptions,
                        label: '🎲 抽卡生成',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _working ? null : _buildWorldview,
                        icon: _working && _worldSeed == null && !_showGachaOptions
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.travel_explore_rounded),
                        label: Text(_worldSeed == null ? '生成世界观' : '重新生成'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (_showGachaOptions) ...[
            const SizedBox(height: 16),
            _buildGachaOptions(colors),
          ],
          if (_worldSeed != null) ...[
            const SizedBox(height: 16),
            _buildWorldviewReview(colors),
          ],
          if (_worldAccepted && _worldSeed != null) ...[
            const SizedBox(height: 16),
            _buildChoiceAndCreate(colors),
          ],
          if (_status.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              _status,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: _working ? colors.primary : colors.onSurfaceVariant,
                    fontWeight: FontWeight.w800,
                  ),
            ),
          ],
          if (_lastDraft != null) ...[
            const SizedBox(height: 18),
            _DraftPreviewCard(
              draft: _lastDraft!,
              project: _lastProject,
              onOpenProject: _lastProject == null ? null : _openLastProject,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildWorldviewReview(ColorScheme colors) {
    return _SectionCard(
      title: '2. 确认世界观',
      subtitle: '这里才是真正的“灵感扩展”。满意后再进入选书名、选类型、选文风。内容可直接修改。',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _MultilineField(
            controller: _expandedInspirationController,
            label: '完整灵感 / 故事概念',
            minLines: 5,
            maxLines: 12,
          ),
          const SizedBox(height: 12),
          _MultilineField(
            controller: _worldviewController,
            label: '世界观草案',
            minLines: 10,
            maxLines: 18,
          ),
          const SizedBox(height: 12),
          _MultilineField(
            controller: _coreConflictController,
            label: '核心冲突',
            minLines: 3,
            maxLines: 7,
          ),
          const SizedBox(height: 12),
          _MultilineField(
            controller: _protagonistController,
            label: '主角种子',
            minLines: 3,
            maxLines: 7,
          ),
          const SizedBox(height: 12),
          _MultilineField(
            controller: _uniqueSettingsController,
            label: '独特设定 / 差异化',
            minLines: 4,
            maxLines: 9,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _readerPromiseController,
            decoration: const InputDecoration(
              labelText: '读者承诺',
              hintText: '这本书给读者的核心看点。',
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _working ? null : _buildWorldview,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('不满意，重写世界观'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _working ? null : _acceptWorldview,
                  icon: const Icon(Icons.check_circle_rounded),
                  label: const Text('满意，下一步'),
                ),
              ),
            ],
          ),
          if (_worldAccepted) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: colors.primaryContainer.withOpacity(0.5),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Text('已采用这个世界观。下面请选择书名、类型和文风模板。'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildChoiceAndCreate(ColorScheme colors) {
    final seed = _worldSeed!;
    return _SectionCard(
      title: '3. 选择书名、类型、文风，再创建',
      subtitle: '这一步才会生成大纲、人物库、伏笔库、章节卡和第 1 章。',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ChoiceBlock(
            title: '书名候选',
            options: seed.titleOptions,
            selected: _titleController.text,
            onSelected: (value) => setState(() => _titleController.text = value),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(labelText: '最终书名，可手动修改'),
          ),
          const SizedBox(height: 16),
          _ChoiceBlock(
            title: '类型候选',
            options: seed.genreOptions,
            selected: _genreController.text,
            onSelected: (value) => setState(() => _genreController.text = value),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _genreController,
            decoration: const InputDecoration(labelText: '最终类型，可手动修改'),
          ),
          const SizedBox(height: 16),
          Text('文风模板候选', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          ...seed.styleTemplates.map(
            (style) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => setState(() => _styleController.text = style),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _styleController.text.trim() == style.trim()
                        ? colors.primaryContainer.withOpacity(0.7)
                        : colors.surfaceContainerHighest.withOpacity(0.55),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _styleController.text.trim() == style.trim()
                          ? colors.primary.withOpacity(0.45)
                          : colors.outlineVariant.withOpacity(0.45),
                    ),
                  ),
                  child: Text(style, style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.45)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          _MultilineField(
            controller: _styleController,
            label: '最终文风模板，可手动修改',
            minLines: 3,
            maxLines: 7,
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('同时生成第 1 章正文'),
            subtitle: const Text('关闭后只生成小说资料和前三章章节卡。'),
            value: _generateFirstChapter,
            onChanged: _working ? null : (value) => setState(() => _generateFirstChapter = value),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _working ? null : _createRemainingContent,
              icon: _working && _worldAccepted
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.auto_awesome_rounded),
              label: Text(_working ? '正在创建剩余内容…' : '开始创建剩下的内容'),
            ),
          ),
        ],
      ),
    );
  }

  void _fillExample() {
    _inspirationController.text = '一个现代人死后成了地府代理人，用现代法律和职场规则整顿阴间。';
  }

  void _resetFlow() {
    setState(() {
      _worldSeed = null;
      _worldAccepted = false;
      _showGachaOptions = false;
      _gachaOptions = [];
      _selectedGachaOption = null;
      _lastDraft = null;
      _lastProject = null;
      _status = '';
      _expandedInspirationController.clear();
      _worldviewController.clear();
      _coreConflictController.clear();
      _protagonistController.clear();
      _uniqueSettingsController.clear();
      _readerPromiseController.clear();
      _titleController.clear();
      _genreController.clear();
      _styleController.clear();
    });
  }

  Future<void> _buildWorldview() async {
    final inspiration = _inspirationController.text.trim();
    if (inspiration.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('先写一个稍微完整的灵感，至少 6 个字。')),
      );
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _working = true;
      _status = widget.settings.hasAiApiKey ? '正在根据灵感构建完整世界观…' : '当前为本地模板模式：正在生成可编辑世界观草案…';
      _worldAccepted = false;
      _lastDraft = null;
      _lastProject = null;
    });

    try {
      final seed = await AiService.instance.buildWorldFromInspiration(
        settings: widget.settings,
        inspiration: inspiration,
      );
      if (!mounted) return;
      _loadWorldSeed(seed);
      setState(() {
        _worldSeed = seed;
        _status = '世界观草案已生成。请先检查并修改，满意后点“满意，下一步”。';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = '世界观生成失败：$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  void _loadWorldSeed(InspirationWorldSeed seed) {
    _expandedInspirationController.text = seed.expandedInspiration;
    _worldviewController.text = seed.worldview;
    _coreConflictController.text = seed.coreConflict;
    _protagonistController.text = seed.protagonistSeed;
    _uniqueSettingsController.text = seed.uniqueSettings;
    _readerPromiseController.text = seed.readerPromise;
    _titleController.text = seed.titleOptions.isEmpty ? '' : seed.titleOptions.first;
    _genreController.text = seed.genreOptions.isEmpty ? '' : seed.genreOptions.first;
    _styleController.text = seed.styleTemplates.isEmpty ? '' : seed.styleTemplates.first;
  }

  void _acceptWorldview() {
    final seed = _editableWorldSeed();
    setState(() {
      _worldSeed = seed;
      _worldAccepted = true;
      _status = '已确认世界观。现在选择书名、类型和文风模板，再创建剩余内容。';
    });
  }

  InspirationWorldSeed _editableWorldSeed() {
    final seed = _worldSeed;
    if (seed == null) {
      return InspirationWorldSeed.fromJson(<String, dynamic>{});
    }
    return seed.copyWith(
      expandedInspiration: _expandedInspirationController.text.trim(),
      worldview: _worldviewController.text.trim(),
      coreConflict: _coreConflictController.text.trim(),
      protagonistSeed: _protagonistController.text.trim(),
      uniqueSettings: _uniqueSettingsController.text.trim(),
      readerPromise: _readerPromiseController.text.trim(),
    );
  }

  Future<void> _createRemainingContent() async {
    final inspiration = _inspirationController.text.trim();
    final seed = _editableWorldSeed();
    final title = _titleController.text.trim();
    if (title.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先选择或填写书名。')),
      );
      return;
    }
    if (!_worldAccepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先确认世界观。')),
      );
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _working = true;
      _status = widget.settings.hasAiApiKey ? '正在基于已确认世界观创建大纲、人物、章节卡和开篇…' : '当前为本地模板模式：正在按已确认世界观创建可编辑项目…';
      _lastDraft = null;
      _lastProject = null;
    });

    try {
      final draft = await AiService.instance.createBookFromWorldSeed(
        settings: widget.settings,
        originalInspiration: inspiration,
        worldSeed: seed,
        title: title,
        genre: _genreController.text,
        style: _styleController.text,
        generateFirstChapter: _generateFirstChapter,
      );
      if (!mounted) return;
      setState(() => _status = '正在写入本地小说文件夹…');

      final project = await _createProjectFromDraft(draft, inspiration, seed);
      if (!mounted) return;
      setState(() {
        _lastDraft = draft;
        _lastProject = project;
        _status = '已创建《${project.title}》，小说资料和章节内容已保存到本地。';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('《${project.title}》已创建'),
          action: SnackBarAction(label: '打开', onPressed: _openLastProject),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = '创建失败：$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<WritingProject> _createProjectFromDraft(
    InspirationBookDraft draft,
    String originalInspiration,
    InspirationWorldSeed worldSeed,
  ) async {
    final now = DateTime.now();
    final title = await _uniqueProjectTitle(draft.title.trim().isEmpty ? '灵感小说' : draft.title.trim());
    final firstChapterTitle = draft.firstChapterTitle.trim().isEmpty ? '第1章' : draft.firstChapterTitle.trim();

    final project = WritingProject(
      id: newEntityId('project'),
      title: title,
      description: draft.description,
      genre: draft.genre,
      createdAt: now,
      updatedAt: now,
      chapters: [
        Chapter(
          id: newEntityId('chapter'),
          title: firstChapterTitle,
          content: draft.firstChapterContent.trim(),
          createdAt: now,
          updatedAt: now,
        ),
      ],
      notes: [
        _note('灵感成书报告', draft.incubationReport, 'AI'),
        _note('原始灵感', '# 原始灵感\n\n$originalInspiration', '灵感'),
        _note('已确认世界观草案', _worldSeedNote(worldSeed), '灵感'),
        _note('核心卖点', draft.sellingPoints, '资料'),
        _note('世界观', draft.worldview, '资料'),
        _note('人物库', draft.characters, '资料'),
        _note('大纲', draft.outline, '资料'),
        _note('伏笔库', draft.foreshadowing, '资料'),
        _note('时间线', draft.timeline, '资料'),
        _note('禁止改动设定', draft.lockedSettings, '资料'),
        _note('文风模板', draft.styleTemplate, '资料'),
        _note('章节卡片', draft.chapterCards, '资料'),
        _note('章节摘要', '# 章节摘要\n\n## $firstChapterTitle\n\n待写完后自动归档。', '资料'),
        _note('长篇质检报告', '# 长篇质检报告\n\n尚未执行一致性检查。', '资料'),
        _note('连续写作日志', '# 连续写作日志\n\n由灵感成书创建于 ${now.toIso8601String()}。', '资料'),
        _note('AI草稿', '# AI草稿\n\n', 'AI'),
      ],
    );

    await StorageService.instance.upsertProject(project);
    final projects = await StorageService.instance.loadProjects();
    return projects.firstWhere((item) => item.id == project.id, orElse: () => project);
  }

  String _worldSeedNote(InspirationWorldSeed seed) {
    return '''# 已确认世界观草案

## 完整灵感 / 故事概念

${seed.expandedInspiration}

## 世界观草案

${seed.worldview}

## 核心冲突

${seed.coreConflict}

## 主角种子

${seed.protagonistSeed}

## 独特设定

${seed.uniqueSettings}

## 读者承诺

${seed.readerPromise}''';
  }

  ProjectNote _note(String title, String body, String tag) {
    final now = DateTime.now();
    return ProjectNote(
      id: newEntityId('note'),
      title: title,
      body: body,
      tag: tag,
      createdAt: now,
      updatedAt: now,
    );
  }

  Future<String> _uniqueProjectTitle(String baseTitle) async {
    final projects = await StorageService.instance.loadProjects();
    final existing = projects.map((item) => item.title.trim()).toSet();
    if (!existing.contains(baseTitle)) return baseTitle;
    for (var i = 2; i < 999; i++) {
      final candidate = '$baseTitle $i';
      if (!existing.contains(candidate)) return candidate;
    }
    return '$baseTitle ${DateTime.now().millisecondsSinceEpoch}';
  }

  Future<void> _openLastProject() async {
    final project = _lastProject;
    if (project == null || !mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProjectScreen(project: project, settings: widget.settings)),
    );
  }

  Future<void> _gachaWorldOptions() async {
    final inspiration = _inspirationController.text.trim();
    if (inspiration.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('灵感至少需要 4 个字才能抽卡哦~')),
      );
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _working = true;
      _showGachaOptions = true;
      _status = '正在生成 3 个世界观选项…';
    });

    try {
      final service = AiInspirationService(widget.settings);
      final result = await service.gachaWorldOptions(inspiration);
      if (!mounted) return;
      setState(() {
        _gachaOptions = result.options;
        _selectedGachaOption = null;
        _status = '已生成 3 个选项，请选择一个！';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = '抽卡生成失败：$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Widget _buildGachaOptions(ColorScheme colors) {
    return _SectionCard(
      title: '🎲 抽卡结果',
      subtitle: '点击卡片选择喜欢的世界观',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const GachaRarityBanner(
            title: '灵感抽卡',
            subtitle: '3个不同风格的世界观供你选择',
          ),
          const SizedBox(height: 16),
          ..._gachaOptions.asMap().entries.map(
            (entry) {
              final index = entry.key;
              final option = entry.value;
              final isSelected = _selectedGachaOption?.id == option.id;
              return Padding(
                padding: EdgeInsets.only(bottom: index < 2 ? 12 : 0),
                child: GachaCard(
                  title: option.title,
                  content: option.expandedInspiration,
                  isSelected: isSelected,
                  onTap: () => _selectGachaOption(option),
                  index: index,
                ),
              );
            },
          ),
          if (_selectedGachaOption != null) ...[
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _working ? null : _confirmGachaOption,
                icon: const Icon(Icons.check_circle_rounded),
                label: const Text('确认选择并进入下一步'),
              ),
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: _working ? null : _gachaWorldOptions,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('再抽一次'),
            ),
          ],
        ],
      ),
    );
  }

  void _selectGachaOption(WorldOption option) {
    setState(() {
      _selectedGachaOption = option;
    });
  }

  void _confirmGachaOption() {
    final option = _selectedGachaOption;
    if (option == null) return;
    final seed = InspirationWorldSeed.fromOption(option);
    _loadWorldSeed(seed);
    setState(() {
      _worldSeed = seed;
      _showGachaOptions = false;
      _status = '已选择：${option.title}。请检查并修改世界观，满意后点"满意，下一步"。';
    });
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.hasApiKey});

  final bool hasApiKey;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: colors.primaryContainer.withOpacity(0.72),
        borderRadius: BorderRadius.circular(26),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: colors.primary.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(Icons.auto_fix_high_rounded, color: colors.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '先定世界观，再开书',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                        color: colors.onPrimaryContainer,
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '流程改为：输入灵感 → AI 扩展完整世界观 → 你确认世界观 → 选择书名、类型、文风 → 创建人物库、大纲、章节卡和第 1 章。',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: colors.onPrimaryContainer.withOpacity(0.78),
                  height: 1.45,
                ),
          ),
          const SizedBox(height: 12),
          Chip(
            avatar: Icon(hasApiKey ? Icons.cloud_done_rounded : Icons.offline_bolt_rounded, size: 18),
            label: Text(hasApiKey ? '联网 AI 模式' : '本地模板模式'),
          ),
        ],
      ),
    );
  }
}

class _StepBanner extends StatelessWidget {
  const _StepBanner({required this.activeStep});

  final int activeStep;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _StepPill(index: 1, title: '灵感', active: activeStep == 1, done: activeStep > 1)),
        const SizedBox(width: 8),
        Expanded(child: _StepPill(index: 2, title: '世界观', active: activeStep == 2, done: activeStep > 2)),
        const SizedBox(width: 8),
        Expanded(child: _StepPill(index: 3, title: '创建', active: activeStep == 3, done: false)),
      ],
    );
  }
}

class _StepPill extends StatelessWidget {
  const _StepPill({required this.index, required this.title, required this.active, required this.done});

  final int index;
  final String title;
  final bool active;
  final bool done;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: active || done ? colors.primaryContainer.withOpacity(0.75) : colors.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(done ? Icons.check_circle_rounded : Icons.circle_rounded, size: 14, color: active || done ? colors.primary : colors.onSurfaceVariant),
          const SizedBox(width: 5),
          Flexible(
            child: Text(
              '$index $title',
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: active || done ? colors.primary : colors.onSurfaceVariant,
                    fontWeight: FontWeight.w900,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.subtitle, required this.child});

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    height: 1.35,
                  ),
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _MultilineField extends StatelessWidget {
  const _MultilineField({required this.controller, required this.label, required this.minLines, required this.maxLines});

  final TextEditingController controller;
  final String label;
  final int minLines;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      minLines: minLines,
      maxLines: maxLines,
      textInputAction: TextInputAction.newline,
      decoration: InputDecoration(labelText: label, alignLabelWithHint: true),
    );
  }
}

class _ChoiceBlock extends StatelessWidget {
  const _ChoiceBlock({required this.title, required this.options, required this.selected, required this.onSelected});

  final String title;
  final List<String> options;
  final String selected;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options.map((option) {
            final isSelected = option.trim() == selected.trim();
            return ChoiceChip(
              label: Text(option, overflow: TextOverflow.ellipsis),
              selected: isSelected,
              onSelected: (_) => onSelected(option),
            );
          }).toList(),
        ),
      ],
    );
  }
}

class _DraftPreviewCard extends StatelessWidget {
  const _DraftPreviewCard({required this.draft, required this.project, required this.onOpenProject});

  final InspirationBookDraft draft;
  final WritingProject? project;
  final VoidCallback? onOpenProject;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '创建结果',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            _InfoRow(label: '书名', value: project?.title ?? draft.title),
            _InfoRow(label: '类型', value: draft.genre),
            _InfoRow(label: '简介', value: draft.description),
            _InfoRow(label: '开篇', value: draft.firstChapterTitle),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: colors.surfaceContainerHighest.withOpacity(0.6),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(
                '已写入：已确认世界观草案、小说资料、章节内容、章节卡片、伏笔库、时间线、文风模板、灵感成书报告。',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.45),
              ),
            ),
            if (onOpenProject != null) ...[
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: onOpenProject,
                icon: const Icon(Icons.folder_open_rounded),
                label: const Text('打开这本小说'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 48,
            child: Text(
              label,
              style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900),
            ),
          ),
          Expanded(
            child: Text(
              value.trim().isEmpty ? '无' : value.trim(),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
