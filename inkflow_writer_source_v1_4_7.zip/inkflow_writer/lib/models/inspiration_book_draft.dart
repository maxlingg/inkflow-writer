class GachaResult {
  const GachaResult({
    required this.options,
  });

  final List<WorldOption> options;

  factory GachaResult.fromLocal(String inspiration) {
    final clean = inspiration.trim().isEmpty ? '一个普通人卷入异常世界，并用自己的方式改变规则' : inspiration.trim();
    final titleBase = clean.length <= 8 ? clean : '${clean.substring(0, 8)}...';

    return GachaResult(
      options: [
        WorldOption(
          id: 'option-1',
          title: '⭐ 爽文路线',
          expandedInspiration: '$clean\n\n这个灵感可以扩展成一部爽文小说：主角从最底层开始，快速获得能力升级，每章都有打脸爽点，旧势力不断送经验包，主角最终站在世界顶端。',
          worldview: '# 世界观草案\n\n## 世界底层规则\n- 有明确的境界/等级体系\n- 有明确的升级路径\n- 有明确的资源获取方式\n\n## 势力结构\n- 有明确的等级压制\n- 有明确的地盘划分',
          coreConflict: '主角想快速崛起，但旧势力不允许新的变数出现，不断打压，逼得主角必须反击。',
          protagonistSeed: '主角原本是底层小人物，意外获得金手指，从此一路逆袭打脸。',
          uniqueSettings: '- 升级快但不崩坏\n- 打脸爽点密集\n- 配角有记忆点',
          readerPromise: '看主角一路升级打脸，爽点不断，让你看了就停不下来。',
          titleOptions: [titleBase, '我在异常世界当大佬', '从底层开始崛起'],
          genreOptions: const ['爽文 / 升级流', '都市脑洞', '轻松吐槽'],
          styleTemplates: const [
            '快节奏、强冲突、手机端易读，每章结尾有追读钩子。',
            '轻松吐槽、爽点明确，对话有梗但不破坏紧张感。',
            '不啰嗦，直接打脸，怎么爽怎么来。',
          ],
        ),
        WorldOption(
          id: 'option-2',
          title: '✨ 智斗路线',
          expandedInspiration: '$clean\n\n这个灵感可以扩展成一部智斗小说：主角不靠战力碾压，而是靠智商布局，用规则漏洞破局，多方势力博弈，不断反转。',
          worldview: '# 世界观草案\n\n## 世界底层规则\n- 规则明确但有漏洞\n- 信息差就是优势\n- 多方势力平衡\n\n## 势力结构\n- 至少三方势力\n- 各有自己的利益和目标\n- 互相牵制',
          coreConflict: '主角想在不被注意的情况下达成自己的目标，但多方势力都在盯着，必须步步为营，稍有不慎就万劫不复。',
          protagonistSeed: '主角原本只是想过普通生活，但被卷入了一个各方博弈的局里，只能用智商破局。',
          uniqueSettings: '- 没有绝对强者\n- 信息是武器\n- 反转不断',
          readerPromise: '看主角如何用智商周旋于多方势力之间，步步为营，每个反转都让你大呼过瘾。',
          titleOptions: [titleBase, '我在规则边缘布局', '异常博弈者'],
          genreOptions: const ['智斗 / 布局流', '悬疑奇幻', '规则怪谈'],
          styleTemplates: const [
            '智斗为主，不搞无脑升级，每个伏笔都要回收。',
            '反转不断，但逻辑自洽，所有布局都有迹可循。',
            '信息分层释放，逐步揭开世界真相。',
          ],
        ),
        WorldOption(
          id: 'option-3',
          title: '🌙 温情路线',
          expandedInspiration: '$clean\n\n这个灵感可以扩展成一部温情小说：主角卷入异常世界，但是用温柔和善意改变了冰冷的规则，治愈自己也治愈别人。',
          worldview: '# 世界观草案\n\n## 世界底层规则\n- 规则冰冷但有温度\n- 善意也能成为力量\n- 人情世故是另一种博弈\n\n## 势力结构\n- 有坏人也有好人\n- 每个人都有自己的故事\n- 世界不是非黑即白',
          coreConflict: '主角想用自己的方式解决问题，但旧规则不相信温情，主角必须证明自己的方式也能行。',
          protagonistSeed: '主角只是个普通人，但比别人多了一点耐心和善意，这成为了他最大的武器。',
          uniqueSettings: '- 温情但不圣母\n- 每个人都有故事\n- 治愈为主爽点为辅',
          readerPromise: '看主角如何用温柔的方式改变冰冷的世界，治愈角色也治愈读者。',
          titleOptions: [titleBase, '我在异常世界送温暖', '规则之外的善意'],
          genreOptions: const ['温情 / 治愈流', '日常系', '轻松温馨'],
          styleTemplates: const [
            '节奏稍慢但有温度，人物有血有肉。',
            '不刻意制造冲突，让故事自然流淌。',
            '用小细节打动人，温情但不煽情。',
          ],
        ),
      ],
    );
  }
}

class WorldOption {
  const WorldOption({
    required this.id,
    required this.title,
    required this.expandedInspiration,
    required this.worldview,
    required this.coreConflict,
    required this.protagonistSeed,
    required this.uniqueSettings,
    required this.readerPromise,
    required this.titleOptions,
    required this.genreOptions,
    required this.styleTemplates,
  });

  final String id;
  final String title;
  final String expandedInspiration;
  final String worldview;
  final String coreConflict;
  final String protagonistSeed;
  final String uniqueSettings;
  final String readerPromise;
  final List<String> titleOptions;
  final List<String> genreOptions;
  final List<String> styleTemplates;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'expandedInspiration': expandedInspiration,
      'worldview': worldview,
      'coreConflict': coreConflict,
      'protagonistSeed': protagonistSeed,
      'uniqueSettings': uniqueSettings,
      'readerPromise': readerPromise,
      'titleOptions': titleOptions,
      'genreOptions': genreOptions,
      'styleTemplates': styleTemplates,
    };
  }

  factory WorldOption.fromJson(Map<String, dynamic> json) {
    String read(String key, String fallback) {
      final value = json[key];
      if (value is String && value.trim().isNotEmpty) return value.trim();
      return fallback;
    }

    List<String> readList(String key, List<String> fallback) {
      final value = json[key];
      if (value is List) {
        final items = value
            .map((item) => item.toString().trim())
            .where((item) => item.isNotEmpty)
            .toList();
        if (items.isNotEmpty) return items.take(8).toList();
      }
      return fallback;
    }

    return WorldOption(
      id: json['id'] as String? ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: read('title', '世界观方案'),
      expandedInspiration: read('expandedInspiration', '一个普通人卷入异常世界。'),
      worldview: read('worldview', '# 世界观草案\n\n## 基础规则\n\n## 势力结构'),
      coreConflict: read('coreConflict', '主角想解决眼前危机，但旧秩序不允许新变量出现。'),
      protagonistSeed: read('protagonistSeed', '主角原本是普通人，被迫成为规则漏洞中的临时执行者。'),
      uniqueSettings: read('uniqueSettings', '- 规则有代价\n- 能力有边界'),
      readerPromise: read('readerPromise', '看主角用新方法拆解旧秩序，持续制造爽点和悬念。'),
      titleOptions: readList('titleOptions', const ['临时代理人', '规则之外', '异常上任']),
      genreOptions: readList('genreOptions', const ['都市脑洞 / 长篇爽文', '悬疑奇幻 / 规则怪谈', '轻松吐槽 / 职场升级']),
      styleTemplates: readList('styleTemplates', const [
        '快节奏、强冲突、手机端易读，每章结尾有追读钩子。',
        '轻松吐槽、爽点明确，对话有梗但不破坏紧张感。',
        '悬疑感更强，信息分层释放，结尾保留未解谜团。',
      ]),
    );
  }
}

class InspirationWorldSeed {
  const InspirationWorldSeed({
    required this.expandedInspiration,
    required this.worldview,
    required this.coreConflict,
    required this.protagonistSeed,
    required this.uniqueSettings,
    required this.readerPromise,
    required this.titleOptions,
    required this.genreOptions,
    required this.styleTemplates,
    required this.nextStepHint,
    this.options = const [],
  });

  final String expandedInspiration;
  final String worldview;
  final String coreConflict;
  final String protagonistSeed;
  final String uniqueSettings;
  final String readerPromise;
  final List<String> titleOptions;
  final List<String> genreOptions;
  final List<String> styleTemplates;
  final String nextStepHint;
  final List<WorldOption> options;

  Map<String, dynamic> toJson() {
    return {
      'expandedInspiration': expandedInspiration,
      'worldview': worldview,
      'coreConflict': coreConflict,
      'protagonistSeed': protagonistSeed,
      'uniqueSettings': uniqueSettings,
      'readerPromise': readerPromise,
      'titleOptions': titleOptions,
      'genreOptions': genreOptions,
      'styleTemplates': styleTemplates,
      'nextStepHint': nextStepHint,
    };
  }

  InspirationWorldSeed copyWith({
    String? expandedInspiration,
    String? worldview,
    String? coreConflict,
    String? protagonistSeed,
    String? uniqueSettings,
    String? readerPromise,
    List<String>? titleOptions,
    List<String>? genreOptions,
    List<String>? styleTemplates,
    String? nextStepHint,
    List<WorldOption>? options,
  }) {
    return InspirationWorldSeed(
      expandedInspiration: expandedInspiration ?? this.expandedInspiration,
      worldview: worldview ?? this.worldview,
      coreConflict: coreConflict ?? this.coreConflict,
      protagonistSeed: protagonistSeed ?? this.protagonistSeed,
      uniqueSettings: uniqueSettings ?? this.uniqueSettings,
      readerPromise: readerPromise ?? this.readerPromise,
      titleOptions: titleOptions ?? this.titleOptions,
      genreOptions: genreOptions ?? this.genreOptions,
      styleTemplates: styleTemplates ?? this.styleTemplates,
      nextStepHint: nextStepHint ?? this.nextStepHint,
      options: options ?? this.options,
    );
  }

  factory InspirationWorldSeed.fromOption(WorldOption option) {
    return InspirationWorldSeed(
      expandedInspiration: option.expandedInspiration,
      worldview: option.worldview,
      coreConflict: option.coreConflict,
      protagonistSeed: option.protagonistSeed,
      uniqueSettings: option.uniqueSettings,
      readerPromise: option.readerPromise,
      titleOptions: option.titleOptions,
      genreOptions: option.genreOptions,
      styleTemplates: option.styleTemplates,
      nextStepHint: '已选择 ${option.title}，现在确认世界观后创建小说。',
      options: [option],
    );
  }

  factory InspirationWorldSeed.fromJson(Map<String, dynamic> json) {
    String read(String key, String fallback) {
      final value = json[key];
      if (value is String && value.trim().isNotEmpty) return value.trim();
      if (value is List) {
        final text = value.map((item) => '- $item').join('\n').trim();
        if (text.isNotEmpty) return text;
      }
      if (value is Map) {
        final text = value.entries.map((entry) => '## ${entry.key}\n${entry.value}').join('\n\n').trim();
        if (text.isNotEmpty) return text;
      }
      return fallback;
    }

    List<String> readList(String key, List<String> fallback) {
      final value = json[key];
      if (value is List) {
        final items = value
            .map((item) => item.toString().trim())
            .where((item) => item.isNotEmpty)
            .toList();
        if (items.isNotEmpty) return items.take(8).toList();
      }
      if (value is String && value.trim().isNotEmpty) {
        final items = value
            .split(RegExp(r'[\n,，；;]+'))
            .map((item) => item.replaceFirst(RegExp(r'^[-*\d.、\s]+'), '').trim())
            .where((item) => item.isNotEmpty)
            .toList();
        if (items.isNotEmpty) return items.take(8).toList();
      }
      return fallback;
    }

    List<WorldOption> readOptions(String key, List<WorldOption> fallback) {
      final value = json[key];
      if (value is List) {
        return value
            .whereType<Map<String, dynamic>>()
            .map(WorldOption.fromJson)
            .toList();
      }
      return fallback;
    }

    return InspirationWorldSeed(
      expandedInspiration: read('expandedInspiration', '一个普通人卷入异常世界，并尝试改写旧规则。'),
      worldview: read('worldview', '# 世界观草案\n\n## 基础规则\n\n## 势力结构\n\n## 代价与限制'),
      coreConflict: read('coreConflict', '主角想解决眼前危机，但旧秩序不允许新的变量出现。'),
      protagonistSeed: read('protagonistSeed', '主角原本是普通人，被迫成为规则漏洞中的临时执行者。'),
      uniqueSettings: read('uniqueSettings', '- 规则有代价\n- 能力有边界\n- 每章都要推进一个未解决问题'),
      readerPromise: read('readerPromise', '看主角用新方法拆解旧秩序，持续制造爽点和悬念。'),
      titleOptions: readList('titleOptions', const ['临时代理人', '规则之外', '异常上任']),
      genreOptions: readList('genreOptions', const ['都市脑洞 / 长篇爽文', '悬疑奇幻 / 规则怪谈', '轻松吐槽 / 职场升级']),
      styleTemplates: readList('styleTemplates', const [
        '快节奏、强冲突、手机端易读，每章结尾有追读钩子。',
        '轻松吐槽、爽点明确，对话有梗但不破坏紧张感。',
        '悬疑感更强，信息分层释放，结尾保留未解谜团。',
      ]),
      nextStepHint: read('nextStepHint', '确认世界观后，选择书名、类型和文风，再生成剩余小说资料。'),
      options: readOptions('options', const []),
    );
  }
}

class InspirationBookDraft {
  const InspirationBookDraft({
    required this.title,
    required this.genre,
    required this.description,
    required this.sellingPoints,
    required this.worldview,
    required this.characters,
    required this.outline,
    required this.foreshadowing,
    required this.timeline,
    required this.lockedSettings,
    required this.styleTemplate,
    required this.chapterCards,
    required this.firstChapterTitle,
    required this.firstChapterContent,
    required this.incubationReport,
  });

  final String title;
  final String genre;
  final String description;
  final String sellingPoints;
  final String worldview;
  final String characters;
  final String outline;
  final String foreshadowing;
  final String timeline;
  final String lockedSettings;
  final String styleTemplate;
  final String chapterCards;
  final String firstChapterTitle;
  final String firstChapterContent;
  final String incubationReport;

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'genre': genre,
      'description': description,
      'sellingPoints': sellingPoints,
      'worldview': worldview,
      'characters': characters,
      'outline': outline,
      'foreshadowing': foreshadowing,
      'timeline': timeline,
      'lockedSettings': lockedSettings,
      'styleTemplate': styleTemplate,
      'chapterCards': chapterCards,
      'firstChapterTitle': firstChapterTitle,
      'firstChapterContent': firstChapterContent,
      'incubationReport': incubationReport,
    };
  }

  factory InspirationBookDraft.fromJson(Map<String, dynamic> json) {
    String read(String key, String fallback) {
      final value = json[key];
      if (value is String && value.trim().isNotEmpty) return value.trim();
      if (value is List) {
        final text = value.map((item) => '- $item').join('\n').trim();
        if (text.isNotEmpty) return text;
      }
      if (value is Map) {
        final text = value.entries.map((entry) => '## ${entry.key}\n${entry.value}').join('\n\n').trim();
        if (text.isNotEmpty) return text;
      }
      return fallback;
    }

    final title = read('title', '未命名灵感小说');
    return InspirationBookDraft(
      title: title,
      genre: read('genre', '长篇小说'),
      description: read('description', '由灵感孵化生成的小说。'),
      sellingPoints: read('sellingPoints', '# 核心卖点\n\n- 独特设定\n- 明确冲突\n- 连载追读钩子'),
      worldview: read('worldview', '# 世界观\n\n## 基础规则\n\n## 地点与势力\n\n## 限制与代价'),
      characters: read('characters', '# 人物库\n\n## 主角\n\n## 配角\n\n## 反派'),
      outline: read('outline', '# 大纲\n\n## 主线\n\n## 阶段目标\n\n## 结局方向'),
      foreshadowing: read('foreshadowing', '# 伏笔库\n\n| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |\n|---|---|---|---|---|'),
      timeline: read('timeline', '# 时间线\n\n- 故事开端：'),
      lockedSettings: read('lockedSettings', '# 禁止改动设定\n\n- 主角核心身份：\n- 金手指/能力限制：\n- 世界底层规则：'),
      styleTemplate: read('styleTemplate', '# 文风模板\n\n## 叙事语气\n\n## 节奏要求\n\n## 对话风格'),
      chapterCards: read('chapterCards', '# 章节卡片\n\n## 第1章\n\n## 第2章\n\n## 第3章'),
      firstChapterTitle: read('firstChapterTitle', '第1章'),
      firstChapterContent: read('firstChapterContent', ''),
      incubationReport: read('incubationReport', '# 灵感孵化报告\n\n已根据灵感生成小说基础资料和第一章草稿。'),
    );
  }
}
