import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/inspiration_book_draft.dart';
import 'app_settings.dart';

class AiInspirationService {
  final AppSettings settings;

  AiInspirationService(this.settings);

  Future<InspirationWorldSeed> buildWorldFromInspiration({
    required String inspiration,
  }) async {
    if (!settings.hasAiApiKey) {
      return _localWorldSeed(inspiration);
    }

    final systemPrompt = '''你是专业的小说世界观构建助手。请根据作者的原始灵感，构建一个完整的世界观草案。

要求：
1. 构建的世界观要能支撑至少 100 万字的长篇小说
2. 包含：完整故事概念、世界观设定、核心冲突、主角种子、独特设定、读者承诺
3. 提供 5 个候选书名、3 个类型候选、3 个文风模板候选
4. 请输出严格的 JSON 格式，不要使用 Markdown 代码围栏

JSON 格式：
{
  "expandedInspiration": "把原始灵感扩展成完整故事概念",
  "worldview": "# 世界观草案\\n## 世界底层规则\\n...",
  "coreConflict": "核心冲突描述",
  "protagonistSeed": "主角种子描述",
  "uniqueSettings": "独特设定描述",
  "readerPromise": "给读者的承诺",
  "titleOptions": ["书名1", "书名2", "书名3", "书名4", "书名5"],
  "genreOptions": ["类型1", "类型2", "类型3"],
  "styleTemplates": ["文风1", "文风2", "文风3"],
  "nextStepHint": "提示用户确认世界观"
}''';

    final userPrompt = '''原始灵感：$inspiration''';

    try {
      final response = await http.post(
        Uri.parse('${settings.aiBaseUrl}/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${settings.aiApiKey}',
        },
        body: jsonEncode({
          'model': settings.aiModel.trim().isEmpty ? 'gpt-4o-mini' : settings.aiModel.trim(),
          'messages': [
            {'role': 'system', 'content': systemPrompt},
            {'role': 'user', 'content': userPrompt},
          ],
          'temperature': settings.aiTemperature.clamp(0.0, 1.5).toDouble(),
          'max_tokens': 3200,
        }),
      ).timeout(const Duration(seconds: 60));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('AI request failed: HTTP ${response.statusCode}');
      }

      final decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      final choices = decoded['choices'] as List?;
      if (choices != null && choices.isNotEmpty) {
        final first = choices.first as Map<String, dynamic>;
        final message = first['message'] as Map<String, dynamic>?;
        if (message != null && message['content'] is String) {
          final content = message['content'] as String;
          try {
            final extracted = _extractJsonObject(content);
            if (extracted != null) {
              return InspirationWorldSeed.fromJson(extracted);
            }
          } catch (_) {}
        }
      }
      return _localWorldSeed(inspiration);
    } catch (_) {
      return _localWorldSeed(inspiration);
    }
  }

  Map<String, dynamic>? _extractJsonObject(String content) {
    var text = content.trim();
    if (text.startsWith('```json')) {
      text = text.replaceFirst(RegExp(r'^```json\s*'), '');
    } else if (text.startsWith('```')) {
      text = text.replaceFirst(RegExp(r'^```\s*'), '');
    }
    text = text.replaceFirst(RegExp(r'\s*```\s*$'), '');
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start >= 0 && end > start) {
      try {
        return jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
      } catch (_) {}
    }
    return null;
  }

  Future<GachaResult> gachaWorldOptions(String inspiration) async {
    return GachaResult.fromLocal(inspiration);
  }

  InspirationWorldSeed _localWorldSeed(String inspiration) {
    final clean = inspiration.trim().isEmpty
        ? '一个普通人卷入异常世界，并用自己的方式改变规则'
        : inspiration.trim();
    final titleBase = _guessTitle(clean);
    return InspirationWorldSeed(
      expandedInspiration: '''$clean

这个灵感可以扩展成一部长篇小说：主角最初只是被异常事件推到规则边缘，他以为只要完成一次任务就能回到普通生活，却发现事件背后存在一套完整的隐藏秩序。旧势力依赖这套秩序维持利益，普通人只能在规则的缝隙中承受后果。主角的优势不是天生无敌，而是能用现实经验、观察力和不走寻常路的解决方式来拆解旧规则。随着一次次处理事件，他逐渐从"被选中的临时变量"成长为能够重新制定边界的人。''',
      worldview: '''# 世界观草案

## 世界底层规则

- 现实世界之外存在一套隐藏秩序，普通人通常看不见，只能感受到异常后果
- 隐藏秩序并非全知全能，它依赖执行者、契约、档案、权限和代价运转
- 主角进入系统后，既能借用部分权限，也会被旧规则追责

## 现实侧/隐秘侧

- 现实侧：主角的生活、工作、亲友关系，是情感牵引和危机外溢的来源
- 隐秘侧：规则执行机构、旧势力、漏洞商人、被规则压制的人
- 缝隙地带：两套秩序的交界处，最容易产生案件、交易、反转和伏笔

## 势力结构

- 旧规则维护者：强调稳定，反感主角这种新变量
- 漏洞利用者：利用规则缺陷牟利，是前中期持续冲突来源
- 中立观察者：知道真相但不站队，可作为信息源和潜在反转点
- 主角阵营：从单人应对逐渐发展成小团队

## 代价与限制

- 代价可以是记忆、时间、人情债、身份暴露、现实关系受损或被旧势力标记
- 关键信息不能凭空获得，必须通过行动、交换、推理或牺牲才能得到
- 主角不能长期逃避现实侧的牵挂，否则人物会失去情感锚点

## 长篇扩展空间

- 单章案件：每章解决一个具体问题
- 卷级矛盾：每卷揭开一个更大的规则漏洞
- 主线真相：主角为什么被选中、原执行者为何失踪、旧秩序是否必须被取代''',
      coreConflict: '主角想要先自保并保护身边人，但旧秩序要求所有变量服从既有规则；主角每次用新方法解决问题，都会暴露更深层的漏洞，也会被更强的势力盯上。',
      protagonistSeed: '主角原本是普通人，擅长从现实经验中寻找规则漏洞。优点是冷静、会观察、不盲从权威；缺点是早期经验不足，容易低估隐秘世界的代价。成长线是从被迫接单，到主动制定规则。',
      uniqueSettings: '''- 用现实逻辑拆解隐藏秩序，而不是单纯打怪升级
- 每个案件都暴露一个规则漏洞，既有爽点也有主线推进
- 能力必须付出代价，避免无脑碾压
- 现实牵挂和隐秘任务互相挤压，制造长篇张力
- 旧秩序不是纯反派，它有存在理由，方便后期反转''',
      readerPromise: '看主角用新规则撬动旧秩序，在一个个案件中升级、破局、揭开真相。',
      titleOptions: [
        titleBase,
        '我在异常世界当代理人',
        '临时规则执行官',
        '规则之外的代理人',
        '旧秩序维修手册'
      ],
      genreOptions: const [
        '都市脑洞 / 长篇爽文',
        '悬疑奇幻 / 规则怪谈',
        '轻松吐槽 / 职场升级'
      ],
      styleTemplates: const [
        '快节奏、强冲突、手机端易读；每章解决一个具体问题，结尾留下更大悬念。',
        '轻松吐槽、爽点明确；对话有现代感，主角用现实规则反制旧秩序。',
        '悬疑氛围更强；信息分层释放，世界真相逐步揭开，避免过早解释全部设定。'
      ],
      nextStepHint: '先确认世界观是否满意；满意后选择书名、类型和文风模板，再创建人物库、大纲、章节卡和开篇。',
    );
  }

  String _guessTitle(String inspiration) {
    final clean = inspiration.trim();
    if (clean.isEmpty) return '临时代理人';
    if (clean.length <= 8) return clean;
    final firstPart = clean.substring(0, 8);
    return '$firstPart…';
  }
}
