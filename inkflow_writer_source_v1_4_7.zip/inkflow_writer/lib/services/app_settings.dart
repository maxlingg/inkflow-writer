import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  static const _themeModeKey = 'themeMode';
  static const _editorFontSizeKey = 'editorFontSize';
  static const _legacyAiApiKeyKey = 'aiApiKey';
  static const _aiApiKeySecureKey = 'aiApiKey.v2.secure';
  static const _aiBaseUrlKey = 'aiBaseUrl';
  static const _aiModelKey = 'aiModel';
  static const _systemPromptKey = 'systemPromptV1';
  static const _aiTemperatureKey = 'aiTemperature';
  static const _contextAutoCleanupEnabledKey = 'contextAutoCleanupEnabled';
  static const _contextCleanupThresholdTokensKey = 'contextCleanupThresholdTokens';
  static const _distillMemoryEnabledKey = 'distillMemoryEnabled';
  static const _distillTriggerTokensKey = 'distillTriggerTokens';
  static const _distillTargetTokensKey = 'distillTargetTokens';

  static const _secureStorage = FlutterSecureStorage();

  static const defaultSystemPrompt = '''你是墨舟写作的中文长篇小说 AI 助手，擅长网文、长篇连载、章节规划、人物弧光、世界观设定和正文修订。

工作原则：
1. 先尊重作者已有设定，再提出扩展。
2. 正文生成要能直接粘贴进章节，不要解释过程。
3. 规划类输出要结构清晰，包含目标、冲突、转折、钩子。
4. 修订类要尽量保留作者原意和人物关系。
5. 发现设定矛盾时先提示矛盾，再给解决方案。
6. 不要替作者强行决定风格；需要时给 2-3 个可选方向。
7. 长篇模式下必须维护小说大脑：人物库、世界观、大纲、章节摘要、伏笔库、时间线、禁止改动设定和文风模板。
8. 生成正文前优先生成章节卡；写完正文后要总结归档，并检查人物、设定、伏笔和文风是否一致。''';

  ThemeMode _themeMode = ThemeMode.system;
  double _editorFontSize = 18;
  String _aiApiKey = '';
  String _aiBaseUrl = 'https://api.openai.com/v1';
  String _aiModel = 'gpt-4o-mini';
  String _systemPrompt = defaultSystemPrompt;
  double _aiTemperature = 1.0;
  bool _contextAutoCleanupEnabled = true;
  int _contextCleanupThresholdTokens = 200000;
  bool _distillMemoryEnabled = true;
  int _distillTriggerTokens = 60000;
  int _distillTargetTokens = 4000;

  SharedPreferences? _prefs;
  Completer<void>? _prefsCompleter;

  ThemeMode get themeMode => _themeMode;
  double get editorFontSize => _editorFontSize;
  String get aiApiKey => _aiApiKey;
  String get aiBaseUrl => _aiBaseUrl;
  String get aiModel => _aiModel;
  String get systemPrompt => _systemPrompt;
  double get aiTemperature => _aiTemperature;
  bool get contextAutoCleanupEnabled => _contextAutoCleanupEnabled;
  int get contextCleanupThresholdTokens => _contextCleanupThresholdTokens;
  bool get distillMemoryEnabled => _distillMemoryEnabled;
  int get distillTriggerTokens => _distillTriggerTokens;
  int get distillTargetTokens => _distillTargetTokens;
  bool get hasAiApiKey => _aiApiKey.trim().isNotEmpty;

  Future<SharedPreferences> _ensurePrefs() async {
    if (_prefs != null) return _prefs!;
    _prefsCompleter ??= Completer<void>();
    _prefs = await SharedPreferences.getInstance();
    _prefsCompleter!.complete();
    return _prefs!;
  }

  Future<void> load() async {
    final prefs = await _ensurePrefs();
    _themeMode = _themeModeFromString(prefs.getString(_themeModeKey));
    _editorFontSize = (prefs.getDouble(_editorFontSizeKey) ?? 18).clamp(14, 28).toDouble();
    _aiApiKey = await _loadSecureApiKey(prefs);
    _aiBaseUrl = prefs.getString(_aiBaseUrlKey) ?? _aiBaseUrl;
    _aiModel = prefs.getString(_aiModelKey) ?? _aiModel;
    _systemPrompt = prefs.getString(_systemPromptKey) ?? defaultSystemPrompt;
    _aiTemperature = (prefs.getDouble(_aiTemperatureKey) ?? 1.0).clamp(0.0, 1.5).toDouble();
    _contextAutoCleanupEnabled = prefs.getBool(_contextAutoCleanupEnabledKey) ?? true;
    _contextCleanupThresholdTokens = (prefs.getInt(_contextCleanupThresholdTokensKey) ?? 200000).clamp(4000, 1000000).toInt();
    _distillMemoryEnabled = prefs.getBool(_distillMemoryEnabledKey) ?? true;
    _distillTriggerTokens = (prefs.getInt(_distillTriggerTokensKey) ?? 60000).clamp(4000, 1000000).toInt();
    _distillTargetTokens = (prefs.getInt(_distillTargetTokensKey) ?? 4000).clamp(800, 64000).toInt();
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    if (_themeMode == mode) return;
    _themeMode = mode;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setString(_themeModeKey, mode.name);
  }

  Future<void> setEditorFontSize(double size) async {
    final nextSize = size.clamp(14, 28).toDouble();
    if (_editorFontSize == nextSize) return;
    _editorFontSize = nextSize;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setDouble(_editorFontSizeKey, nextSize);
  }

  Future<void> setAiApiKey(String value) async {
    _aiApiKey = value.trim();
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.remove(_legacyAiApiKeyKey);
    if (_aiApiKey.isEmpty) {
      await _secureStorage.delete(key: _aiApiKeySecureKey);
    } else {
      await _secureStorage.write(key: _aiApiKeySecureKey, value: _aiApiKey);
    }
  }

  Future<String> _loadSecureApiKey(SharedPreferences prefs) async {
    final secureKey = await _secureStorage.read(key: _aiApiKeySecureKey);
    if (secureKey != null && secureKey.trim().isNotEmpty) return secureKey.trim();

    final legacyKey = prefs.getString(_legacyAiApiKeyKey);
    if (legacyKey != null && legacyKey.trim().isNotEmpty) {
      final trimmed = legacyKey.trim();
      await _secureStorage.write(key: _aiApiKeySecureKey, value: trimmed);
      await prefs.remove(_legacyAiApiKeyKey);
      return trimmed;
    }

    await prefs.remove(_legacyAiApiKeyKey);
    return '';
  }

  Future<void> setAiBaseUrl(String value) async {
    final next = value.trim().isEmpty ? 'https://api.openai.com/v1' : value.trim();
    _aiBaseUrl = next.replaceAll(RegExp(r'/+$'), '');
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setString(_aiBaseUrlKey, _aiBaseUrl);
  }

  Future<void> setAiModel(String value) async {
    _aiModel = value.trim().isEmpty ? 'gpt-4o-mini' : value.trim();
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setString(_aiModelKey, _aiModel);
  }

  Future<void> setAiTemperature(double value) async {
    final next = value.clamp(0.0, 1.5).toDouble();
    _aiTemperature = double.parse(next.toStringAsFixed(2));
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setDouble(_aiTemperatureKey, _aiTemperature);
  }

  Future<void> setContextAutoCleanupEnabled(bool value) async {
    _contextAutoCleanupEnabled = value;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setBool(_contextAutoCleanupEnabledKey, value);
  }

  Future<void> setContextCleanupThresholdTokens(int value) async {
    final next = value.clamp(4000, 1000000).toInt();
    _contextCleanupThresholdTokens = next;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setInt(_contextCleanupThresholdTokensKey, next);
  }

  Future<void> setDistillMemoryEnabled(bool value) async {
    _distillMemoryEnabled = value;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setBool(_distillMemoryEnabledKey, value);
  }

  Future<void> setDistillTriggerTokens(int value) async {
    final next = value.clamp(4000, 1000000).toInt();
    _distillTriggerTokens = next;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setInt(_distillTriggerTokensKey, next);
  }

  Future<void> setDistillTargetTokens(int value) async {
    final next = value.clamp(800, 64000).toInt();
    _distillTargetTokens = next;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setInt(_distillTargetTokensKey, next);
  }

  Future<void> resetAiParameters() async {
    _aiTemperature = 1.0;
    _contextAutoCleanupEnabled = true;
    _contextCleanupThresholdTokens = 200000;
    _distillMemoryEnabled = true;
    _distillTriggerTokens = 60000;
    _distillTargetTokens = 4000;
    notifyListeners();
    final prefs = await _ensurePrefs();
    await Future.wait([
      prefs.setDouble(_aiTemperatureKey, _aiTemperature),
      prefs.setBool(_contextAutoCleanupEnabledKey, _contextAutoCleanupEnabled),
      prefs.setInt(_contextCleanupThresholdTokensKey, _contextCleanupThresholdTokens),
      prefs.setBool(_distillMemoryEnabledKey, _distillMemoryEnabled),
      prefs.setInt(_distillTriggerTokensKey, _distillTriggerTokens),
      prefs.setInt(_distillTargetTokensKey, _distillTargetTokens),
    ]);
  }

  Future<void> setSystemPrompt(String value) async {
    _systemPrompt = value.trim().isEmpty ? defaultSystemPrompt : value.trim();
    notifyListeners();
    final prefs = await _ensurePrefs();
    await prefs.setString(_systemPromptKey, _systemPrompt);
  }

  Future<void> resetSystemPrompt() => setSystemPrompt(defaultSystemPrompt);

  ThemeMode _themeModeFromString(String? value) {
    return switch (value) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
  }
}
