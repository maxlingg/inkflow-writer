import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:charset_converter/charset_converter.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/writing_project.dart';
import '../services/storage_service.dart';

class TxtBookImportScreen extends StatefulWidget {
  const TxtBookImportScreen({super.key});

  @override
  State<TxtBookImportScreen> createState() => _TxtBookImportScreenState();
}

class _TxtBookImportScreenState extends State<TxtBookImportScreen> {
  final _titleController = TextEditingController();
  final _genreController = TextEditingController(text: '导入长篇');
  final _descriptionController = TextEditingController();
  final _ruleController = TextEditingController(
    text: r'^\s*(第\s*[0-9零〇一二两三四五六七八九十百千万]+\s*[章节卷回篇]|Chapter\s+\d+|CHAPTER\s+\d+)\s*[^\n]{0,80}$',
  );
  final _chunkSizeController = TextEditingController(text: '6000');

  String? _filePath;
  String? _fileName;
  String _rawText = '';
  List<_SplitChapter> _chapters = const [];
  _SplitMode _mode = _SplitMode.heading;
  _TextEncoding _encoding = _TextEncoding.auto;
  bool _loading = false;
  bool _creating = false;
  String _message = '';

  @override
  void dispose() {
    _titleController.dispose();
    _genreController.dispose();
    _descriptionController.dispose();
    _ruleController.dispose();
    _chunkSizeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('拆 TXT 小书'),
        actions: [
          IconButton(
            tooltip: '复制默认规则',
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: _ruleController.text));
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('拆章规则已复制')),
                );
              }
            },
            icon: const Icon(Icons.copy_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 26),
        children: [
          _IntroCard(onPick: _pickFile),
          const SizedBox(height: 14),
          if (_fileName != null) _FileCard(fileName: _fileName!, filePath: _filePath ?? '', chars: _rawText.length),
          if (_fileName != null) ...[
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: DropdownButtonFormField<_TextEncoding>(
                  value: _encoding,
                  decoration: const InputDecoration(labelText: '文本编码'),
                  items: _TextEncoding.values
                      .map((encoding) => DropdownMenuItem(value: encoding, child: Text(encoding.label)))
                      .toList(),
                  onChanged: _loading
                      ? null
                      : (value) async {
                          if (value == null) return;
                          setState(() => _encoding = value);
                          await _reloadPickedFile();
                        },
                ),
              ),
            ),
            const SizedBox(height: 14),
          ],
          _SectionTitle(title: '小说信息'),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                    controller: _titleController,
                    decoration: const InputDecoration(labelText: '小说名'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _genreController,
                    decoration: const InputDecoration(labelText: '类型'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _descriptionController,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(labelText: '简介 / 来源说明'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          _SectionTitle(title: '拆分方式'),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedButton<_SplitMode>(
                    segments: const [
                      ButtonSegment(
                        value: _SplitMode.heading,
                        icon: Icon(Icons.title_rounded),
                        label: Text('按章节标题'),
                      ),
                      ButtonSegment(
                        value: _SplitMode.length,
                        icon: Icon(Icons.cut_rounded),
                        label: Text('按字数切分'),
                      ),
                    ],
                    selected: {_mode},
                    onSelectionChanged: (values) {
                      setState(() => _mode = values.first);
                      _previewSplit();
                    },
                  ),
                  const SizedBox(height: 14),
                  if (_mode == _SplitMode.heading) ...[
                    TextField(
                      controller: _ruleController,
                      minLines: 3,
                      maxLines: 5,
                      decoration: const InputDecoration(
                        labelText: '章节标题正则',
                        helperText: '默认识别：第1章、第一章、第十回、Chapter 1 等独占一行标题。',
                      ),
                      onChanged: (_) => _previewSplit(),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '找不到章节标题时会自动按字数切分，避免导入失败。',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant),
                    ),
                  ] else ...[
                    TextField(
                      controller: _chunkSizeController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: '每章目标字数',
                        helperText: '会尽量在段落边界切开，默认 6000 字左右。',
                      ),
                      onChanged: (_) => _previewSplit(),
                    ),
                  ],
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _rawText.isEmpty || _loading ? null : _previewSplit,
                      icon: const Icon(Icons.auto_awesome_motion_rounded),
                      label: const Text('重新预览拆分'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          _SectionTitle(title: '拆分预览'),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: _loading
                  ? const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _chapters.isEmpty ? '还没有选择 TXT 文件。' : '将创建 ${_chapters.length} 个章节，共 ${_rawText.length} 字。',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        if (_message.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(_message, style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700)),
                        ],
                        const SizedBox(height: 12),
                        ..._chapters.take(20).map((chapter) => ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: CircleAvatar(
                                backgroundColor: colors.primaryContainer,
                                foregroundColor: colors.onPrimaryContainer,
                                child: Text('${chapter.index}'),
                              ),
                              title: Text(chapter.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text('${chapter.content.length} 字 · ${_previewLine(chapter.content)}', maxLines: 1, overflow: TextOverflow.ellipsis),
                            )),
                        if (_chapters.length > 20)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text('仅预览前 20 章，剩余 ${_chapters.length - 20} 章会一起导入。'),
                          ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _chapters.isEmpty || _creating ? null : _createProject,
            icon: _creating
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.library_add_check_rounded),
            label: Text(_creating ? '正在创建本地小说…' : '创建为本地小说'),
          ),
        ],
      ),
      backgroundColor: colors.surfaceContainerLowest,
    );
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['txt', 'md'],
      withData: false,
    );
    if (result == null || result.files.isEmpty) return;

    final path = result.files.single.path;
    if (path == null) return;

    setState(() {
      _loading = true;
      _message = '正在读取 TXT…';
    });

    try {
      final file = File(path);
      final bytes = await file.readAsBytes();
      final text = await _decodeText(bytes, _encoding);
      final name = result.files.single.name;
      final title = _stripExtension(name);
      _filePath = path;
      _fileName = name;
      _rawText = _normalizeText(text);
      if (_titleController.text.trim().isEmpty) _titleController.text = title;
      if (_descriptionController.text.trim().isEmpty) {
        _descriptionController.text = '从 TXT 小书导入：$name';
      }
      _previewSplit();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _message = '读取失败：$error';
      });
    }
  }

  Future<void> _reloadPickedFile() async {
    final path = _filePath;
    if (path == null || path.trim().isEmpty) return;
    setState(() {
      _loading = true;
      _message = '正在按 ${_encoding.label} 重新读取…';
    });
    try {
      final text = await _decodeText(await File(path).readAsBytes(), _encoding);
      _rawText = _normalizeText(text);
      _previewSplit();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _message = '重新读取失败：$error';
      });
    }
  }

  void _previewSplit() {
    if (_rawText.trim().isEmpty) {
      setState(() {
        _chapters = const [];
        _loading = false;
        _message = '';
      });
      return;
    }

    try {
      final chapters = _mode == _SplitMode.heading ? _splitByHeading(_rawText) : _splitByLength(_rawText);
      setState(() {
        _chapters = chapters;
        _loading = false;
        _message = _mode == _SplitMode.heading && chapters.length <= 1
            ? '章节标题识别较少，建议检查正则或改用按字数切分。'
            : '预览完成，可创建为本地小说。';
      });
    } catch (error) {
      final fallback = _splitByLength(_rawText);
      setState(() {
        _chapters = fallback;
        _loading = false;
        _message = '章节规则解析失败，已自动按字数切分：$error';
      });
    }
  }

  List<_SplitChapter> _splitByHeading(String text) {
    final pattern = _ruleController.text.trim().isEmpty
        ? r'^\s*(第\s*[0-9零〇一二两三四五六七八九十百千万]+\s*[章节卷回篇]|Chapter\s+\d+|CHAPTER\s+\d+)\s*[^\n]{0,80}$'
        : _ruleController.text.trim();
    final regex = RegExp(pattern, multiLine: true, caseSensitive: false);
    final matches = regex.allMatches(text).toList();
    if (matches.length < 2) return _splitByLength(text);

    final chapters = <_SplitChapter>[];
    final seenTitles = <String, int>{};

    final preface = text.substring(0, matches.first.start).trim();
    if (preface.length > 80) {
      chapters.add(_SplitChapter(index: chapters.length + 1, title: '序章', content: preface));
    }

    for (var i = 0; i < matches.length; i++) {
      final match = matches[i];
      var title = match.group(0)?.trim().replaceAll(RegExp(r'\s+'), ' ') ?? '第${i + 1}章';
      title = _cleanChapterTitle(title);
      final contentStart = _lineEnd(text, match.end);
      final contentEnd = i + 1 < matches.length ? matches[i + 1].start : text.length;
      final content = text.substring(contentStart, contentEnd).trim();
      final key = title;
      final duplicate = seenTitles.update(key, (value) => value + 1, ifAbsent: () => 1);
      if (duplicate > 1) title = '$title-$duplicate';
      chapters.add(_SplitChapter(index: chapters.length + 1, title: title, content: content));
    }

    return chapters.where((chapter) => chapter.title.trim().isNotEmpty || chapter.content.trim().isNotEmpty).toList();
  }

  List<_SplitChapter> _splitByLength(String text) {
    final rawTarget = int.tryParse(_chunkSizeController.text.trim()) ?? 6000;
    final target = rawTarget.clamp(1200, 30000).toInt();
    final chapters = <_SplitChapter>[];
    var cursor = 0;
    var index = 1;
    while (cursor < text.length) {
      var end = min(cursor + target, text.length);
      if (end < text.length) {
        final windowStart = max(cursor + (target * 0.55).round(), cursor);
        final splitAt = _lastParagraphBreak(text, windowStart, end);
        if (splitAt > cursor + 300) end = splitAt;
      }
      final content = text.substring(cursor, end).trim();
      if (content.isNotEmpty) {
        chapters.add(_SplitChapter(index: index, title: '第$index章', content: content));
        index += 1;
      }
      cursor = max(end, cursor + 1);
    }
    return chapters;
  }

  Future<void> _createProject() async {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先填写小说名')));
      return;
    }

    setState(() => _creating = true);
    try {
      final now = DateTime.now();
      final chapters = _chapters
          .map((chapter) => Chapter(
                id: newEntityId('chapter'),
                title: chapter.title,
                content: chapter.content,
                createdAt: now,
                updatedAt: now,
              ))
          .toList();

      final report = '''# TXT 小书导入报告

- 源文件：${_fileName ?? ''}
- 源路径：${_filePath ?? ''}
- 导入时间：${now.toIso8601String()}
- 拆分方式：${_mode == _SplitMode.heading ? '按章节标题' : '按字数切分'}
- 章节数量：${chapters.length}
- 原文长度：${_rawText.length} 字符

## 拆分规则

```text
${_mode == _SplitMode.heading ? _ruleController.text : '每章约 ${_chunkSizeController.text} 字'}
```

## 章节清单

${chapters.asMap().entries.map((entry) => '${entry.key + 1}. ${entry.value.title}（${entry.value.content.length} 字）').join('\n')}
''';

      final project = WritingProject(
        id: newEntityId('project'),
        title: title,
        description: _descriptionController.text.trim(),
        genre: _genreController.text.trim().isEmpty ? '导入长篇' : _genreController.text.trim(),
        createdAt: now,
        updatedAt: now,
        chapters: chapters,
        notes: [
          ProjectNote(
            id: newEntityId('note'),
            title: 'TXT导入报告',
            body: report,
            tag: '导入',
            createdAt: now,
            updatedAt: now,
          ),
          ProjectNote(
            id: newEntityId('note'),
            title: '原TXT信息',
            body: '# 原TXT信息\n\n- 文件名：${_fileName ?? ''}\n- 原始路径：${_filePath ?? ''}\n- 原始字符数：${_rawText.length}\n',
            tag: '导入',
            createdAt: now,
            updatedAt: now,
          ),
        ],
      );

      await StorageService.instance.upsertProject(project);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      setState(() => _creating = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('创建失败：$error')));
    }
  }

  Future<String> _decodeText(List<int> bytes, _TextEncoding encoding) async {
    if (bytes.length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) {
      return utf8.decode(bytes.sublist(3), allowMalformed: true);
    }
    if (bytes.length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE) {
      return _decodeUtf16(bytes.sublist(2), littleEndian: true);
    }
    if (bytes.length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF) {
      return _decodeUtf16(bytes.sublist(2), littleEndian: false);
    }
    if (encoding == _TextEncoding.utf8) return utf8.decode(bytes, allowMalformed: true);
    if (encoding == _TextEncoding.gb18030) return CharsetConverter.decode('gb18030', bytes);
    if (encoding == _TextEncoding.utf16) return _decodeUtf16(bytes, littleEndian: true);

    final utf8Text = utf8.decode(bytes, allowMalformed: true);
    if (_looksReadable(utf8Text)) return utf8Text;
    try {
      final gbText = await CharsetConverter.decode('gb18030', bytes);
      if (_looksReadable(gbText)) return gbText;
    } catch (_) {}
    return utf8Text;
  }

  bool _looksReadable(String text) {
    if (text.isEmpty) return true;
    final sample = text.length > 4000 ? text.substring(0, 4000) : text;
    final replacements = RegExp('\uFFFD').allMatches(sample).length;
    return replacements <= sample.length * 0.01;
  }

  String _decodeUtf16(List<int> bytes, {required bool littleEndian}) {
    final codeUnits = <int>[];
    for (var i = 0; i + 1 < bytes.length; i += 2) {
      final value = littleEndian ? bytes[i] | (bytes[i + 1] << 8) : (bytes[i] << 8) | bytes[i + 1];
      codeUnits.add(value);
    }
    return String.fromCharCodes(codeUnits);
  }

  String _normalizeText(String text) {
    return text.replaceAll('\r\n', '\n').replaceAll('\r', '\n').replaceAll('\u{feff}', '').trim();
  }

  String _stripExtension(String name) {
    final trimmed = name.trim();
    final lower = trimmed.toLowerCase();
    for (final ext in const ['.txt', '.md']) {
      if (lower.endsWith(ext)) return trimmed.substring(0, trimmed.length - ext.length);
    }
    return trimmed;
  }

  String _cleanChapterTitle(String title) {
    final clean = title.replaceAll(RegExp(r'[\\/:*?"<>|]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.length <= 48) return clean;
    return clean.substring(0, 48).trim();
  }

  int _lineEnd(String text, int start) {
    final newline = text.indexOf('\n', start);
    if (newline == -1) return start;
    return newline + 1;
  }

  int _lastParagraphBreak(String text, int start, int end) {
    final range = text.substring(start, end);
    final doubleBreak = range.lastIndexOf('\n\n');
    if (doubleBreak != -1) return start + doubleBreak + 2;
    final singleBreak = range.lastIndexOf('\n');
    if (singleBreak != -1) return start + singleBreak + 1;
    final chinesePeriod = range.lastIndexOf('。');
    if (chinesePeriod != -1) return start + chinesePeriod + 1;
    return end;
  }

  String _previewLine(String content) {
    final text = content.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (text.length <= 30) return text;
    return '${text.substring(0, 30)}…';
  }
}

enum _TextEncoding { auto, utf8, gb18030, utf16 }

extension _TextEncodingText on _TextEncoding {
  String get label => switch (this) {
        _TextEncoding.auto => '自动识别',
        _TextEncoding.utf8 => 'UTF-8',
        _TextEncoding.gb18030 => 'GBK / GB18030',
        _TextEncoding.utf16 => 'UTF-16',
      };
}

enum _SplitMode { heading, length }

class _SplitChapter {
  const _SplitChapter({required this.index, required this.title, required this.content});

  final int index;
  final String title;
  final String content;
}

class _IntroCard extends StatelessWidget {
  const _IntroCard({required this.onPick});

  final VoidCallback onPick;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: colors.primaryContainer,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(Icons.snippet_folder_rounded, color: colors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    '把一个 TXT 小书拆成“章节内容”',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              '适合导入已有 TXT/Markdown 长文：自动识别第1章、第一章、第十回、Chapter 1 等章节标题，并保存为本地小说项目。',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: onPick,
                icon: const Icon(Icons.upload_file_rounded),
                label: const Text('选择 TXT / MD 文件'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FileCard extends StatelessWidget {
  const _FileCard({required this.fileName, required this.filePath, required this.chars});

  final String fileName;
  final String filePath;
  final int chars;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: ListTile(
        leading: Icon(Icons.description_rounded, color: colors.primary),
        title: Text(fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('$chars 字符 · $filePath', maxLines: 2, overflow: TextOverflow.ellipsis),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Text(
      '| $title',
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w900,
            color: colors.primary,
          ),
    );
  }
}
