import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:charset_converter/charset_converter.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import 'project_screen.dart';

class BookAnalysisScreen extends StatefulWidget {
  const BookAnalysisScreen({super.key, required this.settings, this.initialProject});

  final AppSettings settings;
  final WritingProject? initialProject;

  @override
  State<BookAnalysisScreen> createState() => _BookAnalysisScreenState();
}

class _BookAnalysisScreenState extends State<BookAnalysisScreen> {
  final _titleController = TextEditingController();
  final _genreController = TextEditingController(text: '拆书导入');
  final _descriptionController = TextEditingController();
  final _newBookInstructionController = TextEditingController();

  List<WritingProject> _projects = const [];
  String? _selectedProjectId;
  String? _fileName;
  String? _filePath;
  String _rawText = '';
  List<_AnalysisChapter> _importChapters = const [];
  _AnalysisDepth _depth = _AnalysisDepth.standard;
  _TextEncoding _encoding = _TextEncoding.auto;
  final Map<String, String> _reports = {};
  WritingProject? _analysisProject;
  bool _loadingProjects = true;
  bool _readingFile = false;
  bool _running = false;
  bool _creatingNewBook = false;
  int _currentModuleIndex = -1;
  String _message = '';

  @override
  void initState() {
    super.initState();
    _loadProjects();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _genreController.dispose();
    _descriptionController.dispose();
    _newBookInstructionController.dispose();
    super.dispose();
  }

  Future<void> _loadProjects() async {
    final projects = await StorageService.instance.loadProjects();
    if (!mounted) return;
    final initial = widget.initialProject;
    setState(() {
      _projects = projects;
      _selectedProjectId = initial?.id ?? _selectedProjectId;
      _loadingProjects = false;
      if (initial != null) {
        final matches = projects.where((item) => item.id == initial.id).toList();
        _analysisProject = matches.isEmpty ? initial : matches.first;
        _restoreReportsFromProject(_analysisProject);
      } else {
        final current = _selectedProject ?? _analysisProject;
        if (current != null) {
          final matches = projects.where((item) => item.id == current.id).toList();
          _analysisProject = matches.isEmpty ? current : matches.first;
          _selectedProjectId ??= _analysisProject?.id;
        }
        _restoreReportsFromProject(_analysisProject ?? _selectedProject);
      }
    });
  }

  WritingProject? get _selectedProject {
    final id = _selectedProjectId;
    if (id == null) return null;
    final matches = _projects.where((project) => project.id == id).toList();
    return matches.isEmpty ? null : matches.first;
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('拆书分析（爆款拆解）'),
        actions: [
          IconButton(
            tooltip: '重新读取小说',
            onPressed: _running ? null : _loadProjects,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
        children: [
          _IntroCard(onPickFile: _pickFile),
          const SizedBox(height: 16),
          _SectionTitle(title: '1. 选择小说'),
          const SizedBox(height: 10),
          _sourceCard(colors),
          const SizedBox(height: 18),
          _SectionTitle(title: '2. 选择分析深度'),
          const SizedBox(height: 10),
          _depthCard(colors),
          const SizedBox(height: 18),
          _SectionTitle(title: '3. 生成进度'),
          const SizedBox(height: 10),
          _progressCard(colors),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _running || _readingFile ? null : _startAnalysis,
            icon: _running
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.local_fire_department_rounded),
            label: Text(_running ? '正在拆解爆款逻辑…' : '开始拆书分析'),
          ),
          if (_reports.isNotEmpty) ...[
            const SizedBox(height: 22),
            _SectionTitle(title: '4. 拆书报告'),
            const SizedBox(height: 10),
            _reportCard(colors),
            const SizedBox(height: 14),
            FilledButton.tonalIcon(
              onPressed: _creatingNewBook ? null : _createNovelFromTemplate,
              icon: _creatingNewBook
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_fix_high_rounded),
              label: Text(_creatingNewBook ? '正在生成新书方案…' : '用此模板创作新小说'),
            ),
          ],
          if (_message.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text(_message, style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      backgroundColor: colors.surfaceContainerLowest,
    );
  }

  Widget _sourceCard(ColorScheme colors) {
    final selectedProject = _selectedProject;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_loadingProjects)
              const Center(child: Padding(padding: EdgeInsets.all(18), child: CircularProgressIndicator()))
            else ...[
              DropdownButtonFormField<String>(
                value: _selectedProjectId,
                decoration: const InputDecoration(labelText: '选择已写小说'),
                items: _projects
                    .map((project) => DropdownMenuItem(
                          value: project.id,
                          child: Text('${project.title} · ${project.totalChapters}章'),
                        ))
                    .toList(),
                onChanged: _running
                    ? null
                    : (value) {
                        setState(() {
                              _selectedProjectId = value;
                          final matches = _projects.where((project) => project.id == value).toList();
                          _analysisProject = matches.isEmpty ? null : matches.first;
                          _rawText = '';
                          _fileName = null;
                          _filePath = null;
                          _importChapters = const [];
                          _restoreReportsFromProject(_analysisProject);
                        });
                      },
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _running || _readingFile ? null : _pickFile,
                      icon: _readingFile
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.upload_file_rounded),
                      label: const Text('导入 TXT / MD 分析'),
                    ),
                  ),
                ],
              ),
            ],
            if (selectedProject != null) ...[
              const SizedBox(height: 12),
              _InfoPill(
                icon: Icons.menu_book_rounded,
                text: '当前：${selectedProject.title} · ${selectedProject.totalChapters}章 · ${selectedProject.totalCharacters}字',
              ),
            ],
            if (_fileName != null) ...[
              const SizedBox(height: 12),
              _InfoPill(
                icon: Icons.description_rounded,
                text: 'TXT：$_fileName · ${_importChapters.length}章 · ${_rawText.length}字',
              ),
              const SizedBox(height: 8),
              Text(
                _filePath ?? '',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<_TextEncoding>(
                value: _encoding,
                decoration: const InputDecoration(labelText: '文本编码'),
                items: _TextEncoding.values
                    .map((encoding) => DropdownMenuItem(value: encoding, child: Text(encoding.label)))
                    .toList(),
                onChanged: _running || _readingFile
                    ? null
                    : (value) async {
                        if (value == null) return;
                        setState(() => _encoding = value);
                        await _reloadPickedFile();
                      },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: '导入后小说名'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _genreController,
                decoration: const InputDecoration(labelText: '类型 / 赛道'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _descriptionController,
                minLines: 2,
                maxLines: 3,
                decoration: const InputDecoration(labelText: '来源说明 / 简介'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _depthCard(ColorScheme colors) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SegmentedButton<_AnalysisDepth>(
              segments: const [
                ButtonSegment(value: _AnalysisDepth.quick, icon: Icon(Icons.flash_on_rounded), label: Text('快速')),
                ButtonSegment(value: _AnalysisDepth.standard, icon: Icon(Icons.analytics_rounded), label: Text('标准')),
                ButtonSegment(value: _AnalysisDepth.deep, icon: Icon(Icons.psychology_alt_rounded), label: Text('深度')),
              ],
              selected: {_depth},
              onSelectionChanged: _running ? null : (values) => setState(() => _depth = values.first),
            ),
            const SizedBox(height: 12),
            Text(_depth.description, style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  Widget _progressCard(ColorScheme colors) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ..._bookAnalysisModules.asMap().entries.map((entry) {
              final index = entry.key;
              final module = entry.value;
              final done = _reports.containsKey(module.fileName);
              final active = _running && index == _currentModuleIndex;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor: done
                      ? colors.primary
                      : active
                          ? colors.tertiaryContainer
                          : colors.surfaceContainerHighest,
                  foregroundColor: done ? colors.onPrimary : colors.onSurfaceVariant,
                  child: done
                      ? const Icon(Icons.check_rounded)
                      : active
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : Text('${index + 1}'),
                ),
                title: Text(module.label, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(module.fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _reportCard(ColorScheme colors) {
    final project = _analysisProject;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              project == null ? '已生成 ${_reports.length} / 7 个模块。' : '已保存到《${project.title}》/小说资料/拆书分析。',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            ..._bookAnalysisModules.where((module) => _reports.containsKey(module.fileName)).map(
                  (module) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.article_rounded, color: colors.primary),
                    title: Text(module.fileName, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(_reports[module.fileName] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
                  ),
                ),
            if (project != null) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => ProjectScreen(project: project, settings: widget.settings)),
                  );
                  await _loadProjects();
                },
                icon: const Icon(Icons.folder_open_rounded),
                label: const Text('打开小说资料'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['txt', 'md'],
      withData: false,
    );
    if (result == null || result.files.isEmpty) return;
    final path = result.files.single.path;
    if (path == null) return;

    setState(() {
      _readingFile = true;
      _message = '正在读取并分章…';
    });

    try {
      final file = File(path);
      final bytes = await file.readAsBytes();
      final name = result.files.single.name;
      final text = _normalizeText(await _decodeText(bytes, _encoding));
      final chapters = _splitChapters(text);
      if (!mounted) return;
      setState(() {
        _filePath = path;
        _fileName = name;
        _rawText = text;
        _importChapters = chapters;
        _selectedProjectId = null;
        _analysisProject = null;
        _reports.clear();
        _titleController.text = _stripExtension(name);
        _descriptionController.text = '用于爆款拆书分析的 TXT/MD 导入：$name';
        _readingFile = false;
        _message = '已识别 ${chapters.length} 个章节。';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _readingFile = false;
        _message = '读取失败：$error';
      });
    }
  }

  Future<void> _startAnalysis() async {
    setState(() {
      _running = true;
      _currentModuleIndex = 0;
      _reports.clear();
      _message = '正在准备分析对象…';
    });

    try {
      var project = await _ensureAnalysisProject();
      final previousReports = <String>[];
      if (_depth == _AnalysisDepth.deep) {
        if (!mounted) return;
        setState(() {
          _currentModuleIndex = -1;
          _message = '深度模式：正在先生成章节采样摘要…';
        });
        final digest = await AiService.instance.buildBookAnalysisDigest(
          settings: widget.settings,
          project: project,
          depthLabel: _depth.label,
        );
        final normalizedDigest = _normalizeReport('章节采样摘要', digest);
        project = await StorageService.instance.saveBookAnalysisReports(
          project: project,
          reports: {'00_章节采样摘要': normalizedDigest},
        );
        previousReports.add(normalizedDigest);
      }
      for (var i = 0; i < _bookAnalysisModules.length; i += 1) {
        final module = _bookAnalysisModules[i];
        if (!mounted) return;
        setState(() {
          _currentModuleIndex = i;
          _message = '正在生成：${module.label}';
        });
        final output = await AiService.instance.runBookAnalysisModule(
          settings: widget.settings,
          project: project,
          depthLabel: _depth.label,
          depthInstruction: _depth.promptInstruction,
          moduleTitle: module.label,
          moduleTemplate: module.template,
          previousReports: previousReports,
        );
        final report = _normalizeReport(module.label, output);
        project = await StorageService.instance.saveBookAnalysisReports(
          project: project,
          reports: {module.fileName: report},
        );
        previousReports.add(report);
        if (!mounted) return;
        setState(() {
          _analysisProject = project;
          _reports[module.fileName] = report;
        });
      }
      if (!mounted) return;
      setState(() {
        _running = false;
        _currentModuleIndex = -1;
        _message = '拆书报告已保存到 小说资料/拆书分析。';
      });
      await _loadProjects();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _running = false;
        _message = '拆书分析失败：$error';
      });
    }
  }

  Future<WritingProject> _ensureAnalysisProject() async {
    final selected = _selectedProject;
    if (selected != null) {
      _analysisProject = selected;
      return selected;
    }
    if (_rawText.trim().isEmpty || _importChapters.isEmpty) {
      throw StateError('请先选择已有小说，或导入 TXT / MD。');
    }
    final now = DateTime.now();
    final chapters = _importChapters
        .map(
          (chapter) => Chapter(
            id: newEntityId('chapter'),
            title: chapter.title,
            content: chapter.content,
            createdAt: now,
            updatedAt: now,
          ),
        )
        .toList();
    final report = '''# 拆书源文件导入报告

- 源文件：${_fileName ?? ''}
- 源路径：${_filePath ?? ''}
- 导入时间：${now.toIso8601String()}
- 章节数量：${chapters.length}
- 原文长度：${_rawText.length} 字符

## 章节清单
${chapters.asMap().entries.map((entry) => '${entry.key + 1}. ${entry.value.title}（${entry.value.content.length} 字）').join('\n')}
''';
    final project = WritingProject(
      id: newEntityId('project'),
      title: _titleController.text.trim().isEmpty ? _stripExtension(_fileName ?? '拆书导入') : _titleController.text.trim(),
      description: _descriptionController.text.trim(),
      genre: _genreController.text.trim().isEmpty ? '拆书导入' : _genreController.text.trim(),
      createdAt: now,
      updatedAt: now,
      chapters: chapters,
      notes: [
        ProjectNote(
          id: newEntityId('note'),
          title: '拆书源文件导入报告',
          body: report,
          tag: '导入',
          createdAt: now,
          updatedAt: now,
        ),
      ],
    );
    await StorageService.instance.upsertProject(project);
    _analysisProject = project;
    _selectedProjectId = project.id;
    return project;
  }

  Future<void> _createNovelFromTemplate() async {
    final project = _analysisProject;
    if (project == null) {
      setState(() => _message = '请先完成拆书分析。');
      return;
    }
    final methodology = _reports['07_可复用方法论'] ?? _reportFromProject(project, '07_可复用方法论');
    if (methodology == null || methodology.trim().isEmpty) {
      setState(() => _message = '缺少 07_可复用方法论，无法生成新书模板。');
      return;
    }

    final instruction = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('用此模板创作新小说'),
        content: TextField(
          controller: _newBookInstructionController,
          minLines: 3,
          maxLines: 6,
          decoration: const InputDecoration(
            labelText: '新书方向 / 想避开的题材（可选）',
            hintText: '例如：都市异能，男频爽文，不要修仙，不要照搬原书设定。',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, _newBookInstructionController.text.trim()), child: const Text('生成')),
        ],
      ),
    );
    if (instruction == null) return;

    setState(() {
      _creatingNewBook = true;
      _message = '正在根据拆书方法论生成完整新小说资料库…';
    });

    try {
      final draft = await AiService.instance.createNovelDraftFromMethodology(
        settings: widget.settings,
        sourceProject: project,
        methodology: methodology,
        instruction: instruction,
      );
      final now = DateTime.now();
      ProjectNote note(String title, String body, String tag) => ProjectNote(
            id: newEntityId('note'),
            title: title,
            body: body,
            tag: tag,
            createdAt: now,
            updatedAt: now,
          );

      final newProject = WritingProject(
        id: newEntityId('project'),
        title: draft.title.trim().isEmpty ? '基于《${project.title}》方法论的新小说' : draft.title.trim(),
        description: draft.description,
        genre: draft.genre.trim().isEmpty ? project.genre : draft.genre.trim(),
        createdAt: now,
        updatedAt: now,
        chapters: [
          Chapter(
            id: newEntityId('chapter'),
            title: draft.firstChapterTitle.trim().isEmpty ? '第1章' : draft.firstChapterTitle.trim(),
            content: draft.firstChapterContent,
            createdAt: now,
            updatedAt: now,
          ),
        ],
        notes: [
          note('核心卖点', draft.sellingPoints, '卖点'),
          note('世界观', draft.worldview, '资料'),
          note('人物库', draft.characters, '资料'),
          note('大纲', draft.outline, '大纲'),
          note('伏笔库', draft.foreshadowing, '资料'),
          note('时间线', draft.timeline, '资料'),
          note('禁止改动设定', draft.lockedSettings, '硬设定'),
          note('文风模板', draft.styleTemplate, '文风'),
          note('章节卡片', draft.chapterCards, '章节卡'),
          note(
            '爽点公式',
            '# 爽点公式\n\n从拆书方法论提炼，写作时优先用于每章目标、压迫、反击、获得感和断章钩子。\n\n$methodology',
            'AI上下文',
          ),
          note(
            '拆书方法论注入提示词',
            '# 拆书方法论注入提示词\n\n写作时优先参考下面的方法论，但禁止照搬来源作品的人物、剧情、专有名词和标志性桥段。\n\n$methodology',
            'AI上下文',
          ),
          note(
            '原始拆书来源',
            '# 原始拆书来源\n\n- 来源作品：${project.title}\n- 来源类型：${project.genre}\n- 生成时间：${now.toIso8601String()}\n\n${draft.incubationReport}',
            '拆书分析',
          ),
        ],
      );
      await StorageService.instance.upsertProject(newProject);
      if (!mounted) return;
      setState(() {
        _creatingNewBook = false;
        _message = '新小说资料库已创建。';
      });
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ProjectScreen(project: newProject, settings: widget.settings)),
      );
      await _loadProjects();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _creatingNewBook = false;
        _message = '生成新小说失败：$error';
      });
    }
  }

  void _restoreReportsFromProject(WritingProject? project) {
    _reports.clear();
    if (project == null) return;
    for (final module in _bookAnalysisModules) {
      final report = _reportFromProject(project, module.fileName);
      if (report != null && report.trim().isNotEmpty) {
        _reports[module.fileName] = report;
      }
    }
  }

  String? _reportFromProject(WritingProject project, String fileName) {
    final expected = '拆书分析/$fileName';
    for (final note in project.notes) {
      if (note.title == expected || note.title.endsWith('/$fileName') || note.title == fileName) {
        if (note.body.trim().isNotEmpty) return note.body;
      }
    }
    return null;
  }

  Future<void> _reloadPickedFile() async {
    final path = _filePath;
    if (path == null || path.trim().isEmpty) return;
    setState(() {
      _readingFile = true;
      _message = '正在按 ${_encoding.label} 重新读取…';
    });
    try {
      final bytes = await File(path).readAsBytes();
      final text = _normalizeText(await _decodeText(bytes, _encoding));
      final chapters = _splitChapters(text);
      if (!mounted) return;
      setState(() {
        _rawText = text;
        _importChapters = chapters;
        _readingFile = false;
        _message = '已按 ${_encoding.label} 识别 ${chapters.length} 个章节。';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _readingFile = false;
        _message = '重新读取失败：$error';
      });
    }
  }

  String _normalizeReport(String title, String output) {
    final clean = output.trim();
    if (clean.startsWith('#')) return clean;
    return '# $title\n\n$clean';
  }

  List<_AnalysisChapter> _splitChapters(String text) {
    final heading = RegExp(
      r'^\s*(第\s*[0-9零〇一二两三四五六七八九十百千万]+\s*[章节卷回篇]|Chapter\s+\d+|CHAPTER\s+\d+)\s*[^\n]{0,80}$',
      multiLine: true,
    );
    final matches = heading.allMatches(text).toList();
    if (matches.length >= 2) {
      final chapters = <_AnalysisChapter>[];
      for (var i = 0; i < matches.length; i += 1) {
        final start = matches[i].start;
        final end = i + 1 < matches.length ? matches[i + 1].start : text.length;
        final titleEnd = _lineEnd(text, start);
        final title = _cleanChapterTitle(text.substring(start, min(titleEnd, end)).trim());
        final content = text.substring(titleEnd, end).trim();
        if (content.isNotEmpty) chapters.add(_AnalysisChapter(title: title.isEmpty ? '第${i + 1}章' : title, content: content));
      }
      if (chapters.isNotEmpty) return chapters;
    }
    return _splitByLength(text, target: 6000);
  }

  List<_AnalysisChapter> _splitByLength(String text, {required int target}) {
    final chapters = <_AnalysisChapter>[];
    var cursor = 0;
    var index = 1;
    while (cursor < text.length) {
      var end = min(cursor + target, text.length);
      if (end < text.length) {
        final windowStart = max(cursor + (target * 0.55).round(), cursor);
        final splitAt = _lastParagraphBreak(text, windowStart, end);
        if (splitAt > cursor + 300) end = splitAt;
      }
      final content = text.substring(cursor, end).trim();
      if (content.isNotEmpty) chapters.add(_AnalysisChapter(title: '第$index章', content: content));
      cursor = max(end, cursor + 1);
      index += 1;
    }
    return chapters;
  }

  Future<String> _decodeText(List<int> bytes, _TextEncoding encoding) async {
    if (bytes.length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) {
      return utf8.decode(bytes.sublist(3), allowMalformed: true);
    }
    if (bytes.length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE) {
      return _decodeUtf16(bytes.sublist(2), littleEndian: true);
    }
    if (bytes.length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF) {
      return _decodeUtf16(bytes.sublist(2), littleEndian: false);
    }
    if (encoding == _TextEncoding.utf8) return utf8.decode(bytes, allowMalformed: true);
    if (encoding == _TextEncoding.gb18030) return CharsetConverter.decode('gb18030', bytes);
    if (encoding == _TextEncoding.utf16) return _decodeUtf16(bytes, littleEndian: true);

    final utf8Text = utf8.decode(bytes, allowMalformed: true);
    if (_looksReadable(utf8Text)) return utf8Text;
    try {
      final gbText = await CharsetConverter.decode('gb18030', bytes);
      if (_looksReadable(gbText)) return gbText;
    } catch (_) {}
    return utf8Text;
  }

  bool _looksReadable(String text) {
    if (text.isEmpty) return true;
    final sample = text.length > 4000 ? text.substring(0, 4000) : text;
    final replacements = RegExp('\uFFFD').allMatches(sample).length;
    return replacements <= sample.length * 0.01;
  }

  String _decodeUtf16(List<int> bytes, {required bool littleEndian}) {
    final codeUnits = <int>[];
    for (var i = 0; i + 1 < bytes.length; i += 2) {
      final value = littleEndian ? bytes[i] | (bytes[i + 1] << 8) : (bytes[i] << 8) | bytes[i + 1];
      codeUnits.add(value);
    }
    return String.fromCharCodes(codeUnits);
  }

  String _normalizeText(String text) => text.replaceAll('\r\n', '\n').replaceAll('\r', '\n').replaceAll('\u{feff}', '').trim();

  String _stripExtension(String name) {
    final trimmed = name.trim();
    final lower = trimmed.toLowerCase();
    for (final ext in const ['.txt', '.md']) {
      if (lower.endsWith(ext)) return trimmed.substring(0, trimmed.length - ext.length);
    }
    return trimmed;
  }

  String _cleanChapterTitle(String title) {
    final clean = title.replaceAll(RegExp(r'[\\/:*?"<>|]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.length <= 48) return clean;
    return clean.substring(0, 48).trim();
  }

  int _lineEnd(String text, int start) {
    final newline = text.indexOf('\n', start);
    if (newline == -1) return start;
    return newline + 1;
  }

  int _lastParagraphBreak(String text, int start, int end) {
    final range = text.substring(start, end);
    final doubleBreak = range.lastIndexOf('\n\n');
    if (doubleBreak != -1) return start + doubleBreak + 2;
    final singleBreak = range.lastIndexOf('\n');
    if (singleBreak != -1) return start + singleBreak + 1;
    final chinesePeriod = range.lastIndexOf('。');
    if (chinesePeriod != -1) return start + chinesePeriod + 1;
    return end;
  }
}

enum _TextEncoding { auto, utf8, gb18030, utf16 }

extension _TextEncodingText on _TextEncoding {
  String get label => switch (this) {
        _TextEncoding.auto => '自动识别',
        _TextEncoding.utf8 => 'UTF-8',
        _TextEncoding.gb18030 => 'GBK / GB18030',
        _TextEncoding.utf16 => 'UTF-16',
      };
}

enum _AnalysisDepth { quick, standard, deep }

extension _AnalysisDepthText on _AnalysisDepth {
  String get label => switch (this) {
        _AnalysisDepth.quick => '快速',
        _AnalysisDepth.standard => '标准',
        _AnalysisDepth.deep => '深度',
      };

  String get description => switch (this) {
        _AnalysisDepth.quick => '适合快速判断一本书值不值得学，重点读开篇、主线和明显爽点。',
        _AnalysisDepth.standard => '适合常规拆书报告，平衡爆款逻辑、人物、节奏和商业化。',
        _AnalysisDepth.deep => '适合把一本书拆成可复用方法论，会尽量读取更多章节样本并结合前置报告。',
      };

  String get promptInstruction => switch (this) {
        _AnalysisDepth.quick => '输出精炼结论，少举例，多给可复用判断。',
        _AnalysisDepth.standard => '输出完整结构和关键机制，每个栏目给出可执行结论。',
        _AnalysisDepth.deep => '深入拆解底层公式，强调可迁移方法、风险边界和创作复用方案。',
      };
}

class _AnalysisModule {
  const _AnalysisModule({required this.fileName, required this.label, required this.template});

  final String fileName;
  final String label;
  final String template;
}

class _AnalysisChapter {
  const _AnalysisChapter({required this.title, required this.content});

  final String title;
  final String content;
}

const _bookAnalysisModules = <_AnalysisModule>[
  _AnalysisModule(
    fileName: '01_爆款逻辑',
    label: '顶层爆款逻辑',
    template: '''【赛道定位】
【核心标签】
【目标读者】

【差异化卖点】
【核心创新点】

【情绪价值】
【读者刚需】

【出圈传播点】''',
  ),
  _AnalysisModule(
    fileName: '02_故事结构',
    label: '故事骨架',
    template: '''主线
副线
结构四段（开端/发展/高潮/结局）

三级大纲：
- 总纲
- 分卷
- 章节节奏

伏笔体系
节奏公式''',
  ),
  _AnalysisModule(
    fileName: '03_人物系统',
    label: '人物系统',
    template: '''主角模板（标签+弧光）

配角体系
反派动机

人物关系网
情感张力

人设落地方式''',
  ),
  _AnalysisModule(
    fileName: '04_爽点系统',
    label: '钩子与爽点',
    template: '''开篇钩子类型
章节断点策略

爽点类型分布
爽点闭环结构

反转设计
悬念推进''',
  ),
  _AnalysisModule(
    fileName: '05_文风分析',
    label: '文笔与叙事',
    template: '''叙事视角
语言风格

对话密度
场景描写方式

情绪渲染方法''',
  ),
  _AnalysisModule(
    fileName: '06_商业分析',
    label: '商业化',
    template: '''平台适配
付费点设计

追更机制
IP潜力

合规分析''',
  ),
  _AnalysisModule(
    fileName: '07_可复用方法论',
    label: '最终方法论',
    template: '''可复用模板：
- 人设模板
- 开篇公式
- 爽点公式
- 大纲结构

读者需求总结

避坑指南

👉 你的专属创作方案（重点）''',
  ),
];

class _IntroCard extends StatelessWidget {
  const _IntroCard({required this.onPickFile});

  final VoidCallback onPickFile;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: colors.primaryContainer, borderRadius: BorderRadius.circular(18)),
                  child: Icon(Icons.local_fire_department_rounded, color: colors.primary, size: 30),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    '爆款拆书引擎',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              '导入小说或选择已写作品，按 7 大模块拆出爆款逻辑、故事骨架、人物系统、爽点机制、文风、商业化和可复用方法论。',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: onPickFile,
                icon: const Icon(Icons.upload_file_rounded),
                label: const Text('导入 TXT / MD 开始拆书'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Text(
      '| $title',
      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, color: colors.primary),
    );
  }
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(color: colors.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
      child: Row(
        children: [
          Icon(icon, size: 18, color: colors.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }
}
