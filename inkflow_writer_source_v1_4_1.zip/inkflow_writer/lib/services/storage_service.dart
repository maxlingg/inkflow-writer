import 'dart:convert';
import 'dart:io';

import 'package:charset_converter/charset_converter.dart';
import 'package:path_provider/path_provider.dart';

import '../models/writing_project.dart';
import 'docx_export_service.dart';

enum ExportFormat { txt, markdown, docx }

extension ExportFormatLabel on ExportFormat {
  String get label => switch (this) {
        ExportFormat.txt => 'TXT',
        ExportFormat.markdown => 'Markdown',
        ExportFormat.docx => 'Word DOCX',
      };

  String get extension => switch (this) {
        ExportFormat.txt => 'txt',
        ExportFormat.markdown => 'md',
        ExportFormat.docx => 'docx',
      };
}

class ChapterBackup {
  const ChapterBackup({
    required this.path,
    required this.title,
    required this.createdAt,
    required this.reason,
  });

  final String path;
  final String title;
  final DateTime createdAt;
  final String reason;
}

class StorageService {
  StorageService._();

  static final StorageService instance = StorageService._();

  Future<List<WritingProject>> _readProjectIndex() async {
    final file = await _projectFile();
    var projects = <WritingProject>[];

    if (!await file.exists()) return projects;

    final raw = await file.readAsString();
    if (raw.trim().isEmpty) return projects;

    try {
      final decoded = jsonDecode(raw) as List;
      projects = decoded
          .whereType<Map>()
          .map((item) => WritingProject.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } on FormatException {
      final backup = File('${file.path}.broken-${DateTime.now().millisecondsSinceEpoch}');
      await file.rename(backup.path);
      projects = [];
    }

    return projects;
  }


  Future<List<WritingProject>> loadProjectSummaries() async {
    final projects = await _readProjectIndex();
    final folderProjects = await _loadProjectsFromFolders();
    for (final project in folderProjects) {
      if (!projects.any((item) => item.id == project.id)) projects.add(project);
    }
    projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return projects;
  }

  Future<List<WritingProject>> loadProjects() async {
    final projects = await _readProjectIndex();

    final folderProjects = await _loadProjectsFromFolders();
    for (final project in folderProjects) {
      if (!projects.any((item) => item.id == project.id)) projects.add(project);
    }

    final hydrated = <WritingProject>[];
    for (final project in projects) {
      final withDefaults = _withDefaultMaterialFiles(project);
      hydrated.add(await _hydrateProjectFromDisk(withDefaults));
    }

    hydrated.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    await saveProjects(hydrated);
    for (final project in hydrated) {
      await _syncProjectToDisk(project);
    }
    return hydrated;
  }

  Future<void> saveProjects(List<WritingProject> projects) async {
    final file = await _projectFile();
    final data = projects.map(_projectIndexJson).toList();
    const encoder = JsonEncoder.withIndent('  ');
    await file.writeAsString(encoder.convert(data), flush: true);
  }

  Future<void> upsertProject(WritingProject project) async {
    final next = _withDefaultMaterialFiles(project.copyWith(updatedAt: DateTime.now()));
    await _saveProjectInIndex(next);
    await _syncProjectToDisk(next);
  }

  Future<void> _saveProjectInIndex(WritingProject project) async {
    final projects = await _readProjectIndex();
    final index = projects.indexWhere((item) => item.id == project.id);

    if (index == -1) {
      projects.add(project);
    } else {
      projects[index] = project;
    }
    projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    await saveProjects(projects);
  }

  Future<void> deleteProject(String id) async {
    final projects = await loadProjects();
    final target = projects.where((project) => project.id == id).toList();
    projects.removeWhere((project) => project.id == id);
    await saveProjects(projects);

    for (final project in target) {
      final dir = await projectDirectory(project);
      if (await dir.exists()) await dir.delete(recursive: true);

      final novels = await novelsDirectory();
      final legacyDir = Directory('${novels.path}${Platform.pathSeparator}${_safeName(project.title)}');
      if (legacyDir.path != dir.path && await legacyDir.exists()) {
        await legacyDir.delete(recursive: true);
      }
    }
  }

  Future<String> exportProject(
    WritingProject project, {
    required ExportFormat format,
  }) async {
    final dir = await _exportDir();
    final filename = '${_safeName(project.title)}-${_dateStamp()}.${format.extension}';
    final file = File('${dir.path}${Platform.pathSeparator}$filename');

    if (format == ExportFormat.docx) {
      return DocxExportService.exportProject(project, file.path);
    }

    final content = switch (format) {
      ExportFormat.markdown => _toMarkdown(project),
      ExportFormat.txt => _toPlainText(project),
      ExportFormat.docx => '',
    };

    await file.writeAsString(content, flush: true);
    return file.path;
  }

  Future<WritingProject> addTextAsChapter({
    required WritingProject project,
    required String title,
    required String content,
  }) async {
    final now = DateTime.now();
    final chapter = Chapter(
      id: newEntityId('chapter'),
      title: _stripExtension(title.trim().isEmpty ? '新章节' : title.trim()),
      content: content,
      createdAt: now,
      updatedAt: now,
    );
    final next = project.copyWith(
      chapters: [...project.chapters, chapter],
      updatedAt: now,
    );
    await upsertProject(next);
    return next;
  }

  Future<WritingProject> importFileAsChapter(WritingProject project, String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) throw FileSystemException('文件不存在', filePath);

    final name = file.uri.pathSegments.isEmpty ? '导入章节' : file.uri.pathSegments.last;
    final lower = name.toLowerCase();
    String content;
    if (lower.endsWith('.docx')) {
      content = await DocxExportService.readDocxText(filePath);
    } else {
      content = await _readTextFile(file);
    }
    return addTextAsChapter(project: project, title: _stripExtension(name), content: content);
  }

  Future<WritingProject> appendMaterial({
    required WritingProject project,
    required String title,
    required String content,
    String tag = 'AI',
  }) async {
    final now = DateTime.now();
    final cleanTitle = _stripExtension(title.trim().isEmpty ? 'AI草稿' : title.trim());
    final index = project.notes.indexWhere((item) => _safeName(item.title) == _safeName(cleanTitle));
    final notes = [...project.notes];
    if (index == -1) {
      notes.add(
        ProjectNote(
          id: newEntityId('note'),
          title: cleanTitle,
          body: content,
          tag: tag,
          createdAt: now,
          updatedAt: now,
        ),
      );
    } else {
      final old = notes[index];
      notes[index] = old.copyWith(
        body: old.body.trim().isEmpty ? content : '${old.body.trim()}\n\n$content',
        tag: tag,
        updatedAt: now,
      );
    }
    final next = project.copyWith(notes: notes, updatedAt: now);
    await upsertProject(next);
    return next;
  }

  Future<WritingProject> upsertMaterialNote({
    required WritingProject project,
    required ProjectNote note,
  }) async {
    final notes = [...project.notes];
    final index = notes.indexWhere((item) => item.id == note.id);
    final oldNote = index == -1 ? null : notes[index];
    if (index == -1) {
      notes.add(note);
    } else {
      notes[index] = note;
    }
    final next = project.copyWith(notes: notes, updatedAt: DateTime.now());
    await _saveProjectInIndex(next);
    await _writeProjectJson(next);
    await _writeMaterialFile(next, note);
    if (oldNote != null) await _deleteRenamedMaterialFile(next, oldNote, note);
    return next;
  }

  Future<WritingProject> updateMaterial({
    required WritingProject project,
    required String title,
    required String content,
    String tag = '资料',
  }) async {
    final now = DateTime.now();
    final cleanTitle = _stripExtension(title.trim().isEmpty ? '未命名资料' : title.trim());
    final notes = [...project.notes];
    final index = notes.indexWhere((item) => _safeName(item.title) == _safeName(cleanTitle));
    ProjectNote? oldNote;
    late ProjectNote nextNote;

    if (index == -1) {
      nextNote = ProjectNote(
        id: newEntityId('note'),
        title: cleanTitle,
        body: content,
        tag: tag,
        createdAt: now,
        updatedAt: now,
      );
      notes.add(nextNote);
    } else {
      oldNote = notes[index];
      nextNote = oldNote.copyWith(body: content, tag: tag, updatedAt: now);
      notes[index] = nextNote;
    }
    final next = project.copyWith(notes: notes, updatedAt: now);
    await _saveProjectInIndex(next);
    await _writeProjectJson(next);
    await _writeMaterialFile(next, nextNote);
    if (oldNote != null) await _deleteRenamedMaterialFile(next, oldNote, nextNote);
    return next;
  }

  Future<WritingProject> saveBookAnalysisReports({
    required WritingProject project,
    required Map<String, String> reports,
  }) async {
    var next = project;
    final projectDir = await projectDirectory(project);
    final analysisDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料${Platform.pathSeparator}拆书分析');
    if (!await analysisDir.exists()) await analysisDir.create(recursive: true);

    for (final entry in reports.entries) {
      final cleanTitle = _stripExtension(entry.key.trim().isEmpty ? '拆书报告' : entry.key.trim());
      final body = entry.value.trim();
      final nestedFile = File('${analysisDir.path}${Platform.pathSeparator}${_safeName(cleanTitle)}.md');
      await nestedFile.writeAsString(body, flush: true);

      final noteTitle = '拆书分析/$cleanTitle';
      final now = DateTime.now();
      final existing = next.notes.where((note) => note.title == noteTitle).toList();
      final note = existing.isEmpty
          ? ProjectNote(
              id: newEntityId('note'),
              title: noteTitle,
              body: body,
              tag: '拆书分析',
              createdAt: now,
              updatedAt: now,
            )
          : existing.first.copyWith(body: body, tag: '拆书分析', updatedAt: now);
      next = await upsertMaterialNote(project: next, note: note);
    }
    return next;
  }

  Future<WritingProject> upsertChapter({
    required WritingProject project,
    required Chapter chapter,
    String backupReason = '',
  }) async {
    final existing = project.chapters.where((item) => item.id == chapter.id).toList();
    final oldChapter = existing.isEmpty ? null : existing.first;
    if (backupReason.trim().isNotEmpty && oldChapter != null) {
      await backupChapter(project: project, chapter: oldChapter, reason: backupReason);
    }
    final chapters = [...project.chapters];
    final index = chapters.indexWhere((item) => item.id == chapter.id);
    if (index == -1) {
      chapters.add(chapter);
    } else {
      chapters[index] = chapter;
    }
    final next = project.copyWith(chapters: chapters, updatedAt: DateTime.now());
    await _saveProjectInIndex(next);
    await _writeProjectJson(next);
    await _writeChapterFile(next, chapter);
    if (oldChapter != null) await _deleteRenamedChapterFile(next, oldChapter, chapter);
    return next;
  }

  Future<String> backupChapter({
    required WritingProject project,
    required Chapter chapter,
    String reason = '手动备份',
  }) async {
    final projectDir = await projectDirectory(project);
    final dir = Directory('${projectDir.path}${Platform.pathSeparator}版本历史${Platform.pathSeparator}${_safeName(chapter.title)}');
    if (!await dir.exists()) await dir.create(recursive: true);
    final filename = '${_dateStampWithSeconds()}-${_safeName(reason)}.md';
    final file = File('${dir.path}${Platform.pathSeparator}$filename');
    final content = '''# ${chapter.title}

> 备份原因：$reason
> 备份时间：${DateTime.now().toIso8601String()}

${chapter.content}''';
    await file.writeAsString(content, flush: true);
    return file.path;
  }

  Future<List<ChapterBackup>> loadChapterBackups({
    required WritingProject project,
    required Chapter chapter,
  }) async {
    final projectDir = await projectDirectory(project);
    final dir = Directory('${projectDir.path}${Platform.pathSeparator}版本历史${Platform.pathSeparator}${_safeName(chapter.title)}');
    if (!await dir.exists()) return const [];
    final backups = <ChapterBackup>[];
    await for (final entity in dir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final stat = await entity.stat();
      final name = entity.path.split(Platform.pathSeparator).last;
      final reason = name.replaceFirst(RegExp(r'^\d{8}-\d{6}-'), '').replaceFirst(RegExp(r'\.md$'), '');
      backups.add(ChapterBackup(
        path: entity.path,
        title: name,
        createdAt: stat.modified,
        reason: reason.replaceAll('_', ' '),
      ));
    }
    backups.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return backups;
  }

  Future<String> readBackup(String path) async {
    final file = File(path);
    if (!await file.exists()) throw FileSystemException('备份不存在', path);
    final text = await _readTextFile(file);
    final split = text.split('\n\n');
    if (split.length >= 3 && split.first.startsWith('# ')) {
      return split.skip(2).join('\n\n').trimLeft();
    }
    return text;
  }

  Future<Directory> projectDirectory(WritingProject project) async {
    final novels = await novelsDirectory();
    final dir = Directory('${novels.path}${Platform.pathSeparator}${_safeName(project.id)}');
    final legacyDir = Directory('${novels.path}${Platform.pathSeparator}${_safeName(project.title)}');

    if (!await dir.exists()) {
      if (legacyDir.path != dir.path && await legacyDir.exists()) {
        try {
          await legacyDir.rename(dir.path);
        } catch (_) {
          await _copyMissingDirectory(legacyDir, dir);
        }
      } else {
        await dir.create(recursive: true);
      }
    } else if (legacyDir.path != dir.path && await legacyDir.exists()) {
      await _copyMissingDirectory(legacyDir, dir);
    }

    if (!await dir.exists()) await dir.create(recursive: true);
    if (legacyDir.path != dir.path && await legacyDir.exists() && await dir.exists()) {
      try {
        await legacyDir.delete(recursive: true);
      } catch (_) {}
    }
    return dir;
  }

  Future<String> projectDirectoryPath(WritingProject project) async {
    return (await projectDirectory(project)).path;
  }

  Future<Directory> novelsDirectory() async {
    final base = await _baseDir();
    final dir = Directory('${base.path}${Platform.pathSeparator}novels');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<String> novelsDirectoryPath() async {
    return (await novelsDirectory()).path;
  }

  Future<Directory> baseDirectory() => _baseDir();

  Future<Directory> _baseDir() async {
    final internalRoot = await getApplicationDocumentsDirectory();
    Directory? root;

    try {
      root = await getExternalStorageDirectory();
    } catch (_) {
      root = null;
    }

    final dir = Directory('${(root ?? internalRoot).path}${Platform.pathSeparator}inkflow_writer');
    if (!await dir.exists()) await dir.create(recursive: true);

    if (root != null) {
      final oldDir = Directory('${internalRoot.path}${Platform.pathSeparator}inkflow_writer');
      await _migrateOldInternalData(oldDir, dir);
    }

    return dir;
  }

  Future<void> _migrateOldInternalData(Directory oldDir, Directory newDir) async {
    if (!await oldDir.exists()) return;
    final marker = File('${newDir.path}${Platform.pathSeparator}.migrated');
    if (await marker.exists()) return;

    await for (final entity in oldDir.list(recursive: false, followLinks: false)) {
      final name = entity.path.split(Platform.pathSeparator).last;
      final targetPath = '${newDir.path}${Platform.pathSeparator}$name';
      if (entity is File && !await File(targetPath).exists()) {
        await entity.copy(targetPath);
      }
      if (entity is Directory && !await Directory(targetPath).exists()) {
        await _copyDirectory(entity, Directory(targetPath));
      }
    }
    await marker.writeAsString(DateTime.now().toIso8601String());
  }

  Future<void> _copyDirectory(Directory source, Directory target) async {
    if (!await target.exists()) await target.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final name = entity.path.split(Platform.pathSeparator).last;
      final targetPath = '${target.path}${Platform.pathSeparator}$name';
      if (entity is File) await entity.copy(targetPath);
      if (entity is Directory) await _copyDirectory(entity, Directory(targetPath));
    }
  }

  Future<void> _copyMissingDirectory(Directory source, Directory target) async {
    if (!await target.exists()) await target.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final name = entity.path.split(Platform.pathSeparator).last;
      final targetPath = '${target.path}${Platform.pathSeparator}$name';
      if (entity is File) {
        final targetFile = File(targetPath);
        if (!await targetFile.exists()) await entity.copy(targetPath);
      }
      if (entity is Directory) await _copyMissingDirectory(entity, Directory(targetPath));
    }
  }

  Future<File> _projectFile() async {
    final dir = await _baseDir();
    return File('${dir.path}${Platform.pathSeparator}projects.json');
  }

  Future<Directory> _exportDir() async {
    final dir = Directory('${(await _baseDir()).path}${Platform.pathSeparator}exports');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<List<WritingProject>> _loadProjectsFromFolders() async {
    final novels = await novelsDirectory();
    final results = <WritingProject>[];
    await for (final entity in novels.list(recursive: false, followLinks: false)) {
      if (entity is! Directory) continue;
      final jsonFile = File('${entity.path}${Platform.pathSeparator}project.json');
      if (await jsonFile.exists()) {
        try {
          final decoded = jsonDecode(await jsonFile.readAsString()) as Map<String, dynamic>;
          results.add(WritingProject.fromJson(decoded));
          continue;
        } catch (_) {}
      }

      final now = DateTime.now();
      final title = entity.path.split(Platform.pathSeparator).last;
      results.add(
        WritingProject(
          id: newEntityId('project'),
          title: title,
          description: '',
          genre: '长篇小说',
          createdAt: now,
          updatedAt: now,
          chapters: const [],
          notes: const [],
        ),
      );
    }
    return results;
  }

  WritingProject _withDefaultMaterialFiles(WritingProject project) {
    final now = DateTime.now();
    final notes = [...project.notes];
    void ensureNote(String title, String body) {
      if (notes.any((item) => _safeName(item.title) == _safeName(title))) return;
      notes.add(
        ProjectNote(
          id: newEntityId('note'),
          title: title,
          body: body,
          tag: '资料',
          createdAt: now,
          updatedAt: now,
        ),
      );
    }

    ensureNote('世界观', '# 世界观\n\n## 基础规则\n\n## 地点与势力\n\n## 限制与代价\n');
    ensureNote('人物库', '# 人物库\n\n## 主角\n\n## 配角\n\n## 反派\n');
    ensureNote('大纲', '# 大纲\n\n## 主线\n\n## 阶段目标\n\n## 结局方向\n');
    ensureNote('章节摘要', '# 章节摘要\n\n用于保存每章发生了什么、人物变化、伏笔和下一章承接点。\n');
    ensureNote('伏笔库', '# 伏笔库\n\n| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |\n|---|---|---|---|---|\n');
    ensureNote('时间线', '# 时间线\n\n记录关键事件的先后顺序、人物到场情况和可能的矛盾。\n');
    ensureNote('禁止改动设定', '# 禁止改动设定\n\n这些内容是 AI 写作时不能擅自改变的硬规则。\n\n- 主角核心身份：\n- 金手指/能力限制：\n- 世界底层规则：\n- 已经定死的结局方向：\n');
    ensureNote('文风模板', '# 文风模板\n\n## 叙事语气\n\n## 节奏要求\n\n## 对话风格\n\n## 禁止事项\n\n- 不要 AI 总结腔。\n- 不要频繁使用空泛形容词。\n');
    ensureNote('章节卡片', '# 章节卡片\n\n每章写作前的任务单会保存到这里。\n');
    ensureNote('蒸馏记忆', '# 蒸馏记忆\n\n把长篇上下文、AI 对话和章节资料压缩成稳定记忆。AI 写作时优先参考这里，避免长篇越写越乱。\n\n## 稳定设定\n\n## 人物状态\n\n## 主线进度\n\n## 伏笔与悬念\n\n## 时间线\n\n## 文风约束\n');
    ensureNote('长篇质检报告', '# 长篇质检报告\n\n保存一致性检查、伏笔检查、节奏检查结果。\n');
    ensureNote('连续写作日志', '# 连续写作日志\n\n记录每次连续写作生成了哪些章节、摘要和问题。\n');
    ensureNote('AI草稿', '# AI草稿\n\nAI 生成但还没放入正文的内容可以先存到这里。\n');

    final chapters = [...project.chapters];
    if (chapters.isEmpty) {
      chapters.add(
        Chapter(
          id: newEntityId('chapter'),
          title: '第1章',
          content: '',
          createdAt: now,
          updatedAt: now,
        ),
      );
    }

    return project.copyWith(notes: notes, chapters: chapters);
  }

  Future<WritingProject> _hydrateProjectFromDisk(WritingProject project) async {
    final projectDir = await projectDirectory(project);
    final materialsDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料');
    final chaptersDir = Directory('${projectDir.path}${Platform.pathSeparator}章节内容');
    if (!await materialsDir.exists()) await materialsDir.create(recursive: true);
    if (!await chaptersDir.exists()) await chaptersDir.create(recursive: true);

    final notes = <ProjectNote>[];
    final knownNoteTitles = <String>{};
    final knownNoteFiles = <String>{};
    for (final note in project.notes) {
      final preferredName = _fileNameForNote(note);
      final legacyName = _legacyFileNameForTitle(note.title);
      final file = await _firstExistingFile(materialsDir, [preferredName, legacyName]);
      var next = note;
      if (file != null) next = note.copyWith(body: await _readTextFile(file));
      knownNoteTitles.add(_safeName(next.title));
      knownNoteFiles.addAll([preferredName, legacyName]);
      notes.add(next);
    }

    await for (final entity in materialsDir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final name = entity.path.split(Platform.pathSeparator).last;
      if (knownNoteFiles.contains(name)) continue;
      final title = _titleFromFile(entity.path);
      if (knownNoteTitles.contains(_safeName(title))) continue;
      final now = DateTime.now();
      notes.add(ProjectNote(
        id: newEntityId('note'),
        title: title,
        body: await _readTextFile(entity),
        tag: '资料',
        createdAt: now,
        updatedAt: now,
      ));
    }

    final chapters = <Chapter>[];
    final knownChapterTitles = <String>{};
    final knownChapterFiles = <String>{};
    for (final chapter in project.chapters) {
      final preferredName = _fileNameForChapter(chapter);
      final legacyName = _legacyFileNameForTitle(chapter.title);
      final file = await _firstExistingFile(chaptersDir, [preferredName, legacyName]);
      var next = chapter;
      if (file != null) next = chapter.copyWith(content: await _readTextFile(file));
      knownChapterTitles.add(_safeName(next.title));
      knownChapterFiles.addAll([preferredName, legacyName]);
      chapters.add(next);
    }

    final extraChapterFiles = <File>[];
    await for (final entity in chaptersDir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final name = entity.path.split(Platform.pathSeparator).last;
      if (knownChapterFiles.contains(name)) continue;
      final title = _titleFromFile(entity.path);
      if (!knownChapterTitles.contains(_safeName(title))) extraChapterFiles.add(entity);
    }
    extraChapterFiles.sort((a, b) => _chapterSortKey(_titleFromFile(a.path)).compareTo(_chapterSortKey(_titleFromFile(b.path))));
    for (final file in extraChapterFiles) {
      final now = DateTime.now();
      chapters.add(Chapter(
        id: newEntityId('chapter'),
        title: _titleFromFile(file.path),
        content: await _readTextFile(file),
        createdAt: now,
        updatedAt: now,
      ));
    }

    return project.copyWith(notes: notes, chapters: chapters);
  }

  Future<void> _syncProjectToDisk(WritingProject project) async {
    final projectDir = await projectDirectory(project);
    final materialsDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料');
    final chaptersDir = Directory('${projectDir.path}${Platform.pathSeparator}章节内容');
    if (!await materialsDir.exists()) await materialsDir.create(recursive: true);
    if (!await chaptersDir.exists()) await chaptersDir.create(recursive: true);

    await _writeProjectJson(project);

    final expectedMaterialFiles = <String>{};
    for (final note in project.notes) {
      final fileName = _fileNameForNote(note);
      expectedMaterialFiles.add(fileName);
      final file = File('${materialsDir.path}${Platform.pathSeparator}$fileName');
      await file.writeAsString(note.body, flush: true);
    }
    await _deleteUnexpectedMarkdownFiles(materialsDir, expectedMaterialFiles);

    final expectedChapterFiles = <String>{};
    for (final chapter in project.chapters) {
      final fileName = _fileNameForChapter(chapter);
      expectedChapterFiles.add(fileName);
      final file = File('${chaptersDir.path}${Platform.pathSeparator}$fileName');
      await file.writeAsString(chapter.content, flush: true);
    }
    await _deleteUnexpectedMarkdownFiles(chaptersDir, expectedChapterFiles);
  }

  Future<void> _writeProjectJson(WritingProject project) async {
    final projectDir = await projectDirectory(project);
    const encoder = JsonEncoder.withIndent('  ');
    await File('${projectDir.path}${Platform.pathSeparator}project.json')
        .writeAsString(encoder.convert(_projectIndexJson(project)), flush: true);
  }

  Future<void> _writeChapterFile(WritingProject project, Chapter chapter) async {
    final projectDir = await projectDirectory(project);
    final chaptersDir = Directory('${projectDir.path}${Platform.pathSeparator}章节内容');
    if (!await chaptersDir.exists()) await chaptersDir.create(recursive: true);
    final file = File('${chaptersDir.path}${Platform.pathSeparator}${_fileNameForChapter(chapter)}');
    await file.writeAsString(chapter.content, flush: true);
  }

  Future<void> _writeMaterialFile(WritingProject project, ProjectNote note) async {
    final projectDir = await projectDirectory(project);
    final materialsDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料');
    if (!await materialsDir.exists()) await materialsDir.create(recursive: true);
    final file = File('${materialsDir.path}${Platform.pathSeparator}${_fileNameForNote(note)}');
    await file.writeAsString(note.body, flush: true);
  }

  Future<void> _deleteRenamedChapterFile(WritingProject project, Chapter oldChapter, Chapter newChapter) async {
    final oldNames = {_fileNameForChapter(oldChapter), _legacyFileNameForTitle(oldChapter.title)};
    oldNames.remove(_fileNameForChapter(newChapter));
    oldNames.remove(_legacyFileNameForTitle(newChapter.title));
    if (oldNames.isEmpty) return;
    final projectDir = await projectDirectory(project);
    final chaptersDir = Directory('${projectDir.path}${Platform.pathSeparator}章节内容');
    for (final name in oldNames) {
      final file = File('${chaptersDir.path}${Platform.pathSeparator}$name');
      if (await file.exists()) await file.delete();
    }
  }

  Future<void> _deleteRenamedMaterialFile(WritingProject project, ProjectNote oldNote, ProjectNote newNote) async {
    final oldNames = {_fileNameForNote(oldNote), _legacyFileNameForTitle(oldNote.title)};
    oldNames.remove(_fileNameForNote(newNote));
    oldNames.remove(_legacyFileNameForTitle(newNote.title));
    if (oldNames.isEmpty) return;
    final projectDir = await projectDirectory(project);
    final materialsDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料');
    for (final name in oldNames) {
      final file = File('${materialsDir.path}${Platform.pathSeparator}$name');
      if (await file.exists()) await file.delete();
    }
  }

  Future<void> _deleteUnexpectedMarkdownFiles(Directory dir, Set<String> expectedNames) async {
    await for (final entity in dir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final name = entity.path.split(Platform.pathSeparator).last;
      if (!expectedNames.contains(name)) await entity.delete();
    }
  }

  String _toPlainText(WritingProject project) {
    final buffer = StringBuffer()
      ..writeln(project.title)
      ..writeln(project.genre)
      ..writeln()
      ..writeln(project.description)
      ..writeln('\n====================\n');

    for (final chapter in project.chapters) {
      buffer
        ..writeln(chapter.title)
        ..writeln(List.filled(chapter.title.length.clamp(1, 80), '-').join())
        ..writeln()
        ..writeln(chapter.content.trim())
        ..writeln('\n');
    }

    if (project.notes.isNotEmpty) {
      buffer.writeln('\n====================\n小说资料\n');
      for (final note in project.notes) {
        buffer
          ..writeln('[${note.tag}] ${note.title}')
          ..writeln(note.body.trim())
          ..writeln();
      }
    }
    return buffer.toString();
  }

  String _toMarkdown(WritingProject project) {
    final buffer = StringBuffer()
      ..writeln('# ${project.title}')
      ..writeln()
      ..writeln('> 类型：${project.genre}')
      ..writeln()
      ..writeln(project.description)
      ..writeln();

    for (final chapter in project.chapters) {
      buffer
        ..writeln('## ${chapter.title}')
        ..writeln()
        ..writeln(chapter.content.trim())
        ..writeln();
    }

    if (project.notes.isNotEmpty) {
      buffer.writeln('---\n\n## 小说资料\n');
      for (final note in project.notes) {
        buffer
          ..writeln('### ${note.title}')
          ..writeln()
          ..writeln('- 标签：${note.tag}')
          ..writeln()
          ..writeln(note.body.trim())
          ..writeln();
      }
    }
    return buffer.toString();
  }

  Map<String, dynamic> _projectIndexJson(WritingProject project) {
    final json = project.toJson();
    json['cachedTotalCharacters'] = project.totalCharacters;
    json['chapters'] = project.chapters.map((chapter) {
      final item = chapter.toJson();
      item['content'] = '';
      return item;
    }).toList();
    json['notes'] = project.notes.map((note) {
      final item = note.toJson();
      item['body'] = '';
      return item;
    }).toList();
    return json;
  }

  String _fileNameForChapter(Chapter chapter) =>
      '${_safeName(_stripExtension(chapter.title))}--${_safeName(chapter.id)}.md';

  String _fileNameForNote(ProjectNote note) =>
      '${_safeName(_stripExtension(note.title))}--${_safeName(note.id)}.md';

  String _legacyFileNameForTitle(String title) => '${_safeName(_stripExtension(title))}.md';

  Future<File?> _firstExistingFile(Directory dir, List<String> names) async {
    for (final name in names) {
      final file = File('${dir.path}${Platform.pathSeparator}$name');
      if (await file.exists()) return file;
    }
    return null;
  }

  Future<String> _readTextFile(File file) async {
    final bytes = await file.readAsBytes();
    return _decodeTextBytes(bytes);
  }

  Future<String> _decodeTextBytes(List<int> bytes) async {
    if (bytes.length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) {
      return utf8.decode(bytes.sublist(3), allowMalformed: true);
    }
    if (bytes.length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE) {
      return _decodeUtf16(bytes.sublist(2), littleEndian: true);
    }
    if (bytes.length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF) {
      return _decodeUtf16(bytes.sublist(2), littleEndian: false);
    }

    final utf8Text = utf8.decode(bytes, allowMalformed: true);
    if (_looksReadable(utf8Text)) return utf8Text;

    for (final encoding in const ['gb18030', 'gbk']) {
      try {
        final decoded = await CharsetConverter.decode(encoding, bytes);
        if (_looksReadable(decoded)) return decoded;
      } catch (_) {}
    }
    return utf8Text;
  }

  bool _looksReadable(String text) {
    if (text.isEmpty) return true;
    final sample = text.length > 4000 ? text.substring(0, 4000) : text;
    final replacements = RegExp('\uFFFD').allMatches(sample).length;
    return replacements <= sample.length * 0.01;
  }

  String _decodeUtf16(List<int> bytes, {required bool littleEndian}) {
    final codeUnits = <int>[];
    for (var i = 0; i + 1 < bytes.length; i += 2) {
      final value = littleEndian ? bytes[i] | (bytes[i + 1] << 8) : (bytes[i] << 8) | bytes[i + 1];
      codeUnits.add(value);
    }
    return String.fromCharCodes(codeUnits);
  }

  String _titleFromFile(String path) {
    final name = path.split(Platform.pathSeparator).last;
    final title = _stripExtension(name);
    return title.replaceFirst(RegExp(r'--(?:chapter|note)-[0-9]+-[A-Za-z0-9]+$'), '');
  }

  String _stripExtension(String title) {
    final trimmed = title.trim();
    for (final ext in const ['.md', '.txt', '.docx']) {
      if (trimmed.toLowerCase().endsWith(ext)) {
        return trimmed.substring(0, trimmed.length - ext.length);
      }
    }
    return trimmed;
  }

  String _safeName(String value) {
    final safe = value.trim().replaceAll(RegExp(r'[\\/:*?"<>|\s]+'), '_');
    return safe.isEmpty ? 'untitled' : safe;
  }

  int _chapterSortKey(String title) {
    final match = RegExp(r'(\d+)').firstMatch(title);
    if (match == null) return 999999;
    return int.tryParse(match.group(1) ?? '') ?? 999999;
  }

  String _dateStamp() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${now.year}${two(now.month)}${two(now.day)}-${two(now.hour)}${two(now.minute)}';
  }

  String _dateStampWithSeconds() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${now.year}${two(now.month)}${two(now.day)}-${two(now.hour)}${two(now.minute)}${two(now.second)}';
  }
}
