import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

import '../models/chat_session.dart';
import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/chat_session_store.dart';
import '../services/storage_service.dart';
import '../widgets/app_bottom_bar.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.settings, this.initialProject});

  final AppSettings settings;
  final WritingProject? initialProject;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _inputController = TextEditingController();
  final _scrollController = ScrollController();
  List<ChatSession> _sessions = [];
  List<WritingProject> _projects = [];
  ChatSession? _session;
  WritingProject? _project;
  bool _loading = true;
  bool _sending = false;
  bool _aiRateChecking = false;
  List<ChapterAiRate> _aiRateResults = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final sessions = await ChatSessionStore.loadSessions();
    final projects = await StorageService.instance.loadProjects();
    var currentProject = widget.initialProject;

    ChatSession current;
    if (sessions.isNotEmpty) {
      current = sessions.first;
      if (current.projectId != null) {
        final matches = projects.where((item) => item.id == current.projectId).toList();
        if (matches.isNotEmpty) currentProject = matches.first;
      }
    } else {
      if (currentProject == null && projects.isNotEmpty) currentProject = projects.first;
      current = _newSession(currentProject);
      await ChatSessionStore.upsert(current);
      sessions.add(current);
    }

    if (!mounted) return;
    setState(() {
      _sessions = sessions;
      _projects = projects;
      _session = current;
      _project = currentProject;
      _loading = false;
    });
  }

  ChatSession _newSession(WritingProject? project) {
    final now = DateTime.now();
    return ChatSession(
      id: newChatId('chat'),
      title: project == null ? '创作对话' : '关于《${project.title}》',
      projectId: project?.id,
      messages: [
        ChatMessage(
          id: newChatId('msg'),
          role: 'assistant',
          content: '我是 AI 创作台。顶部的小说标签用于切换/查看注入上下文，模式标签用于配置联网 AI。你可以让我做大纲、人物、世界观、续写、质检、拆章，也可以把输出保存到资料库。',
          createdAt: now,
        ),
      ],
      createdAt: now,
      updatedAt: now,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final session = _session;
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 创作台'),
        actions: [
          IconButton(
            tooltip: '切换对话',
            onPressed: _sessions.length <= 1 ? null : _showSessionPicker,
            icon: const Icon(Icons.forum_outlined),
          ),
          IconButton(
            tooltip: '绑定小说',
            onPressed: _showProjectPicker,
            icon: const Icon(Icons.auto_stories_outlined),
          ),
          IconButton.filledTonal(
            tooltip: '新对话',
            onPressed: _createNewSession,
            icon: const Icon(Icons.add_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      bottomNavigationBar: InkFlowBottomBar(settings: widget.settings, selectedIndex: 0),
      body: _loading || session == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
                  color: colors.surface,
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      ActionChip(
                        avatar: const Icon(Icons.auto_stories_rounded, size: 18),
                        label: Text(_project == null ? '选择小说上下文' : '《${_project!.title}》'),
                        onPressed: _showProjectPicker,
                      ),
                      if (_project != null)
                        ActionChip(
                          avatar: const Icon(Icons.fact_check_outlined, size: 18),
                          label: const Text('查看上下文'),
                          onPressed: _showProjectContext,
                        ),
                      ActionChip(
                        avatar: Icon(
                          widget.settings.hasAiApiKey
                              ? Icons.cloud_done_rounded
                              : Icons.offline_bolt_rounded,
                          size: 18,
                        ),
                        label: Text(
                          widget.settings.hasAiApiKey
                              ? '联网 AI：${widget.settings.aiModel}'
                              : '本地模板模式，点此配置 AI',
                        ),
                        onPressed: _openAiSettings,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    controller: _scrollController,
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
                    itemCount: session.messages.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final message = session.messages[index];
                      return _MessageBubble(
                        message: message,
                        onCopy: () => Clipboard.setData(ClipboardData(text: message.content)),
                        onSaveToDraft: message.isUser ? null : () => _saveAssistantMessage(message),
                      );
                    },
                  ),
                ),
                if (_aiRateResults.isNotEmpty)
                  _AiRateResultPanel(
                    results: _aiRateResults,
                    onClose: () => setState(() => _aiRateResults.clear()),
                  ),
                _QuickPrompts(onPick: _handleQuickPrompt),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _inputController,
                            minLines: 1,
                            maxLines: 5,
                            decoration: const InputDecoration(
                              hintText: '输入创作需求，例如：帮我拆这本书前三十章……',
                            ),
                            onSubmitted: (_) => _send(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton.filled(
                          onPressed: _sending ? null : _send,
                          icon: _sending
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.send_rounded),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _send() async {
    final text = _inputController.text.trim();
    final session = _session;
    if (text.isEmpty || session == null) return;
    _inputController.clear();
    final now = DateTime.now();
    final userMessage = ChatMessage(id: newChatId('msg'), role: 'user', content: text, createdAt: now);
    final nextSession = session.copyWith(messages: [...session.messages, userMessage], updatedAt: now);
    setState(() {
      _session = nextSession;
      _sending = true;
    });
    await ChatSessionStore.upsert(nextSession);
    _jumpToBottom();

    try {
      final history = nextSession.messages
          .map((item) => '${item.role == 'user' ? '用户' : '助手'}：${item.content}')
          .toList();
      final answer = await AiService.instance.sendChat(
        settings: widget.settings,
        message: text,
        project: _project,
        history: history,
      );
      final assistant = ChatMessage(
        id: newChatId('msg'),
        role: 'assistant',
        content: answer,
        createdAt: DateTime.now(),
      );
      final saved = nextSession.copyWith(
        title: _makeTitle(text),
        messages: [...nextSession.messages, assistant],
        updatedAt: DateTime.now(),
      );
      await ChatSessionStore.upsert(saved);
      if (!mounted) return;
      setState(() {
        _session = saved;
        _sessions = [saved, ..._sessions.where((item) => item.id != saved.id)];
      });
      _jumpToBottom();
    } catch (error) {
      final failed = ChatMessage(
        id: newChatId('msg'),
        role: 'assistant',
        content: '请求失败：$error',
        createdAt: DateTime.now(),
      );
      final saved = nextSession.copyWith(messages: [...nextSession.messages, failed], updatedAt: DateTime.now());
      await ChatSessionStore.upsert(saved);
      if (!mounted) return;
      setState(() => _session = saved);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  String _makeTitle(String text) {
    final compact = text.replaceAll(RegExp(r'\s+'), '');
    if (compact.length <= 14) return compact;
    return '${compact.substring(0, 14)}…';
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent + 240,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _saveAssistantMessage(ChatMessage message) async {
    final project = _project;
    if (project == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先绑定小说')));
      return;
    }
    final next = await StorageService.instance.appendMaterial(
      project: project,
      title: _makeTitle(message.content),
      content: message.content,
      tag: 'AI',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('已保存到《${project.title}》的资料库'),
        action: SnackBarAction(label: '查看', onPressed: () => Navigator.of(context).pop()),
      ),
    );
  }

  void _showSessionPicker() {
    showModalBottomSheet(
      context: context,
      builder: (_) => ListView.builder(
        itemCount: _sessions.length,
        itemBuilder: (context, index) {
          final session = _sessions[index];
          return ListTile(
            leading: const Icon(Icons.chat_outlined),
            title: Text(session.title),
            subtitle: Text(_formatTime(session.updatedAt)),
            selected: session.id == _session?.id,
            onTap: () {
              setState(() => _session = session);
              Navigator.pop(context);
            },
          );
        },
      ),
    );
  }

  void _showProjectPicker() {
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.block),
            title: const Text('不使用上下文'),
            selected: _project == null,
            onTap: () {
              setState(() => _project = null);
              Navigator.pop(context);
            },
          ),
          const Divider(),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _projects.length,
              itemBuilder: (context, index) {
                final project = _projects[index];
                return ListTile(
                  leading: const Icon(Icons.auto_stories_outlined),
                  title: Text(project.title),
                  subtitle: Text(project.genre),
                  selected: project.id == _project?.id,
                  onTap: () {
                    setState(() => _project = project);
                    Navigator.pop(context);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showProjectContext() {
    final project = _project;
    if (project == null) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, scrollController) => _ProjectContextViewer(
          project: project,
          scrollController: scrollController,
        ),
      ),
    );
  }

  void _openAiSettings() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => SettingsScreen(settings: widget.settings)));
  }

  Future<void> _createNewSession() async {
    final now = DateTime.now();
    final session = ChatSession(
      id: newChatId('chat'),
      title: '新对话',
      projectId: _project?.id,
      messages: [
        ChatMessage(
          id: newChatId('msg'),
          role: 'assistant',
          content: '新对话已创建。我可以帮你做大纲、人物、世界观、续写、质检、拆章等创作任务。',
          createdAt: now,
        ),
      ],
      createdAt: now,
      updatedAt: now,
    );
    await ChatSessionStore.upsert(session);
    if (!mounted) return;
    setState(() {
      _session = session;
      _sessions = [session, ..._sessions];
    });
  }

  void _handleQuickPrompt(String prompt) {
    if (prompt == 'AI率检查') {
      _checkAiRate();
    } else {
      _inputController.text = prompt;
    }
  }

  Future<void> _checkAiRate() async {
    final project = _project;
    if (project == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先绑定小说')),
      );
      return;
    }
    if (project.chapters.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前小说没有章节')),
      );
      return;
    }

    setState(() => _aiRateChecking = true);

    try {
      final results = await AiService.instance.checkChapterAiRate(
        settings: widget.settings,
        project: project,
      );
      if (!mounted) return;
      setState(() {
        _aiRateResults = results;
        _aiRateChecking = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _aiRateChecking = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('AI率检查失败：$error')),
      );
    }
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);
    if (diff.inDays > 0) return '${diff.inDays}天前';
    if (diff.inHours > 0) return '${diff.inHours}小时前';
    if (diff.inMinutes > 0) return '${diff.inMinutes}分钟前';
    return '刚刚';
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    required this.message,
    required this.onCopy,
    required this.onSaveToDraft,
  });

  final ChatMessage message;
  final VoidCallback onCopy;
  final VoidCallback? onSaveToDraft;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isUser = message.isUser;

    return Row(
      mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!isUser) ...[
          CircleAvatar(
            radius: 16,
            backgroundColor: colors.primaryContainer,
            child: Icon(Icons.smart_toy_outlined, size: 18, color: colors.onPrimaryContainer),
          ),
          const SizedBox(width: 10),
        ],
        Flexible(
          child: Container(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.72,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: isUser ? colors.primaryContainer : colors.surfaceContainerHighest,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(20),
                topRight: const Radius.circular(20),
                bottomLeft: Radius.circular(isUser ? 20 : 4),
                bottomRight: Radius.circular(isUser ? 4 : 20),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isUser)
                  Text(
                    message.content,
                    style: Theme.of(context).textTheme.bodyMedium,
                  )
                else
                  MarkdownBody(
                    data: message.content,
                    selectable: true,
                    styleSheet: MarkdownStyleSheet(
                      p: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.6),
                      code: TextStyle(
                        backgroundColor: colors.surfaceContainerHighest,
                        fontFamily: 'monospace',
                        fontSize: 13,
                      ),
                      codeblockDecoration: BoxDecoration(
                        color: colors.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      blockquoteDecoration: BoxDecoration(
                        border: Border(
                          left: BorderSide(color: colors.primary, width: 3),
                        ),
                      ),
                      listBullet: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                const SizedBox(height: 8),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                      onTap: onCopy,
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        child: Text(
                          '复制',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: colors.onSurfaceVariant,
                              ),
                        ),
                      ),
                    ),
                    if (onSaveToDraft != null) ...[
                      const SizedBox(width: 8),
                      InkWell(
                        onTap: onSaveToDraft,
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          child: Text(
                            '保存',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: colors.primary,
                                ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
        if (isUser) ...[
          const SizedBox(width: 10),
          CircleAvatar(
            radius: 16,
            backgroundColor: colors.secondaryContainer,
            child: Icon(Icons.person_outline, size: 18, color: colors.onSecondaryContainer),
          ),
        ],
      ],
    );
  }
}

class _QuickPrompts extends StatelessWidget {
  const _QuickPrompts({required this.onPick});

  final void Function(String) onPick;

  static const _prompts = [
    '续写本章',
    '润色本章',
    '质检一致性',
    '拆解章节',
    '扩展情节',
    'AI率检查',
  ];

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _prompts.map((prompt) {
            return Padding(
              padding: const EdgeInsets.only(right: 8, bottom: 8),
              child: ActionChip(
                label: Text(prompt),
                onPressed: () => onPick(prompt),
                backgroundColor: colors.surfaceContainerHighest,
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _ProjectContextViewer extends StatelessWidget {
  const _ProjectContextViewer({
    required this.project,
    required this.scrollController,
  });

  final WritingProject project;
  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: colors.outlineVariant)),
            ),
            child: Row(
              children: [
                Icon(Icons.auto_stories_outlined, color: colors.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '《${project.title}》',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      Text(
                        'AI 将基于以下内容创作',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: colors.onSurfaceVariant,
                            ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              controller: scrollController,
              padding: const EdgeInsets.all(16),
              children: [
                if (project.description.isNotEmpty) ...[
                  _ContextSection(
                    title: '小说简介',
                    content: project.description,
                    icon: Icons.description_outlined,
                  ),
                  const SizedBox(height: 16),
                ],
                if (project.notes.isNotEmpty) ...[
                  Text(
                    '资料库（${project.notes.length}篇）',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                  ),
                  const SizedBox(height: 12),
                  ...project.notes.map((note) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _NoteCard(
                          title: note.title,
                          body: note.body.length > 200 ? '${note.body.substring(0, 200)}...' : note.body,
                          tag: note.tag,
                        ),
                      )),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ContextSection extends StatelessWidget {
  const _ContextSection({
    required this.title,
    required this.content,
    required this.icon,
  });

  final String title;
  final String content;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: colors.primary),
              const SizedBox(width: 8),
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.6),
          ),
        ],
      ),
    );
  }
}

class _AiRateResultPanel extends StatelessWidget {
  const _AiRateResultPanel({
    required this.results,
    required this.onClose,
  });

  final List<ChapterAiRate> results;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest.withOpacity(0.7),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.outlineVariant.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 8),
            child: Row(
              children: [
                Icon(Icons.psychology_rounded, size: 20, color: colors.primary),
                const SizedBox(width: 8),
                Text(
                  '章节 AI 率检查结果',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close_rounded, size: 18),
                  onPressed: onClose,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.all(12),
            itemCount: results.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final result = results[index];
              return _AiRateItem(result: result);
            },
          ),
        ],
      ),
    );
  }
}

class _AiRateItem extends StatelessWidget {
  const _AiRateItem({required this.result});

  final ChapterAiRate result;

  Color _getRateColor(double rate, ColorScheme colors) {
    if (rate < 0.3) return Colors.green;
    if (rate < 0.5) return Colors.orange;
    return Colors.red;
  }

  String _getRateLabel(double rate) {
    if (rate < 0.3) return '低';
    if (rate < 0.5) return '中';
    if (rate < 0.7) return '较高';
    return '高';
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final rateColor = _getRateColor(result.aiRate, colors);
    final ratePercent = (result.aiRate * 100).toStringAsFixed(0);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  result.chapterTitle,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: rateColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '$ratePercent% (${_getRateLabel(result.aiRate)})',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: rateColor,
                        fontWeight: FontWeight.w900,
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(
                '字数：${result.totalCharacters}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: colors.onSurfaceVariant,
                    ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: result.aiRate,
                    backgroundColor: colors.surfaceContainerHighest,
                    color: rateColor,
                    minHeight: 6,
                  ),
                ),
              ),
            ],
          ),
          if (result.summary.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              result.summary,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: colors.onSurfaceVariant,
                  ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );
  }
}

class _NoteCard extends StatelessWidget {
  const _NoteCard({
    required this.title,
    required this.body,
    required this.tag,
  });

  final String title;
  final String body;
  final String tag;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outlineVariant.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: colors.primaryContainer.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  tag,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: colors.primary,
                      ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            body,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: colors.onSurfaceVariant,
                  height: 1.5,
                ),
          ),
        ],
      ),
    );
  }
}
