import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../widgets/app_bottom_bar.dart';
import '../widgets/empty_state.dart';
import '../widgets/skeleton_loading.dart';
import 'book_analysis_screen.dart';
import 'inspiration_to_book_screen.dart';
import 'txt_book_import_screen.dart';
import 'project_screen.dart';
import 'skills_screen.dart';

enum ProjectFilter { all, recent, longForm, shortForm }

extension ProjectFilterLabel on ProjectFilter {
  String get label => switch (this) {
        ProjectFilter.all => '全部',
        ProjectFilter.recent => '最近',
        ProjectFilter.longForm => '长篇',
        ProjectFilter.shortForm => '短篇',
      };
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<WritingProject> _projects = [];
  bool _loading = true;
  ProjectFilter _currentFilter = ProjectFilter.all;

  @override
  void initState() {
    super.initState();
    _load();
  }

  List<WritingProject> get _filteredProjects {
    switch (_currentFilter) {
      case ProjectFilter.all:
        return _projects;
      case ProjectFilter.recent:
        return _projects
            .where((p) => DateTime.now().difference(p.updatedAt).inDays <= 7)
            .toList();
      case ProjectFilter.longForm:
        return _projects.where((p) => p.chapters.length >= 5).toList();
      case ProjectFilter.shortForm:
        return _projects.where((p) => p.chapters.length < 5).toList();
    }
  }

  Future<void> _load() async {
    final projects = await StorageService.instance.loadProjectSummaries();
    if (!mounted) return;
    setState(() {
      _projects = projects;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 52,
        leading: Padding(
          padding: const EdgeInsets.only(left: 18),
          child: Icon(Icons.auto_stories_rounded, color: colors.primary, size: 30),
        ),
        title: const Text('我的小说'),
        titleTextStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w900,
              color: colors.onSurface,
            ),
        actions: [
          IconButton(
            tooltip: '新建小说',
            onPressed: _showCreateProjectDialog,
            icon: const Icon(Icons.create_new_folder_rounded),
          ),
          const SizedBox(width: 8),
          IconButton(
            tooltip: '本地目录',
            onPressed: _showStoragePath,
            icon: const Icon(Icons.folder_outlined),
          ),
          PopupMenuButton<String>(
            tooltip: '更多',
            onSelected: (value) async {
              if (value == 'skills') {
                await Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SkillsScreen()),
                );
              }
              if (value == 'book_analysis') await _openBookAnalysis();
              if (value == 'txt_import') await _openTxtBookImport();
              if (value == 'refresh') await _load();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'skills', child: Text('AI 技能库')),
              PopupMenuItem(value: 'book_analysis', child: Text('拆书分析')),
              PopupMenuItem(value: 'txt_import', child: Text('拆 TXT 小书')),
              PopupMenuItem(value: 'refresh', child: Text('重新读取')),
            ],
          ),
          const SizedBox(width: 6),
        ],
      ),
      bottomNavigationBar: InkFlowBottomBar(settings: widget.settings),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openInspirationToBook,
        icon: const Icon(Icons.auto_fix_high_rounded),
        label: const Text('灵感成书'),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      body: _loading
          ? _buildLoadingState(colors)
          : RefreshIndicator(
              onRefresh: _load,
              child: _projects.isEmpty
                  ? _buildEmptyState()
                  : _buildProjectList(colors),
            ),
      backgroundColor: colors.surfaceContainerLowest,
    );
  }

  Widget _buildLoadingState(ColorScheme colors) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 28, 18, 100),
      children: [
        _buildFilterChips(),
        const SizedBox(height: 16),
        const SkeletonLoading(),
      ],
    );
  }

  Widget _buildEmptyState() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 100),
      children: [
        _buildFilterChips(),
        SizedBox(height: MediaQuery.of(context).size.height * 0.1),
        _buildEmptyStateContent(),
      ],
    );
  }

  Widget _buildEmptyStateContent() {
    final colors = Theme.of(context).colorScheme;
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.0, end: 1.0),
          duration: const Duration(milliseconds: 1500),
          curve: Curves.easeOutBack,
          builder: (context, value, child) {
            return Transform.scale(
              scale: value,
              child: child,
            );
          },
          child: Icon(
            Icons.create_new_folder_rounded,
            size: 80,
            color: colors.primary.withOpacity(0.8),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          '本地还没有小说',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
              ),
        ),
        const SizedBox(height: 8),
        Text(
          '新建后会自动生成"小说资料"和"章节内容"两个本地文件夹。',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: colors.onSurfaceVariant,
              ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: _openInspirationToBook,
          icon: const Icon(Icons.auto_fix_high_rounded),
          label: const Text('灵感成书'),
        ),
        const SizedBox(height: 12),
        TextButton.icon(
          onPressed: _showCreateProjectDialog,
          icon: const Icon(Icons.add_rounded),
          label: const Text('手动新建'),
        ),
      ],
    );
  }

  Widget _buildProjectList(ColorScheme colors) {
    final filtered = _filteredProjects;
    final hasProjects = filtered.isNotEmpty;
    return ListView.separated(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 100),
      itemCount: 2 + (hasProjects ? filtered.length : 1),
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        if (index == 0) {
          return _buildFilterChips();
        }
        if (index == 1) {
          return Padding(
            padding: const EdgeInsets.only(top: 8),
            child: _InspirationEntryCard(onTap: _openInspirationToBook),
          );
        }
        if (!hasProjects) {
          return Padding(
            padding: const EdgeInsets.only(top: 24),
            child: Center(
              child: Text(
                '无匹配的小说',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
          );
        }
        final project = filtered[index - 2];
        return _NovelCard(
          project: project,
          isCurrent: index == 2,
          onOpen: () async {
            final fullProject = await _loadFullProject(project);
            if (!mounted) return;
            await Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ProjectScreen(
                  project: fullProject,
                  settings: widget.settings,
                ),
              ),
            );
            await _load();
          },
          onRename: () => _renameProject(project),
          onDelete: () => _confirmDeleteProject(project),
          onExportMarkdown: () => _exportProject(project, ExportFormat.markdown),
          onExportText: () => _exportProject(project, ExportFormat.txt),
          onExportDocx: () => _exportProject(project, ExportFormat.docx),
        );
      },
    );
  }

  Widget _buildFilterChips() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: ProjectFilter.values.map((filter) {
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(filter.label),
              selected: _currentFilter == filter,
              onSelected: (selected) {
                setState(() {
                  _currentFilter = selected ? filter : ProjectFilter.all;
                });
              },
            ),
          );
        }).toList(),
      ),
    );
  }

  Future<WritingProject> _loadFullProject(WritingProject project) async {
    final projects = await StorageService.instance.loadProjects();
    return projects.firstWhere((item) => item.id == project.id, orElse: () => project);
  }

  Future<void> _openInspirationToBook() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => InspirationToBookScreen(settings: widget.settings)),
    );
    await _load();
  }

  Future<void> _openBookAnalysis() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => BookAnalysisScreen(settings: widget.settings)),
    );
    await _load();
  }

  Future<void> _openTxtBookImport() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const TxtBookImportScreen()),
    );
    await _load();
  }

  Future<void> _showCreateProjectDialog() async {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    final genreController = TextEditingController(text: '长篇小说');

    final result = await showDialog<WritingProject>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('新建小说'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  autofocus: true,
                  decoration: const InputDecoration(labelText: '小说名'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: genreController,
                  decoration: const InputDecoration(labelText: '类型'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: descriptionController,
                  minLines: 3,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: '一句话简介'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                final now = DateTime.now();
                final title = titleController.text.trim();
                if (title.isEmpty) return;
                Navigator.pop(
                  context,
                  WritingProject(
                    id: newEntityId('project'),
                    title: title,
                    description: descriptionController.text.trim(),
                    genre: genreController.text.trim().isEmpty
                        ? '原创'
                        : genreController.text.trim(),
                    createdAt: now,
                    updatedAt: now,
                    chapters: [
                      Chapter(
                        id: newEntityId('chapter'),
                        title: '第1章',
                        content: '',
                        createdAt: now,
                        updatedAt: now,
                      ),
                    ],
                    notes: [
                      ProjectNote(
                        id: newEntityId('note'),
                        title: '世界观',
                        body: '',
                        tag: '资料',
                        createdAt: now,
                        updatedAt: now,
                      ),
                      ProjectNote(
                        id: newEntityId('note'),
                        title: '人物库',
                        body: '',
                        tag: '资料',
                        createdAt: now,
                        updatedAt: now,
                      ),
                      ProjectNote(
                        id: newEntityId('note'),
                        title: '大纲',
                        body: '',
                        tag: '资料',
                        createdAt: now,
                        updatedAt: now,
                      ),
                      ProjectNote(
                        id: newEntityId('note'),
                        title: '章节摘要',
                        body: '',
                        tag: '资料',
                        createdAt: now,
                        updatedAt: now,
                      ),
                    ],
                  ),
                );
              },
              child: const Text('创建'),
            ),
          ],
        );
      },
    );

    if (result == null) return;
    await StorageService.instance.upsertProject(result);
    await _load();
  }

  Future<void> _renameProject(WritingProject project) async {
    final fullProject = await _loadFullProject(project);
    final titleController = TextEditingController(text: fullProject.title);
    final descriptionController = TextEditingController(text: fullProject.description);
    final genreController = TextEditingController(text: fullProject.genre);

    final result = await showDialog<WritingProject>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('修改小说信息'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                autofocus: true,
                decoration: const InputDecoration(labelText: '小说名'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: genreController,
                decoration: const InputDecoration(labelText: '类型'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: descriptionController,
                minLines: 3,
                maxLines: 5,
                decoration: const InputDecoration(labelText: '简介'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(
            onPressed: () {
              final title = titleController.text.trim();
              if (title.isEmpty) return;
              Navigator.pop(
                context,
                fullProject.copyWith(
                  title: title,
                  genre: genreController.text.trim().isEmpty ? '原创' : genreController.text.trim(),
                  description: descriptionController.text.trim(),
                  updatedAt: DateTime.now(),
                ),
              );
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );

    if (result == null) return;
    await StorageService.instance.upsertProject(result);
    await _load();
  }

  Future<void> _confirmDeleteProject(WritingProject project) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${project.title}」？'),
        content: const Text('作品、章节、小说资料和本地文件夹都会从本机移除。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );

    if (shouldDelete != true) return;
    await StorageService.instance.deleteProject(project.id);
    await _load();
  }

  Future<void> _showStoragePath() async {
    final path = await StorageService.instance.novelsDirectoryPath();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('本地小说目录'),
        content: SelectableText(path),
        actions: [
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: path));
              if (context.mounted) Navigator.pop(context);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('目录路径已复制')),
                );
              }
            },
            child: const Text('复制路径'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('知道了'),
          ),
        ],
      ),
    );
  }

  Future<void> _exportProject(WritingProject project, ExportFormat format) async {
    final fullProject = await _loadFullProject(project);
    final path = await StorageService.instance.exportProject(fullProject, format: format);
    await Share.shareXFiles([XFile(path)], text: '「${fullProject.title}」已导出');
  }
}

class _InspirationEntryCard extends StatelessWidget {
  const _InspirationEntryCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: colors.secondaryContainer.withOpacity(0.68),
      borderRadius: BorderRadius.circular(24),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: colors.secondary.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(Icons.auto_fix_high_rounded, color: colors.secondary),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '灵感成书',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w900,
                            color: colors.onSecondaryContainer,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '输入一句想法，自动创建小说资料、章节卡和第 1 章。',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: colors.onSecondaryContainer.withOpacity(0.72),
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}

class _NovelCard extends StatelessWidget {
  const _NovelCard({
    required this.project,
    required this.isCurrent,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    required this.onExportMarkdown,
    required this.onExportText,
    required this.onExportDocx,
  });

  final WritingProject project;
  final bool isCurrent;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final VoidCallback onExportMarkdown;
  final VoidCallback onExportText;
  final VoidCallback onExportDocx;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final bg = isCurrent ? colors.primaryContainer.withOpacity(0.72) : colors.surface;
    final fg = isCurrent ? colors.onPrimaryContainer : colors.onSurface;

    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(24),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onOpen,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: isCurrent ? colors.primary.withOpacity(0.14) : colors.primaryContainer.withOpacity(0.55),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Icon(Icons.book_rounded, color: colors.primary, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            project.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.w900,
                                  color: fg,
                                  height: 1.05,
                                ),
                          ),
                        ),
                        if (isCurrent) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                            decoration: BoxDecoration(
                              color: colors.primary,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Text(
                              '当前',
                              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                                    color: colors.onPrimary,
                                    fontWeight: FontWeight.w900,
                                  ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 8),
                    FutureBuilder<String>(
                      future: StorageService.instance.projectDirectoryPath(project),
                      builder: (context, snapshot) {
                        final path = snapshot.data ?? '正在读取本地路径…';
                        return Text(
                          path,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                color: fg.withOpacity(0.48),
                                fontWeight: FontWeight.w800,
                              ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: Icon(Icons.more_vert_rounded, color: fg.withOpacity(0.58)),
                onSelected: (value) {
                  if (value == 'rename') onRename();
                  if (value == 'md') onExportMarkdown();
                  if (value == 'txt') onExportText();
                  if (value == 'docx') onExportDocx();
                  if (value == 'delete') onDelete();
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(value: 'rename', child: Text('修改信息')),
                  PopupMenuDivider(),
                  PopupMenuItem(value: 'docx', child: Text('导出 Word DOCX')),
                  PopupMenuItem(value: 'md', child: Text('导出 Markdown')),
                  PopupMenuItem(value: 'txt', child: Text('导出 TXT')),
                  PopupMenuDivider(),
                  PopupMenuItem(value: 'delete', child: Text('删除小说')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
