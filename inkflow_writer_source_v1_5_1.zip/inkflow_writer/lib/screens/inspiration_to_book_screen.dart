import 'package:flutter/material.dart';

import '../models/inspiration_book_draft.dart';
import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../widgets/gacha_widget.dart';
import 'project_screen.dart';

class InspirationToBookScreen extends StatefulWidget {
  const InspirationToBookScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  State<InspirationToBookScreen> createState() => _InspirationToBookScreenState();
}

class _InspirationToBookScreenState extends State<InspirationToBookScreen> {
  final _inspirationController = TextEditingController();
  final _expandedInspirationController = TextEditingController();
  final _worldviewController = TextEditingController();
  final _coreConflictController = TextEditingController();
  final _protagonistController = TextEditingController();
  final _uniqueSettingsController = TextEditingController();
  final _readerPromiseController = TextEditingController();
  final _titleController = TextEditingController();
  final _genreController = TextEditingController();
  final _styleController = TextEditingController();

  bool _generateFirstChapter = true;
  bool _working = false;
  bool _showGachaOptions = false;
  String _status = '';
  InspirationWorldSeed? _worldSeed;
  InspirationBookDraft? _lastDraft;
  WritingProject? _lastProject;
  List<WorldOption> _gachaOptions = [];
  WorldOption? _selectedGachaOption;

  @override
  void dispose() {
    _inspirationController.dispose();
    _expandedInspirationController.dispose();
    _worldviewController.dispose();
    _coreConflictController.dispose();
    _protagonistController.dispose();
    _uniqueSettingsController.dispose();
    _readerPromiseController.dispose();
    _titleController.dispose();
    _genreController.dispose();
    _styleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('灵感成书'),
        actions: [
          IconButton(
            tooltip: '示例灵感',
            onPressed: _working ? null : _fillExample,
            icon: const Icon(Icons.tips_and_updates_rounded),
          ),
          IconButton(
            tooltip: '重置流程',
            onPressed: _working ? null : _resetFlow,
            icon: const Icon(Icons.restart_alt_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        children: [
          _HeroCard(hasApiKey: widget.settings.hasAiApiKey),
          const SizedBox(height: 16),
          _StepBanner(
            activeStep: _worldSeed == null ? 1 : 2,
          ),
          const SizedBox(height: 16),
          _SectionCard(
            title: '1. 输入灵感',
            subtitle: '写下你的创作灵感（至少6个字）',
            child: Column(
              children: [
                TextField(
                  controller: _inspirationController,
                  minLines: 5,
                  maxLines: 9,
                  textInputAction: TextInputAction.newline,
                  decoration: const InputDecoration(
                    labelText: '原始灵感',
                    hintText: '例如：一个现代人死后成了地府代理人，用现代法律和职场规则整顿阴间。',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: GachaDrawButton(
                        onPressed: _working ? null : _gachaWorldOptions,
                        isLoading: _working && _showGachaOptions,
                        label: '🎲 快速抽卡',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _working ? null : _buildWorldview,
                        icon: _working && _worldSeed == null && !_showGachaOptions
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.travel_explore_rounded),
                        label: const Text('✨ 深度生成'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (_showGachaOptions) ...[
            const SizedBox(height: 16),
            _buildGachaOptions(colors),
          ],
          if (_worldSeed != null) ...[
            const SizedBox(height: 16),
            _buildConfirmAndCreate(colors),
          ],
          if (_status.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              _status,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: _working ? colors.primary : colors.onSurfaceVariant,
                    fontWeight: FontWeight.w800,
                  ),
            ),
          ],
          if (_lastDraft != null) ...[
            const SizedBox(height: 18),
            _DraftPreviewCard(
              draft: _lastDraft!,
              project: _lastProject,
              onOpenProject: _lastProject == null ? null : _openLastProject,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildConfirmAndCreate(ColorScheme colors) {
    final seed = _worldSeed!;
    return _SectionCard(
      title: '2. 确认并创建',
      subtitle: '检查以下内容，满意后一键创建小说项目（可直接编辑修改）',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ExpansionTile(
            title: const Text('世界观设定（可展开编辑）'),
            initiallyExpanded: false,
            children: [
              _MultilineField(
                controller: _expandedInspirationController,
                label: '完整灵感 / 故事概念',
                minLines: 5,
                maxLines: 12,
              ),
              const SizedBox(height: 12),
              _MultilineField(
                controller: _worldviewController,
                label: '世界观草案',
                minLines: 10,
                maxLines: 18,
              ),
              const SizedBox(height: 12),
              _MultilineField(
                controller: _coreConflictController,
                label: '核心冲突',
                minLines: 3,
                maxLines: 7,
              ),
              const SizedBox(height: 12),
              _MultilineField(
                controller: _protagonistController,
                label: '主角种子',
                minLines: 3,
                maxLines: 7,
              ),
              const SizedBox(height: 12),
              _MultilineField(
                controller: _uniqueSettingsController,
                label: '独特设定 / 差异化',
                minLines: 4,
                maxLines: 9,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _readerPromiseController,
                decoration: const InputDecoration(
                  labelText: '读者承诺',
                  hintText: '这本书给读者的核心看点。',
                ),
              ),
            ],
          ),
          const Divider(height: 32),
          _ChoiceBlock(
            title: '书名候选',
            options: seed.titleOptions,
            selected: _titleController.text,
            onSelected: (value) => setState(() => _titleController.text = value),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(labelText: '最终书名，可手动修改'),
          ),
          const SizedBox(height: 16),
          _ChoiceBlock(
            title: '类型候选',
            options: seed.genreOptions,
            selected: _genreController.text,
            onSelected: (value) => setState(() => _genreController.text = value),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _genreController,
            decoration: const InputDecoration(labelText: '最终类型，可手动修改'),
          ),
          const SizedBox(height: 16),
          Text('文风模板候选', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          ...seed.styleTemplates.map(
            (style) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => setState(() => _styleController.text = style),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _styleController.text.trim() == style.trim()
                        ? colors.primaryContainer.withOpacity(0.7)
                        : colors.surfaceContainerHighest.withOpacity(0.55),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _styleController.text.trim() == style.trim()
                          ? colors.primary.withOpacity(0.45)
                          : colors.outlineVariant.withOpacity(0.45),
                    ),
                  ),
                  child: Text(style, style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.45)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          _MultilineField(
            controller: _styleController,
            label: '最终文风模板，可手动修改',
            minLines: 3,
            maxLines: 7,
          ),
          const SizedBox(height: 16),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('同时生成第 1 章正文'),
            subtitle: const Text('关闭后只生成小说资料和前三章章节卡。'),
            value: _generateFirstChapter,
            onChanged: _working ? null : (value) => setState(() => _generateFirstChapter = value),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _working ? null : _buildWorldview,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('重新生成'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: FilledButton.icon(
                  onPressed: _working ? null : _createProject,
                  icon: _working
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.auto_awesome_rounded),
                  label: Text(_working ? '正在创建…' : '🚀 一键创建'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _fillExample() {
    _inspirationController.text = '一个现代人死后成了地府代理人，用现代法律和职场规则整顿阴间。';
  }

  void _resetFlow() {
    setState(() {
      _worldSeed = null;
      _showGachaOptions = false;
      _gachaOptions = [];
      _selectedGachaOption = null;
      _lastDraft = null;
      _lastProject = null;
      _status = '';
      _expandedInspirationController.clear();
      _worldviewController.clear();
      _coreConflictController.clear();
      _protagonistController.clear();
      _uniqueSettingsController.clear();
      _readerPromiseController.clear();
      _titleController.clear();
      _genreController.clear();
      _styleController.clear();
    });
  }

  Future<void> _buildWorldview() async {
    final inspiration = _inspirationController.text.trim();
    if (inspiration.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('先写一个稍微完整的灵感，至少 6 个字。')),
      );
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _working = true;
      _showGachaOptions = false;
      _status = widget.settings.hasAiApiKey ? '正在根据灵感构建完整世界观…' : '正在生成可编辑世界观草案…';
      _lastDraft = null;
      _lastProject = null;
    });

    try {
      final seed = await AiService.instance.buildWorldFromInspiration(
        settings: widget.settings,
        inspiration: inspiration,
      );
      if (!mounted) return;
      _loadWorldSeed(seed);
      setState(() {
        _worldSeed = seed;
        _status = '世界观已生成！检查并修改后，点击"一键创建"生成小说项目。';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = '世界观生成失败：$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  void _loadWorldSeed(InspirationWorldSeed seed) {
    _expandedInspirationController.text = seed.expandedInspiration;
    _worldviewController.text = seed.worldview;
    _coreConflictController.text = seed.coreConflict;
    _protagonistController.text = seed.protagonistSeed;
    _uniqueSettingsController.text = seed.uniqueSettings;
    _readerPromiseController.text = seed.readerPromise;
    _titleController.text = seed.titleOptions.isEmpty ? '' : seed.titleOptions.first;
    _genreController.text = seed.genreOptions.isEmpty ? '' : seed.genreOptions.first;
    _styleController.text = seed.styleTemplates.isEmpty ? '' : seed.styleTemplates.first;
  }

  InspirationWorldSeed _editableWorldSeed() {
    final seed = _worldSeed;
    if (seed == null) {
      return InspirationWorldSeed.fromJson(<String, dynamic>{});
    }
    return seed.copyWith(
      expandedInspiration: _expandedInspirationController.text.trim(),
      worldview: _worldviewController.text.trim(),
      coreConflict: _coreConflictController.text.trim(),
      protagonistSeed: _protagonistController.text.trim(),
      uniqueSettings: _uniqueSettingsController.text.trim(),
      readerPromise: _readerPromiseController.text.trim(),
    );
  }

  Future<void> _createProject() async {
    final title = _titleController.text.trim();
    if (title.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先选择或填写书名。')),
      );
      return;
    }

    final inspiration = _inspirationController.text.trim();
    final seed = _editableWorldSeed();

    FocusScope.of(context).unfocus();
    setState(() {
      _working = true;
      _status = widget.settings.hasAiApiKey ? '正在创建大纲、人物、章节卡和开篇…' : '正在按已确认世界观创建可编辑项目…';
    });

    try {
      final draft = await AiService.instance.createBookFromWorldSeed(
        settings: widget.settings,
        originalInspiration: inspiration,
        worldSeed: seed,
        title: title,
        genre: _genreController.text,
        style: _styleController.text,
        generateFirstChapter: _generateFirstChapter,
      );
      if (!mounted) return;
      setState(() => _status = '正在写入本地小说文件夹…');

      final project = await _createProjectFromDraft(draft, inspiration, seed);
      if (!mounted) return;
      setState(() {
        _lastDraft = draft;
        _lastProject = project;
        _status = '✅ 《${project.title}》已创建！';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('《${project.title}》已创建'),
          action: SnackBarAction(label: '打开', onPressed: _openLastProject),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = '创建失败：$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<WritingProject> _createProjectFromDraft(
    InspirationBookDraft draft,
    String originalInspiration,
    InspirationWorldSeed worldSeed,
  ) async {
    final now = DateTime.now();
    final title = await _uniqueProjectTitle(draft.title.trim().isEmpty ? '灵感小说' : draft.title.trim());
    final firstChapterTitle = draft.firstChapterTitle.trim().isEmpty ? '第1章' : draft.firstChapterTitle.trim();

    final project = WritingProject(
      id: newEntityId('project'),
      title: title,
      description: draft.description,
      genre: draft.genre,
      createdAt: now,
      updatedAt: now,
      chapters: [
        Chapter(
          id: newEntityId('chapter'),
          title: firstChapterTitle,
          content: draft.firstChapterContent.trim(),
          createdAt: now,
          updatedAt: now,
        ),
      ],
      notes: [
        _note('灵感成书报告', draft.incubationReport, 'AI'),
        _note('原始灵感', '# 原始灵感\n\n$originalInspiration', '灵感'),
        _note('已确认世界观草案', _worldSeedNote(worldSeed), '灵感'),
        _note('核心卖点', draft.sellingPoints, '资料'),
        _note('世界观', draft.worldview, '资料'),
        _note('人物库', draft.characters, '资料'),
        _note('大纲', draft.outline, '资料'),
        _note('伏笔库', draft.foreshadowing, '资料'),
        _note('时间线', draft.timeline, '资料'),
        _note('禁止改动设定', draft.lockedSettings, '资料'),
        _note('文风模板', draft.styleTemplate, '资料'),
        _note('章节卡片', draft.chapterCards, '资料'),
        _note('章节摘要', '# 章节摘要\n\n## $firstChapterTitle\n\n待写完后自动归档。', '资料'),
        _note('长篇质检报告', '# 长篇质检报告\n\n尚未执行一致性检查。', '资料'),
        _note('连续写作日志', '# 连续写作日志\n\n由灵感成书创建于 ${now.toIso8601String()}。', '资料'),
        _note('AI草稿', '# AI草稿\n\n', 'AI'),
      ],
    );

    await StorageService.instance.upsertProject(project);
    return project;
  }

  String _worldSeedNote(InspirationWorldSeed seed) {
    return '''# 世界观草案

## 完整灵感

${seed.expandedInspiration}

## 世界观

${seed.worldview}

## 核心冲突

${seed.coreConflict}

## 主角种子

${seed.protagonistSeed}

## 独特设定

${seed.uniqueSettings}

## 读者承诺

${seed.readerPromise}''';
  }

  ProjectNote _note(String title, String body, String tag) {
    final now = DateTime.now();
    return ProjectNote(
      id: newEntityId('note'),
      title: title,
      body: body,
      tag: tag,
      createdAt: now,
      updatedAt: now,
    );
  }

  Future<String> _uniqueProjectTitle(String baseTitle) async {
    final projects = await StorageService.instance.loadProjects();
    final existing = projects.map((item) => item.title.trim()).toSet();
    if (!existing.contains(baseTitle)) return baseTitle;
    for (var i = 2; i < 999; i++) {
      final candidate = '$baseTitle $i';
      if (!existing.contains(candidate)) return candidate;
    }
    return '$baseTitle ${DateTime.now().millisecondsSinceEpoch}';
  }

  Future<void> _openLastProject() async {
    final project = _lastProject;
    if (project == null || !mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProjectScreen(project: project, settings: widget.settings)),
    );
  }

  Future<void> _gachaWorldOptions() async {
    final inspiration = _inspirationController.text.trim();
    if (inspiration.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('灵感至少需要 4 个字才能抽卡哦~')),
      );
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _working = true;
      _showGachaOptions = true;
      _status = '正在生成 3 个创作路线…';
    });

    try {
      final result = await AiService.instance.gachaWorldOptions(inspiration);
      if (!mounted) return;
      setState(() {
        _gachaOptions = result.options;
        _selectedGachaOption = null;
        _status = '✅ 已生成 3 个创作路线！选择一个后点击"一键创建"';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = '抽卡生成失败：$error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Widget _buildGachaOptions(ColorScheme colors) {
    return _SectionCard(
      title: '🎲 创作路线',
      subtitle: '选择你喜欢的创作方向',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const GachaRarityBanner(
            title: '快速抽卡结果',
            subtitle: '选择一个创作方向，然后一键创建',
          ),
          const SizedBox(height: 16),
          ..._gachaOptions.asMap().entries.map(
            (entry) {
              final index = entry.key;
              final option = entry.value;
              final isSelected = _selectedGachaOption?.id == option.id;
              return Padding(
                padding: EdgeInsets.only(bottom: index < 2 ? 12 : 0),
                child: GachaCard(
                  title: option.title,
                  content: option.expandedInspiration,
                  isSelected: isSelected,
                  onTap: () => _selectGachaOption(option),
                  index: index,
                ),
              );
            },
          ),
          if (_selectedGachaOption != null) ...[
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _working ? null : _confirmGachaAndCreate,
                icon: const Icon(Icons.auto_awesome_rounded),
                label: const Text('🚀 确认并一键创建'),
              ),
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: _working ? null : _gachaWorldOptions,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('再抽一次'),
            ),
          ],
        ],
      ),
    );
  }

  void _selectGachaOption(WorldOption option) {
    final seed = InspirationWorldSeed.fromOption(option);
    _loadWorldSeed(seed);
    setState(() {
      _selectedGachaOption = option;
      _worldSeed = seed;
      _showGachaOptions = false;
      _status = '✅ 已选择：${option.title}！检查内容后点击"一键创建"';
    });
  }

  Future<void> _confirmGachaAndCreate() async {
    final option = _selectedGachaOption;
    if (option == null) return;

    await _createProject();
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.hasApiKey});

  final bool hasApiKey;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            colors.primaryContainer.withOpacity(0.6),
            colors.secondaryContainer.withOpacity(0.4),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: colors.primary.withOpacity(0.25),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.auto_fix_high_rounded, color: colors.primary, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '灵感成书',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                        color: colors.onPrimaryContainer,
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            hasApiKey
                ? 'AI 已配置，可以深度生成完整世界观。也可以尝试快速抽卡获取灵感！'
                : '当前为本地模板模式（无 AI）。抽卡功能可用，或使用本地模板快速生成。',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: colors.onPrimaryContainer.withOpacity(0.8),
                ),
          ),
        ],
      ),
    );
  }
}

class _StepBanner extends StatelessWidget {
  const _StepBanner({required this.activeStep});

  final int activeStep;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final steps = ['输入灵感', '确认内容'];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: List.generate(steps.length * 2 - 1, (index) {
          if (index.isOdd) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Icon(
                Icons.chevron_right_rounded,
                size: 18,
                color: colors.outline.withOpacity(0.6),
              ),
            );
          }
          final stepIndex = index ~/ 2;
          final isActive = stepIndex + 1 == activeStep;
          final isCompleted = stepIndex + 1 < activeStep;
          return _StepChip(
            label: '${stepIndex + 1}',
            text: steps[stepIndex],
            isActive: isActive,
            isCompleted: isCompleted,
          );
        }),
      ),
    );
  }
}

class _StepChip extends StatelessWidget {
  const _StepChip({
    required this.label,
    required this.text,
    required this.isActive,
    required this.isCompleted,
  });

  final String label;
  final String text;
  final bool isActive;
  final bool isCompleted;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final bg = isActive
        ? colors.primary
        : isCompleted
            ? colors.primaryContainer
            : colors.surfaceContainerHighest;
    final fg = isActive
        ? colors.onPrimary
        : isCompleted
            ? colors.onPrimaryContainer
            : colors.onSurfaceVariant;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 26,
          height: 26,
          decoration: BoxDecoration(
            color: bg,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: isCompleted
                ? Icon(Icons.check_rounded, size: 16, color: fg)
                : Text(
                    label,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: fg,
                    ),
                  ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          text,
          style: TextStyle(
            fontSize: 13,
            fontWeight: isActive ? FontWeight.w900 : FontWeight.w600,
            color: isActive ? colors.primary : colors.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: colors.outlineVariant.withOpacity(0.5),
          width: 1,
        ),
      ),
      color: colors.surface,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: colors.onSurfaceVariant,
                            ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            child,
          ],
        ),
      ),
    );
  }
}

class _MultilineField extends StatelessWidget {
  const _MultilineField({
    required this.controller,
    required this.label,
    this.minLines = 3,
    this.maxLines = 6,
  });

  final TextEditingController controller;
  final String label;
  final int minLines;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      minLines: minLines,
      maxLines: maxLines,
      textInputAction: TextInputAction.newline,
      decoration: InputDecoration(
        labelText: label,
        alignLabelWithHint: true,
      ),
    );
  }
}

class _ChoiceBlock extends StatelessWidget {
  const _ChoiceBlock({
    required this.title,
    required this.options,
    required this.selected,
    required this.onSelected,
  });

  final String title;
  final List<String> options;
  final String selected;
  final void Function(String) onSelected;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w900,
              ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options.map((option) {
            final isSelected = selected.trim() == option.trim();
            return ChoiceChip(
              label: Text(option),
              selected: isSelected,
              onSelected: (_) => onSelected(option),
              selectedColor: colors.primaryContainer,
              labelStyle: TextStyle(
                color: isSelected ? colors.onPrimaryContainer : colors.onSurface,
                fontWeight: isSelected ? FontWeight.w900 : FontWeight.w500,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}

class _DraftPreviewCard extends StatelessWidget {
  const _DraftPreviewCard({
    required this.draft,
    required this.project,
    required this.onOpenProject,
  });

  final InspirationBookDraft draft;
  final WritingProject? project;
  final VoidCallback? onOpenProject;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      color: colors.primaryContainer.withOpacity(0.4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: colors.primary.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.check_circle_rounded, color: colors.primary, size: 24),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '创建成功！',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w900,
                          color: colors.onPrimaryContainer,
                        ),
                  ),
                ),
                if (onOpenProject != null)
                  FilledButton.tonal(
                    onPressed: onOpenProject,
                    child: const Text('打开项目'),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              '《${draft.title}》已保存到本地，包含：世界观、人物库、大纲、伏笔库和章节卡片。',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: colors.onPrimaryContainer.withOpacity(0.8),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
