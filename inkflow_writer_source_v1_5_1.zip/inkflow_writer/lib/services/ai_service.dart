import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;

import '../models/ai_skill.dart';
import '../models/inspiration_book_draft.dart';
import '../models/writing_project.dart';
import 'app_settings.dart';

enum AiContextMode { selection, chapter, project }

extension AiContextModeLabel on AiContextMode {
  String get label {
    return switch (this) {
      AiContextMode.selection => '选中文本优先',
      AiContextMode.chapter => '当前章节',
      AiContextMode.project => '作品设定 + 全书摘要',
    };
  }
}

class GachaResult {
  final List<WorldOption> options;

  const GachaResult({required this.options});

  factory GachaResult.fromLocal(String inspiration) {
    return GachaResult(
      options: [
        _buildLocalOption1(inspiration),
        _buildLocalOption2(inspiration),
        _buildLocalOption3(inspiration),
      ],
    );
  }

  static WorldOption _buildLocalOption1(String inspiration) {
    return WorldOption(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: '⭐ 爽文路线',
      expandedInspiration: '$inspiration\n\n主角快速崛起，用现代思维碾压旧规则，每章都有明确的爽点。',
      worldview: '# 世界观草案\n\n## 基础规则\n\n- 有明确的能力等级系统\n- 每完成一个任务有明确的奖励\n- 旧秩序的腐败显而易见\n\n## 势力结构\n\n- 守旧派：维护现有规则，打压新变量\n- 改良派：希望改变但不敢行动\n- 主角阵营：从0开始建立新秩序\n\n## 代价与限制\n\n- 能力越强，代价越大\n- 每次使用能力都会被记录\n',
      coreConflict: '主角想快速解决问题，但旧秩序的既得利益者不断阻挠，同时主角也要应对能力带来的反噬。',
      protagonistSeed: '主角原本是普通人，有现代社会的常识和思维方式。不按常理出牌，善于利用规则漏洞。乐观向上，有感染力。',
      uniqueSettings: '- 能力有明确等级\n- 爽点密集\n- 升级节奏清晰\n- 每个章节都有成果',
      readerPromise: '看主角用现代思维降维打击旧秩序，爽点不断，追读欲强。',
      titleOptions: const ['规则破坏者', '系统代理人', '从零开始的逆袭'],
      genreOptions: const ['都市脑洞 / 长篇爽文', '轻松搞笑 / 升级流', '系统流 / 快节奏'],
      styleTemplates: const [
        '快节奏、强冲突、手机端易读，每章结尾有追读钩子。',
        '轻松吐槽、爽点明确，对话有梗但不破坏紧张感。',
        '节奏明快，升级清晰，每章都有明确的成果展示。',
      ],
    );
  }

  static WorldOption _buildLocalOption2(String inspiration) {
    return WorldOption(
      id: (DateTime.now().millisecondsSinceEpoch + 1).toString(),
      title: '✨ 智斗路线',
      expandedInspiration: '$inspiration\n\n主角不靠武力碾压，而是用智慧和布局改变世界，每一步都有深远影响。',
      worldview: '# 世界观草案\n\n## 基础规则\n\n- 信息就是力量\n- 每个势力都有秘密和弱点\n- 结盟和背叛随时可能发生\n\n## 势力结构\n\n- 多个派系互相制衡\n- 有隐藏的幕后操纵者\n- 主角需要寻找和建立盟友\n\n## 代价与限制\n\n- 布局越久，风险越大\n- 信任任何人都可能付出代价\n- 需要不断平衡各方利益\n',
      coreConflict: '主角想在不引起注意的情况下改变世界，但各大势力都在关注这个新变量，主角需要在夹缝中生存和发展。',
      protagonistSeed: '主角原本是普通人，善于观察和推理。谨慎但有决断力，不轻易相信他人。有长远规划能力，不追求眼前利益。',
      uniqueSettings: '- 布局重于战斗\n- 信息差就是优势\n- 多方势力博弈\n- 反转和伏笔密集',
      readerPromise: '看主角用智慧一步步拆解旧秩序，每个布局都有回报，反转不断。',
      titleOptions: const ['幕后玩家', '规则编织者', '智慧的代理人'],
      genreOptions: const ['悬疑奇幻 / 智斗流', '布局流 / 慢热但精彩', '权谋 / 多方博弈'],
      styleTemplates: const [
        '悬疑感更强，信息分层释放，结尾保留未解谜团。',
        '节奏稍慢但信息量密集，每章都有新线索。',
        '冷静叙事，注重逻辑和布局，逐步揭开真相。',
      ],
    );
  }

  static WorldOption _buildLocalOption3(String inspiration) {
    return WorldOption(
      id: (DateTime.now().millisecondsSinceEpoch + 2).toString(),
      title: '🌙 温情路线',
      expandedInspiration: '$inspiration\n\n主角用温柔的方式改变世界，治愈身边的人，也被世界温柔以待。',
      worldview: '# 世界观草案\n\n## 基础规则\n\n- 每个人都有故事和苦衷\n- 改变人心比改变规则更重要\n- 善意会带来回报\n\n## 势力结构\n\n- 不是非黑即白\n- 每个人都有光明面和阴暗面\n- 主角连接不同的人和故事\n\n## 代价与限制\n\n- 不能拯救所有人\n- 需要付出时间和真心\n- 有时需要做出艰难的选择\n',
      coreConflict: '主角想用温柔的方式改变世界，但现实很残酷，需要在理想和现实间找到平衡。',
      protagonistSeed: '主角原本是普通人，内心柔软但有力量。善于倾听和理解他人。有同理心，愿意为他人付出。',
      uniqueSettings: '- 治愈系\n- 重视人物成长和关系\n- 日常中见真情\n- 温馨但不缺乏冲突',
      readerPromise: '看主角用温柔改变世界，治愈人心，温馨感动。',
      titleOptions: const ['规则的温柔', '异常管理者', '来自彼岸的慰藉'],
      genreOptions: const ['温馨治愈 / 日常流', '都市奇幻 / 人情味儿', '成长治愈 / 现实向'],
      styleTemplates: const [
        '文风细腻，注重人物心理描写，情感真挚。',
        '日常中见真情，节奏平缓但有韵味。',
        '温暖而有力量，在平凡中发现非凡。',
      ],
    );
  }
}

class AiService {
  AiService._();

  static final AiService instance = AiService._();

  Future<String> runSkill({
    required AppSettings settings,
    required AiSkill skill,
    required WritingProject project,
    required Chapter chapter,
    required String extraInstruction,
    required AiContextMode contextMode,
    required String selectedText,
  }) async {
    final contextBlock = _contextBlock(
      project: project,
      chapter: chapter,
      contextMode: contextMode,
      selectedText: selectedText,
    );

    final userPrompt = '''
作品名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}

上下文模式：${contextMode.label}
$contextBlock

使用技能：${skill.name}
技能分类：${skill.category}
技能要求：${skill.prompt}
补充要求：${extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim()}

输出要求：
1. 严格尊重已有设定，不要和上下文冲突。
2. 能直接用于写作的技能，请直接输出正文；规划类技能请用清晰条目。
3. 不要说“当然可以”、不要解释你在做什么。
''';

    return complete(
      settings: settings,
      systemPrompt: '小说技能任务：根据用户选择的 Skill 和上下文完成写作、修订、规划或资料整理。',
      userPrompt: userPrompt,
      localFallback: _localDraft(skill, project, chapter, extraInstruction, contextMode, selectedText),
      maxTokens: 2600,
    );
  }

  Future<String> sendChat({
    required AppSettings settings,
    required String message,
    required WritingProject? project,
    required List<String> history,
  }) async {
    final projectContext = project == null ? '当前没有绑定小说。' : _projectBrief(project);
    final historyText = _chatHistoryBlock(settings, history);
    final prompt = '''
用户消息：$message

当前绑定小说：
$projectContext

最近对话：
${historyText.trim().isEmpty ? '无' : historyText}

请用中文回答。可以给出明确的下一步，也可以生成大纲、正文片段、设定表或修改建议。不要声称已经直接修改文件，除非用户明确使用按钮保存/插入。
''';

    return complete(
      settings: settings,
      systemPrompt: '小说工作台对话：回答作者问题，帮助推进作品创作流程。',
      userPrompt: prompt,
      localFallback: _localChatFallback(message, project),
      maxTokens: 2600,
    );
  }

  Future<String> runLongFormTask({
    required AppSettings settings,
    required WritingProject project,
    required String taskName,
    Chapter? chapter,
    String instruction = '',
    String draftCard = '',
    int maxTokens = 3200,
  }) async {
    final userPrompt = '''
任务：$taskName
作品名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}

【小说大脑】
${_materialsBlock(project)}

【章节列表/节选】
${_chaptersBlock(project)}

【当前章节】
${chapter == null ? '无' : '${chapter.title}\n${_compact(chapter.content, 6200)}'}

【章节卡/任务单】
${draftCard.trim().isEmpty ? '无' : draftCard.trim()}

【作者补充要求】
${instruction.trim().isEmpty ? '无' : instruction.trim()}

请按任务输出可以直接保存到软件里的内容。不要说“当然可以”，不要输出无关解释。
''';

    return complete(
      settings: settings,
      systemPrompt: 'AI 长篇创作模式：维护小说大脑、生成章节卡、写正文、总结归档、检查一致性和连续写作。',
      userPrompt: userPrompt,
      localFallback: _localLongFormFallback(taskName, project, chapter, instruction, draftCard),
      maxTokens: maxTokens,
    );
  }



  Future<String> runBookAnalysisModule({
    required AppSettings settings,
    required WritingProject project,
    required String depthLabel,
    required String depthInstruction,
    required String moduleTitle,
    required String moduleTemplate,
    required List<String> previousReports,
  }) async {
    final previousBlock = previousReports.isEmpty
        ? '无'
        : previousReports.map((item) => _compact(item, 1400)).join('\n\n---\n\n');
    final userPrompt = '''
你不是总结剧情，而是拆解爆款小说的底层逻辑。

禁止复述剧情，必须输出：
- 为什么火
- 爽点机制
- 人设结构
- 节奏设计
- 可复用创作方法

当前只生成一个模块：$moduleTitle
分析深度：$depthLabel
深度要求：$depthInstruction

【作品信息】
书名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}
章节数：${project.chapters.length}
总字数：${project.totalCharacters}

【已生成的前置拆书报告】
$previousBlock

【作品资料】
${_materialsBlock(project)}

【章节样本/正文切片】
${_bookAnalysisSourceBlock(project, depthLabel)}

【固定输出模板】
$moduleTemplate

输出规则：
1. 严格使用上面的固定模板标题，不要遗漏栏目。
2. 禁止长篇复述剧情，只提取结构、机制和可复用规律。
3. 每个栏目必须给出“观察 → 判断 → 可复用做法”。
4. 对网文/商业连载，要重点分析追读、爽点闭环、情绪价值和章节断点。
5. 输出 Markdown，可直接保存为拆书报告。
''';

    return complete(
      settings: settings,
      systemPrompt: '爆款拆书引擎：拆解小说商业逻辑、爽点机制、人设结构、节奏设计和可复用创作方法。禁止复述剧情。',
      userPrompt: userPrompt,
      localFallback: _localBookAnalysisFallback(project, moduleTitle, moduleTemplate, depthLabel),
      maxTokens: depthLabel == '深度' ? 4200 : depthLabel == '标准' ? 3200 : 2200,
    );
  }

  Future<String> buildBookAnalysisDigest({
    required AppSettings settings,
    required WritingProject project,
    required String depthLabel,
  }) async {
    final source = _bookAnalysisSourceBlock(project, depthLabel);
    final userPrompt = '''
请先为后续 7 模块爆款拆书做“章节采样摘要”，不是最终报告。

【作品信息】
书名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}
章节数：${project.chapters.length}
总字数：${project.totalCharacters}

【章节样本/正文切片】
$source

输出 Markdown，必须包含：
# 章节采样摘要
## 开篇三章承诺
## 主线推进地图
## 关键人物变化
## 爽点/钩子样本
## 断章策略样本
## 中后段节奏观察
## 可供后续拆解的判断

规则：
- 禁止长篇复述剧情。
- 每一项都写“观察 → 判断 → 后续拆解可用点”。
- 这是给后续 7 大模块使用的中间摘要，要信息密度高。
''';

    return complete(
      settings: settings,
      systemPrompt: '爆款拆书预处理：把长篇章节样本压缩为后续 7 大模块拆解可用的高密度摘要。',
      userPrompt: userPrompt,
      localFallback: '''# 章节采样摘要

> 本地模板模式：连接 AI 后会先生成深度拆书摘要，再拆 7 大模块。

## 开篇三章承诺
- 记录开篇钩子、读者承诺、首个冲突。

## 主线推进地图
- 记录阶段目标和升级路径。

## 关键人物变化
- 记录主角欲望、弧光、关系张力。

## 爽点/钩子样本
- 记录压迫、反击、反转、获得感。

## 断章策略样本
- 记录每章结尾如何制造追读。

## 中后段节奏观察
- 记录卷结构、阶段闭环、付费点。

## 可供后续拆解的判断
- 后续 7 模块应重点分析赛道、爽点公式、人设落地和商业追更机制。
''',
      maxTokens: depthLabel == '深度' ? 3600 : 2400,
    );
  }

  Future<InspirationBookDraft> createNovelDraftFromMethodology({
    required AppSettings settings,
    required WritingProject sourceProject,
    required String methodology,
    String instruction = '',
  }) async {
    final localDraft = _localMethodologyBookDraft(sourceProject, methodology);
    final userPrompt = '''
请把下面的拆书方法论注入为创作模板，但不要抄袭原书人物、设定、剧情、专有名词或标志性桥段。

【来源作品】
${sourceProject.title} / ${sourceProject.genre}

【拆书方法论】
${_compact(methodology, 11000)}

【作者补充要求】
${instruction.trim().isEmpty ? '无' : instruction.trim()}

请输出严格 JSON，不要使用 Markdown 代码围栏，不要输出解释。字段必须完整：
{
  "title": "全新小说书名",
  "genre": "新小说类型/赛道",
  "description": "一句话简介，80字以内",
  "sellingPoints": "# 核心卖点\\n## 读者承诺\\n## 差异化\\n## 爽点闭环",
  "worldview": "# 世界观\\n## 基础规则\\n## 势力结构\\n## 代价与限制\\n## 长篇扩展空间",
  "characters": "# 人物库\\n## 主角\\n## 配角体系\\n## 反派/阻碍者\\n## 人物关系网",
  "outline": "# 大纲\\n## 主线\\n## 第一卷\\n## 第二卷\\n## 第三卷\\n## 结局方向",
  "foreshadowing": "# 伏笔库\\n| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |...",
  "timeline": "# 时间线\\n按关键事件顺序列出",
  "lockedSettings": "# 禁止改动设定\\n- 主角核心身份：\\n- 金手指/能力限制：\\n- 世界底层规则：\\n- 不能照搬来源作品：",
  "styleTemplate": "# 文风模板\\n## 叙事语气\\n## 节奏要求\\n## 对话风格\\n## 禁止事项",
  "chapterCards": "# 章节卡片\\n## 第1章\\n## 第2章\\n## 第3章",
  "firstChapterTitle": "第1章 标题",
  "firstChapterContent": "可留空；若生成，必须是原创开篇正文",
  "incubationReport": "# 拆书方法论新书生成报告\\n## 来源方法\\n## 已复用结构\\n## 已规避元素\\n## 下一步建议"
}

要求：
- 只复用爆款机制、节奏、人设公式和读者承诺，不复用原书表达和剧情。
- 生成结果必须能直接拆成小说资料库，支持后续 AI 长篇写作。
- 章节卡要包含目标、冲突、爽点/情绪点、结尾钩子。
- 写清“禁止改动设定”，防止后续 AI 写作跑偏。
''';

    final raw = await complete(
      settings: settings,
      systemPrompt: '新书方案生成器：从拆书方法论中抽取可复用结构，生成完全原创的新小说资料库 JSON。',
      userPrompt: userPrompt,
      localFallback: jsonEncode(localDraft.toJson()),
      maxTokens: 5200,
    );

    try {
      final decoded = jsonDecode(_extractJsonObject(raw));
      if (decoded is Map<String, dynamic>) return InspirationBookDraft.fromJson(decoded);
      if (decoded is Map) return InspirationBookDraft.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {
      return localDraft;
    }
    return localDraft;
  }

  Future<String> createNovelOutlineFromMethodology({
    required AppSettings settings,
    required WritingProject sourceProject,
    required String methodology,
    String instruction = '',
  }) async {
    final draft = await createNovelDraftFromMethodology(
      settings: settings,
      sourceProject: sourceProject,
      methodology: methodology,
      instruction: instruction,
    );
    return draft.outline;
  }



  Future<InspirationWorldSeed> buildWorldFromInspiration({
    required AppSettings settings,
    required String inspiration,
  }) async {
    final localSeed = _localWorldSeed(inspiration);
    final userPrompt = """
作者只给了一个原始灵感：
${inspiration.trim()}

请先不要直接创建小说，也不要写章节正文。
你的任务是把这个灵感扩展成一个可供作者确认的【完整世界观草案】，让作者满意后再选择书名、类型和文风。

请输出严格 JSON，不要使用 Markdown 代码围栏，不要输出解释。字段必须完整：
{
  "expandedInspiration": "把原始灵感扩写成完整故事概念，包含主角处境、核心事件、世界变化和长期目标，300-600字",
  "worldview": "# 世界观草案\n## 世界底层规则\n## 现实侧/隐秘侧\n## 势力结构\n## 能力/金手指规则\n## 代价与限制\n## 长篇可扩展空间\n...",
  "coreConflict": "核心冲突：主角想要什么、阻碍来自哪里、旧秩序为什么必须被撬动",
  "protagonistSeed": "主角种子：身份、性格、缺陷、目标、成长线、不能轻易改动的核心设定",
  "uniqueSettings": "独特设定清单，写清和同类题材的区别、爽点来源、反套路点",
  "readerPromise": "给读者的追读承诺：这本书主要看点是什么，80字以内",
  "titleOptions": ["书名候选1", "书名候选2", "书名候选3", "书名候选4", "书名候选5"],
  "genreOptions": ["类型候选1", "类型候选2", "类型候选3"],
  "styleTemplates": ["文风模板1", "文风模板2", "文风模板3"],
  "nextStepHint": "提醒作者确认世界观后再选择书名、类型、文风并创建小说"
}

要求：
1. 世界观要能支撑至少 100 万字长篇，不要只是短篇脑洞。
2. 必须先构建世界规则、势力、代价、主角成长线，再给候选书名。
3. 不要生成章节正文，不要生成最终大纲。
4. 给出的书名、类型、文风只是候选，最终由作者选择。
""";

    final raw = await complete(
      settings: settings,
      systemPrompt: '灵感世界观构建器：只负责把作者的一句话灵感扩展成完整世界观草案和候选书名/类型/文风，不直接创建小说。',
      userPrompt: userPrompt,
      localFallback: jsonEncode(localSeed.toJson()),
      maxTokens: 3200,
    );

    try {
      final decoded = jsonDecode(_extractJsonObject(raw));
      if (decoded is Map<String, dynamic>) return InspirationWorldSeed.fromJson(decoded);
      if (decoded is Map) return InspirationWorldSeed.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {
      return _worldSeedFromLooseText(raw, localSeed);
    }
    return localSeed;
  }

  Future<GachaResult> gachaWorldOptions(String inspiration) async {
    return GachaResult.fromLocal(inspiration);
  }

  Future<List<ChapterAiRate>> checkChapterAiRate({
    required AppSettings settings,
    required WritingProject project,
  }) async {
    if (project.chapters.isEmpty) return [];

    final chapter = project.chapters.lastWhere(
      (c) => c.content.trim().isNotEmpty,
      orElse: () => project.chapters.lastWhere(
        (c) => true,
        orElse: () => throw StateError('no chapters'),
      ),
    );

    final content = chapter.content.trim();
    if (content.isEmpty) return [];

    final totalChars = content.length;
    final hasApiKey = settings.aiApiKey.trim().isNotEmpty;
    double aiRate;
    String summary;

    if (hasApiKey) {
      final prompt = '''
请分析以下小说章节，判断其中有多少比例的内容看起来像是 AI 生成的。

评判标准：
1. 重复句式、过度对称的段落结构
2. 机械化的情感描写（"眼中闪过一丝"、"不由自主"等套路）
3. 缺乏具体细节的泛化描述
4. 过度使用连接词和过渡句
5. 人物对话缺乏个性和口语化

章节内容：
${content.length > 4000 ? content.substring(0, 4000) : content}

请输出 JSON 格式：
{
  "aiRate": 0.0-1.0 的数字，表示 AI 生成嫌疑程度，
  "summary": "一段话说明为什么这么判断，50字以内"
}''';

        try {
          final response = await complete(
            settings: settings,
            systemPrompt: '章节AI率分析：评估章节内容的AI生成嫌疑程度。',
            userPrompt: prompt,
            localFallback: _localAiRateFallback(totalChars),
            maxTokens: 800,
          );

          final parsed = _parseAiRateResponse(response);
          aiRate = parsed.rate;
          summary = parsed.summary;
        } catch (_) {
          final local = _localAiRateFallback(totalChars);
          final parsed = _parseAiRateResponse(local);
          aiRate = parsed.rate;
          summary = parsed.summary;
        }
      } else {
        final local = _localAiRateFallback(totalChars);
        final parsed = _parseAiRateResponse(local);
        aiRate = parsed.rate;
        summary = parsed.summary;
      }

      return [
        ChapterAiRate(
          chapterId: chapter.id,
          chapterTitle: chapter.title,
          totalCharacters: totalChars,
          aiRate: aiRate,
          summary: summary,
        ),
      ];
  }

  ({double rate, String summary}) _parseAiRateResponse(String response) {
    try {
      final text = response.trim();
      final rateMatch = RegExp(r'"aiRate"\s*:\s*([\d.]+)').firstMatch(text);
      final summaryMatch = RegExp(r'"summary"\s*:\s*"([^"]+)"').firstMatch(text);

      double rate = 0.3;
      String summary = '本地模式：无法精确分析';

      if (rateMatch != null) {
        rate = double.tryParse(rateMatch.group(1) ?? '0.3') ?? 0.3;
        rate = rate.clamp(0.0, 1.0);
      }
      if (summaryMatch != null) {
        summary = summaryMatch.group(1) ?? summary;
      }

      return (rate: rate, summary: summary);
    } catch (_) {
      return (rate: 0.3, summary: '无法解析AI响应');
    }
  }

  String _localAiRateFallback(int totalChars) {
    return '{"aiRate": 0.35, "summary": "本地模式：字数$totalChars，无法精确检测AI率。请连接AI服务获取准确分析。"}';
  }

  Future<InspirationBookDraft> createBookFromWorldSeed({
    required AppSettings settings,
    required String originalInspiration,
    required InspirationWorldSeed worldSeed,
    required String title,
    required String genre,
    required String style,
    required bool generateFirstChapter,
  }) async {
    final cleanTitle = title.trim().isEmpty ? worldSeed.titleOptions.first : title.trim();
    final cleanGenre = genre.trim().isEmpty ? worldSeed.genreOptions.first : genre.trim();
    final cleanStyle = style.trim().isEmpty ? worldSeed.styleTemplates.first : style.trim();
    final localDraft = _localBookDraftFromWorldSeed(
      originalInspiration: originalInspiration,
      worldSeed: worldSeed,
      title: cleanTitle,
      genre: cleanGenre,
      style: cleanStyle,
      generateFirstChapter: generateFirstChapter,
    );

    final userPrompt = """
作者已经确认世界观，现在才开始创建剩余小说内容。

【原始灵感】
${originalInspiration.trim()}

【已确认的完整灵感/故事概念】
${worldSeed.expandedInspiration}

【已确认的世界观草案】
${worldSeed.worldview}

【核心冲突】
${worldSeed.coreConflict}

【主角种子】
${worldSeed.protagonistSeed}

【独特设定】
${worldSeed.uniqueSettings}

【读者承诺】
${worldSeed.readerPromise}

【作者最终选择】
书名：$cleanTitle
类型：$cleanGenre
文风模板：$cleanStyle
是否生成第1章正文：${generateFirstChapter ? '是' : '否，只生成开篇章节卡'}

请根据上面已经确认的世界观创建剩余内容，并输出严格 JSON，不要使用 Markdown 代码围栏，不要输出解释。
JSON 字段必须完整：
{
  "title": "$cleanTitle",
  "genre": "$cleanGenre",
  "description": "一句话简介，80字以内",
  "sellingPoints": "# 核心卖点\n...",
  "worldview": "# 世界观\n把已确认世界观整理成正式资料...",
  "characters": "# 人物库\n## 主角\n## 重要配角\n## 反派/阻碍者\n...",
  "outline": "# 大纲\n## 主线\n## 第一卷\n## 第二卷\n## 第三卷\n## 结局方向\n...",
  "foreshadowing": "# 伏笔库\n| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |...",
  "timeline": "# 时间线\n...",
  "lockedSettings": "# 禁止改动设定\n...",
  "styleTemplate": "# 文风模板\n把作者选择的文风扩展为可执行规则...",
  "chapterCards": "# 章节卡片\n## 第1章 ...\n## 第2章 ...\n## 第3章 ...",
  "firstChapterTitle": "第1章 标题",
  "firstChapterContent": "如果要求生成正文，这里写第1章正文，适合手机阅读，1200-2500字；否则留空",
  "incubationReport": "# 灵感成书报告\n## 原始灵感\n## 已确认世界观\n## 作者选择\n## 已生成内容\n## 下一步建议\n..."
}

创作要求：
1. 不得推翻已确认世界观，只能整理、补充、结构化。
2. 大纲要有阶段推进，不要只写概念。
3. 章节卡至少给前三章，每章包含目标、冲突、爽点/情绪点、结尾钩子。
4. 第1章正文要直接进入场景，不要写说明文，不要出现“以下是”。
5. 禁止改动设定要写清主角身份、能力规则、世界底层规则和文风红线。
""";

    final raw = await complete(
      settings: settings,
      systemPrompt: '灵感成书第二阶段：基于作者已确认的世界观，以及作者选择的书名、类型、文风，创建正式小说项目资料、章节卡和第1章。',
      userPrompt: userPrompt,
      localFallback: jsonEncode(localDraft.toJson()),
      maxTokens: generateFirstChapter ? 5600 : 3800,
    );

    try {
      final decoded = jsonDecode(_extractJsonObject(raw));
      if (decoded is Map<String, dynamic>) return InspirationBookDraft.fromJson(decoded);
      if (decoded is Map) return InspirationBookDraft.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {
      return _draftFromLooseText(raw, localDraft);
    }
    return localDraft;
  }
  Future<InspirationBookDraft> incubateBookFromInspiration({
    required AppSettings settings,
    required String inspiration,
    required String genre,
    required String style,
    required bool generateFirstChapter,
  }) async {
    final localDraft = _localInspirationBookDraft(
      inspiration: inspiration,
      genre: genre,
      style: style,
      generateFirstChapter: generateFirstChapter,
    );

    final userPrompt = """
作者给出的灵感：
${inspiration.trim()}

期望类型：${genre.trim().isEmpty ? '长篇小说' : genre.trim()}
期望文风：${style.trim().isEmpty ? '适合中文网文连载，节奏清晰，有追读钩子' : style.trim()}
是否生成第1章正文：${generateFirstChapter ? '是' : '否，只生成开篇章节卡'}

请把这个灵感孵化成一部可以立刻开写的长篇小说，并输出严格 JSON，不要使用 Markdown 代码围栏，不要输出解释。

JSON 字段必须完整：
{
  "title": "书名，短而有记忆点",
  "genre": "题材类型",
  "description": "一句话简介，80字以内",
  "sellingPoints": "# 核心卖点\n...",
  "worldview": "# 世界观\n## 基础规则\n## 地点与势力\n## 限制与代价\n...",
  "characters": "# 人物库\n## 主角\n## 重要配角\n## 反派/阻碍者\n...",
  "outline": "# 大纲\n## 主线\n## 第一卷\n## 第二卷\n## 第三卷\n## 结局方向\n...",
  "foreshadowing": "# 伏笔库\n| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |...",
  "timeline": "# 时间线\n...",
  "lockedSettings": "# 禁止改动设定\n...",
  "styleTemplate": "# 文风模板\n## 叙事语气\n## 节奏要求\n## 对话风格\n## 禁止事项\n...",
  "chapterCards": "# 章节卡片\n## 第1章 ...\n## 第2章 ...\n## 第3章 ...",
  "firstChapterTitle": "第1章 标题",
  "firstChapterContent": "如果要求生成正文，这里写第1章正文，适合手机阅读，1200-2500字；否则留空",
  "incubationReport": "# 灵感孵化报告\n## 已生成内容\n## 下一步建议\n..."
}

创作要求：
1. 小说资料必须能直接保存到本地 Markdown 文件。
2. 大纲要有阶段推进，不要只写概念。
3. 章节卡至少给前三章，每章包含目标、冲突、爽点/情绪点、结尾钩子。
4. 第1章正文要直接进入场景，不要写说明文，不要出现“以下是”。
5. 禁止改动设定要写清主角身份、能力规则、世界底层规则和文风红线。
""";

    final raw = await complete(
      settings: settings,
      systemPrompt: '灵感成书：把作者的一句话灵感孵化成完整长篇小说项目，生成小说资料、章节卡和第1章正文。',
      userPrompt: userPrompt,
      localFallback: jsonEncode(localDraft.toJson()),
      maxTokens: generateFirstChapter ? 5200 : 3600,
    );

    try {
      final decoded = jsonDecode(_extractJsonObject(raw));
      if (decoded is Map<String, dynamic>) return InspirationBookDraft.fromJson(decoded);
      if (decoded is Map) return InspirationBookDraft.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {
      return _draftFromLooseText(raw, localDraft);
    }
    return localDraft;
  }


  Future<String> distillProjectMemory({
    required AppSettings settings,
    required WritingProject project,
    Chapter? chapter,
    required String scope,
    String extraInstruction = '',
  }) async {
    final selectedChapterBlock = chapter == null
        ? '无'
        : '## ${chapter.title}\n${_compact(chapter.content, 9000)}';

    final sourceBlock = switch (scope) {
      '当前章节' => selectedChapterBlock,
      '小说资料' => _materialsBlock(project),
      '全书上下文' => ''' 
【小说资料】
${_materialsBlock(project)}

【章节节选】
${_chaptersBlock(project)}
''',
      _ => ''' 
【小说资料】
${_materialsBlock(project)}

【章节节选】
${_chaptersBlock(project)}
''',
    };

    final userPrompt = '''
任务：蒸馏长篇小说上下文
作品名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}
蒸馏范围：$scope
目标长度：约 ${settings.distillTargetTokens} tokens
作者补充要求：${extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim()}

【需要蒸馏的来源】
$sourceBlock

请把上面的长上下文压缩成可以长期保存、反复喂给 AI 的「蒸馏记忆」。
必须保留稳定事实、人物状态、能力规则、世界规则、主线进度、伏笔、时间线、文风约束。
必须删除一次性废话、重复解释、无用寒暄、临时推演和已经被否定的方案。

请按以下 Markdown 结构输出：
# 蒸馏记忆

## 本次蒸馏范围
说明本次基于哪些内容蒸馏。

## 稳定设定
只记录已确认、后续不能随意推翻的设定。

## 人物状态
列出主要人物当前身份、目标、关系、秘密、能力限制、情绪状态。

## 世界规则
记录世界底层规则、势力结构、能力/金手指规则、代价和红线。

## 主线进度
记录已经发生的关键事件、当前阶段目标、下一阶段矛盾。

## 伏笔与悬念
用表格列出：伏笔/悬念、埋设位置、状态、建议回收方式。

## 时间线
按先后顺序列出关键事件，标记可能冲突。

## 文风约束
记录应该保持的叙事语气、节奏、对话风格和禁止事项。

## 可丢弃内容
列出已经不需要继续喂给 AI 的旧内容或重复信息。

## 下一步写作提醒
给下一章或下一轮创作的具体提醒。

输出要精炼但信息密度高，不要写“以下是”。
''';

    return complete(
      settings: settings,
      systemPrompt: '蒸馏器：把长篇小说上下文、章节、资料和对话压缩成长期可复用的结构化记忆。',
      userPrompt: userPrompt,
      localFallback: _localDistillFallback(project, chapter, scope),
      maxTokens: settings.distillTargetTokens.clamp(800, 64000).toInt(),
    );
  }

  Future<String> complete({
    required AppSettings settings,
    required String systemPrompt,
    required String userPrompt,
    required String localFallback,
    int maxTokens = 2200,
  }) async {
    final apiKey = settings.aiApiKey.trim();
    if (apiKey.isEmpty) return localFallback;

    try {
      final effectiveSystemPrompt = await _effectiveSystemPrompt(settings, systemPrompt);
      final cleanedUserPrompt = _autoCleanUserPrompt(
        settings: settings,
        systemPrompt: effectiveSystemPrompt,
        userPrompt: userPrompt,
        maxTokens: maxTokens,
      );
      final baseUrl = settings.aiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
      final uri = Uri.parse('$baseUrl/chat/completions');
      final response = await http
          .post(
            uri,
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $apiKey',
            },
            body: jsonEncode({
              'model': settings.aiModel.trim().isEmpty ? 'gpt-4o-mini' : settings.aiModel.trim(),
              'messages': [
                {'role': 'system', 'content': effectiveSystemPrompt},
                {'role': 'user', 'content': cleanedUserPrompt},
              ],
              'temperature': settings.aiTemperature.clamp(0.0, 1.5).toDouble(),
              'max_tokens': maxTokens,
            }),
          )
          .timeout(const Duration(seconds: 60));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw AiException('AI 请求失败：HTTP ${response.statusCode}\n${response.body}');
      }

      final decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      final choices = decoded['choices'];
      if (choices is List && choices.isNotEmpty) {
        final first = choices.first;
        if (first is Map) {
          final message = first['message'];
          if (message is Map && message['content'] is String) {
            final text = (message['content'] as String).trim();
            if (text.isNotEmpty) return text;
          }
          if (first['text'] is String) {
            final text = (first['text'] as String).trim();
            if (text.isNotEmpty) return text;
          }
        }
      }
      throw const AiException('AI 返回为空，请稍后重试。');
    } on TimeoutException {
      throw const AiException('请求超时，请检查网络连接后重试。');
    } on FormatException catch (e) {
      throw AiException('数据解析错误：${e.message}');
    } on http.ClientException catch (e) {
      throw AiException('网络请求失败：${e.message}');
    } catch (e) {
      if (e is AiException) rethrow;
      throw AiException('未知错误：$e');
    }
  }

  String _chatHistoryBlock(AppSettings settings, List<String> history) {
    if (history.isEmpty) return '';
    final source = settings.contextAutoCleanupEnabled && history.length > 80
        ? history.skip(history.length - 80).toList()
        : history;
    final raw = source.join('\n');
    if (!settings.contextAutoCleanupEnabled) return raw;
    final budget = max(1200, (settings.contextCleanupThresholdTokens * 0.32).floor());
    return _trimTextToTokenBudget(raw, budget, label: '对话历史');
  }

  String _autoCleanUserPrompt({
    required AppSettings settings,
    required String systemPrompt,
    required String userPrompt,
    required int maxTokens,
  }) {
    if (!settings.contextAutoCleanupEnabled) return userPrompt;
    final threshold = settings.contextCleanupThresholdTokens;
    final systemTokens = _estimateTokens(systemPrompt);
    final reservedTokens = systemTokens + maxTokens + 900;
    final userBudget = max(1200, threshold - reservedTokens);
    return _trimTextToTokenBudget(userPrompt, userBudget, label: '小说上下文');
  }

  String _trimTextToTokenBudget(String text, int tokenBudget, {required String label}) {
    final estimated = _estimateTokens(text);
    if (estimated <= tokenBudget) return text;

    final ratio = tokenBudget / max(estimated, 1);
    final targetChars = max(900, (text.length * ratio).floor());
    final notice = '\n\n【上下文自动清理】$label 约 $estimated tokens，超过当前阈值预算 $tokenBudget tokens，已省略较早/中段内容；请优先参考保留的任务说明、当前章节和最近内容。\n\n';
    final headChars = min(3200, max(600, (targetChars * 0.18).floor()));
    final tailChars = max(500, targetChars - headChars - notice.length);

    if (text.length <= headChars + tailChars + notice.length) return text;
    final head = text.substring(0, headChars);
    final tail = text.substring(text.length - min(tailChars, text.length));
    return '$head$notice$tail';
  }

  int _estimateTokens(String text) {
    if (text.isEmpty) return 0;
    var cjk = 0;
    var ascii = 0;
    var other = 0;
    for (final unit in text.codeUnits) {
      if ((unit >= 0x3400 && unit <= 0x9FFF) || (unit >= 0xF900 && unit <= 0xFAFF)) {
        cjk += 1;
      } else if (unit <= 0x007F) {
        ascii += 1;
      } else {
        other += 1;
      }
    }
    return cjk + (other * 0.8).ceil() + (ascii / 4).ceil();
  }

  Future<String> _effectiveSystemPrompt(AppSettings settings, String taskPrompt) async {
    final activeSkills = await AiSkillStore.loadActiveSkills();
    final skillBlock = AiSkillStore.activeSkillsSystemBlock(activeSkills.take(40).toList());
    return '''${settings.systemPrompt}

【当前任务说明】
$taskPrompt

【已激活 Skills】
$skillBlock

执行规则：
- 当用户选择某个 Skill 时，优先遵循该 Skill 的提示词、工作流和输出格式。
- 如果多个 Skill 相关，按任务目标组合使用，但不要输出内部分析过程。
- 若上下文不足，给出可执行的补充建议，不要编造已经写入本地文件的事实。''';
  }

  String _materialsBlock(WritingProject project) {
    if (project.notes.isEmpty) return '无';
    return project.notes
        .take(40)
        .map((note) => '## ${note.title}\n${_compact(note.body, 1100)}')
        .join('\n\n');
  }

  String _chaptersBlock(WritingProject project) {
    if (project.chapters.isEmpty) return '无';
    return project.chapters
        .take(80)
        .map((chapter) => '- ${chapter.title}：${_compact(chapter.content, 520)}')
        .join('\n');
  }

  String _extractJsonObject(String raw) {
    var text = raw.trim();
    if (text.startsWith('```')) {
      text = text.replaceFirst(RegExp(r'^```(?:json)?\s*', multiLine: true), '');
      text = text.replaceFirst(RegExp(r'\s*```\s*$', multiLine: true), '');
    }
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start >= 0 && end > start) return text.substring(start, end + 1);
    return text;
  }

  InspirationWorldSeed _worldSeedFromLooseText(String raw, InspirationWorldSeed fallback) {
    final clean = raw.trim();
    if (clean.isEmpty) return fallback;
    return fallback.copyWith(
      worldview: '# 世界观草案\n\n$clean',
      nextStepHint: 'AI 没有返回标准 JSON，已把原文放入世界观草案。你可以编辑后继续创建小说。',
    );
  }

  InspirationWorldSeed _localWorldSeed(String inspiration) {
    final clean = inspiration.trim().isEmpty ? '一个普通人卷入异常世界，并用自己的方法改变规则。' : inspiration.trim();
    final titleBase = _guessTitle(clean);
    return InspirationWorldSeed(
      expandedInspiration: '''$clean

这个灵感可以扩展成一部长篇：主角最初只是被异常事件推到规则边缘，他以为自己只要完成一次任务就能回到普通生活，却发现事件背后存在一整套隐藏秩序。旧势力依赖这套秩序维持利益，普通人只能在规则缝隙里承受后果。主角的优势不是天生无敌，而是能用现代经验、观察力和不按套路的解决方式拆解旧规则。随着一次次处理事件，他逐渐从“被选中的临时变量”成长为能重新制定边界的人。''',
      worldview: '''# 世界观草案

## 世界底层规则

- 现实世界之外存在一套隐藏秩序，普通人通常看不见，只会感受到异常后果。
- 隐藏秩序并非全知全能，它依赖执行者、契约、档案、权限和代价运转。
- 主角进入系统后，既能借用部分权限，也会被旧规则追责。

## 现实侧/隐秘侧

- 现实侧：主角的生活、工作、亲友关系，是情感牵引和危机外溢的来源。
- 隐秘侧：规则执行机构、旧势力、漏洞商人、被规则压制的人。
- 缝隙地带：两套秩序交界处，最适合产生案件、交易、反转和伏笔。

## 势力结构

- 旧规则维护者：强调稳定，反感主角这种新变量。
- 漏洞利用者：利用规则缺陷牟利，是前中期持续冲突来源。
- 中立观察者：知道真相但不站队，可作为信息源和潜在反转点。
- 主角阵营：从单人应对逐渐发展成小团队。

## 能力/金手指规则

- 主角可以临时调用某种权限，但每次调用都要留下记录或付出代价。
- 能力不能无条件碾压，只能解决“规则允许被撬动”的部分。
- 越接近世界底层真相，代价越高，敌人越强。

## 代价与限制

- 代价可以是记忆、时间、人情债、身份暴露、现实关系受损或被旧势力标记。
- 关键信息不能凭空获得，必须通过行动、交换、推理或牺牲得到。
- 主角不能长期逃避现实侧牵挂，否则人物会失去情感锚点。

## 长篇可扩展空间

- 单章案件：每章解决一个具体问题。
- 卷级矛盾：每卷揭开一个更大的规则漏洞。
- 主线真相：主角为什么被选中、原执行者为何失踪、旧秩序是否必须被取代。''',
      coreConflict: '主角想先自保并保护身边人，但旧秩序要求所有变量服从既有规则；主角每次用新方法解决问题，都会暴露更深层的漏洞，也会被更强的势力盯上。',
      protagonistSeed: '主角原本是普通人，擅长从现实经验中寻找规则漏洞。优点是冷静、会观察、不盲从权威；缺点是早期经验不足，容易低估隐秘世界的代价。成长线是从被迫接单，到主动制定规则。',
      uniqueSettings: '''- 用现实逻辑拆解隐藏秩序，而不是单纯打怪升级。
- 每个案件都暴露一个规则漏洞，既有爽点也有主线推进。
- 能力必须付出代价，避免无脑碾压。
- 现实牵挂和隐秘任务互相挤压，制造长篇张力。
- 旧秩序不是纯反派，它有存在理由，方便后期反转。''',
      readerPromise: '看主角用新规则撬动旧秩序，在一个个案件中升级、破局、揭开真相。',
      titleOptions: [
        titleBase,
        '我在异常世界当代理人',
        '临时规则执行官',
        '规则之外的代理人',
        '旧秩序维修手册',
      ],
      genreOptions: const [
        '都市脑洞 / 长篇爽文',
        '悬疑奇幻 / 规则怪谈',
        '轻松吐槽 / 职场升级',
      ],
      styleTemplates: const [
        '快节奏、强冲突、手机端易读；每章解决一个具体问题，结尾留下更大悬念。',
        '轻松吐槽、爽点明确；对话有现代感，主角用现实规则反制旧秩序。',
        '悬疑氛围更强；信息分层释放，世界真相逐步揭开，避免过早解释全部设定。',
      ],
      nextStepHint: '先确认世界观是否满意；满意后选择书名、类型和文风模板，再创建人物库、大纲、章节卡和开篇。',
    );
  }

  InspirationBookDraft _localBookDraftFromWorldSeed({
    required String originalInspiration,
    required InspirationWorldSeed worldSeed,
    required String title,
    required String genre,
    required String style,
    required bool generateFirstChapter,
  }) {
    final cleanTitle = title.trim().isEmpty ? worldSeed.titleOptions.first : title.trim();
    final cleanGenre = genre.trim().isEmpty ? worldSeed.genreOptions.first : genre.trim();
    final cleanStyle = style.trim().isEmpty ? worldSeed.styleTemplates.first : style.trim();
    final firstTitle = '第1章 临时上任';
    final firstChapter = generateFirstChapter
        ? '''$firstTitle

手机屏幕亮起时，主角还以为那只是一条普通通知。

可通知栏里没有应用图标，只有一行像是直接刻进屏幕里的字：

【你已被临时选中，请在三分钟内完成第一次处理。】

他盯着那行字看了两秒，第一反应不是害怕，而是荒唐。这个世界每天都有太多骗局，快递、中奖、贷款、冒充客服，花样多到让人懒得生气。

直到房间里的灯忽然灭了。

窗外的城市还亮着，楼下车流照常穿过路口，远处便利店的招牌闪了一下又恢复稳定。停电的只有他的房间。

下一秒，门外传来敲门声。

咚。

咚。

咚。

每一下都不重，却像敲在他的后颈上。主角握住门把手，屏幕上的倒计时已经跳到两分二十一秒。

【请开门。】

他没有立刻照做，而是深吸一口气，先把手机录音打开，又把桌上的金属书挡在胸前。

门开了一道缝。

外面站着的不是邻居，也不是物业。那人穿着不合季节的黑色外套，脸色白得像许久没见过太阳。他抬起眼，声音沙哑：

“轮到你签收了。”

主角低头，看见对方递来的不是快递盒，而是一份泛黄的委托书。

委托书第一页写着他的名字。

第二页写着一个他从没去过的地点。

第三页只有一句话：

【规则已经失效，临时代理人即刻上任。】

倒计时归零。

房间深处，某个不属于现实的声音笑了起来。'''
        : '';

    return InspirationBookDraft(
      title: cleanTitle,
      genre: cleanGenre,
      description: worldSeed.readerPromise,
      sellingPoints: '''# 核心卖点

- 原始灵感：$originalInspiration
- 读者承诺：${worldSeed.readerPromise}
- 核心冲突：${worldSeed.coreConflict}
- 类型定位：$cleanGenre
- 文风方向：$cleanStyle
- 追读动力：每章处理一个具体事件，同时揭开更大的规则漏洞。''',
      worldview: worldSeed.worldview.replaceFirst('世界观草案', '世界观'),
      characters: '''# 人物库

## 主角

${worldSeed.protagonistSeed}

### 外在目标

- 先活下来，弄清自己为什么被选中。
- 保护现实侧牵挂，不让异常外溢。
- 学会利用规则漏洞，而不是被旧秩序牵着走。

### 内在成长

- 从临时应对，到主动调查。
- 从害怕暴露，到建立自己的规则边界。
- 从单人破局，到组织可信赖的小团队。

## 关键配角

- 引路人：知道部分真相，但隐瞒关键代价。
- 现实牵挂：主角不能放弃普通生活的理由。
- 竞争者：同样接触隐秘秩序，但选择更激进方式。

## 阻碍者/反派

- 旧规则维护者：认为主角会破坏稳定。
- 漏洞利用者：借规则缺陷牟利。
- 幕后黑手：与主角被选中和原执行者失踪有关。''',
      outline: '''# 大纲

## 主线

$cleanTitle 讲述主角因“$originalInspiration”进入隐藏秩序，从临时变量逐步成长为能改写规则的人。

## 第一卷：被迫入局

- 第1章：异常通知出现，主角第一次接触隐藏规则。
- 第2章：主角完成第一次任务，却发现奖励背后藏着限制。
- 第3章：引路人出现，告诉主角他只是临时替补。
- 卷末钩子：真正的原执行者失踪，而线索指向主角身边的人。

## 第二卷：规则漏洞

- 主角尝试用现实经验拆解隐秘规则。
- 旧势力开始关注他。
- 竞争者登场，证明主角不是唯一被选中的人。
- 卷末钩子：主角发现自己一直在替某个存在补漏洞。

## 第三卷：主动改写

- 主角建立自己的小团队。
- 伏笔开始回收，现实侧和隐秘侧冲突合流。
- 主角必须决定：修补旧秩序，还是建立新秩序。

## 结局方向

主角不再只是临时代理人，而是成为能制定边界的人；结局保留更大世界入口，方便续写。''',
      foreshadowing: '''# 伏笔库

| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |
|---|---|---|---|---|
| 主角为什么被选中 | 第1章 | 第一卷末/第二卷中 | 未回收 | 与原执行者失踪有关 |
| 通知来源 | 第1章 | 第二卷 | 未回收 | 不是普通系统 |
| 引路人隐瞒的信息 | 第3章 | 第二卷末 | 未回收 | 会造成信任危机 |
| 能力代价 | 第1-3章 | 持续回收 | 进行中 | 每次使用都要留下痕迹 |''',
      timeline: '''# 时间线

- 故事开始前：隐藏秩序出现漏洞，原执行者失踪。
- 第1天：主角收到异常通知，被迫第一次处理事件。
- 第一卷前半：主角学习基本规则，发现代价。
- 第一卷后半：现实侧被卷入，主角开始主动调查。
- 第二卷：旧势力下场，主角发现更深漏洞。
- 第三卷：现实侧与隐秘侧冲突合流，主角改写边界。''',
      lockedSettings: '''# 禁止改动设定

- 书名：$cleanTitle
- 类型：$cleanGenre
- 主角核心身份：由原始灵感“$originalInspiration”触发，不能改成完全无关身份。
- 世界底层规则：隐秘秩序依赖规则、权限、代价运转；不能无条件许愿式解决问题。
- 能力限制：每次使用能力都要留下成本、记录或风险。
- 文风红线：$cleanStyle
- 叙事红线：不要让 AI 用总结代替场景，不要连续空转水文。''',
      styleTemplate: '''# 文风模板

## 作者选择

$cleanStyle

## 执行规则

- 手机端阅读优先，段落短，动作和对话推进剧情。
- 每章至少有一个明确目标、一个冲突升级、一个情绪点或爽点。
- 解释设定时必须放进场景和冲突里，不要长篇说明。
- 章节结尾保留钩子，但不要故意断在无意义处。

## 禁止事项

- 不要突然散文化。
- 不要无代价开挂。
- 不要把人物写成只会解释设定的工具人。''',
      chapterCards: '''# 章节卡片

## 第1章 临时上任

- 本章目标：让主角接触异常通知，被迫接下第一次任务。
- 出场人物：主角、异常送达者/执行者。
- 核心冲突：主角想把它当骗局处理，但现实开始失效。
- 爽点/情绪点：主角没有立刻慌乱，而是用现实经验反制异常。
- 结尾钩子：委托书确认主角成为临时代理人。

## 第2章 第一次处理

- 本章目标：主角完成第一个小任务，理解规则有代价。
- 核心冲突：任务看似简单，实则牵出规则漏洞。
- 爽点/情绪点：主角用非常规方法找到漏洞。
- 结尾钩子：奖励到账，但同时出现惩罚记录。

## 第3章 引路人

- 本章目标：引路人登场，给主角解释部分真相。
- 核心冲突：主角不信任对方，对方也隐瞒关键代价。
- 爽点/情绪点：主角第一次主动提出规则交易。
- 结尾钩子：原执行者失踪档案出现主角名字。''',
      firstChapterTitle: firstTitle,
      firstChapterContent: firstChapter,
      incubationReport: '''# 灵感成书报告

## 原始灵感

$originalInspiration

## 已确认世界观

${worldSeed.expandedInspiration}

## 作者选择

- 书名：$cleanTitle
- 类型：$cleanGenre
- 文风模板：$cleanStyle

## 已生成内容

- 世界观
- 人物库
- 大纲
- 伏笔库
- 时间线
- 禁止改动设定
- 文风模板
- 前三章章节卡
- ${generateFirstChapter ? '第1章正文' : '第1章章节卡'}

## 下一步建议

先打开《世界观》和《禁止改动设定》确认底层规则，再进入《第1章》继续写作。''',
    );
  }

  InspirationBookDraft _draftFromLooseText(String raw, InspirationBookDraft fallback) {
    return InspirationBookDraft(
      title: fallback.title,
      genre: fallback.genre,
      description: fallback.description,
      sellingPoints: fallback.sellingPoints,
      worldview: fallback.worldview,
      characters: fallback.characters,
      outline: raw.trim().isEmpty ? fallback.outline : '# AI 灵感孵化原文\n\n${raw.trim()}',
      foreshadowing: fallback.foreshadowing,
      timeline: fallback.timeline,
      lockedSettings: fallback.lockedSettings,
      styleTemplate: fallback.styleTemplate,
      chapterCards: fallback.chapterCards,
      firstChapterTitle: fallback.firstChapterTitle,
      firstChapterContent: fallback.firstChapterContent,
      incubationReport: '${fallback.incubationReport}\n\n## 解析提示\nAI 没有返回标准 JSON，已把原文保存进《大纲》。',
    );
  }

  InspirationBookDraft _localInspirationBookDraft({
    required String inspiration,
    required String genre,
    required String style,
    required bool generateFirstChapter,
  }) {
    final cleanInspiration = inspiration.trim().isEmpty ? '一个普通人卷入异常世界，并用自己的方法改变规则。' : inspiration.trim();
    final cleanGenre = genre.trim().isEmpty ? '长篇小说' : genre.trim();
    final cleanStyle = style.trim().isEmpty ? '快节奏、强冲突、适合连载，有清晰章节钩子' : style.trim();
    final title = _guessTitle(cleanInspiration);
    final firstTitle = '第1章 异常的开始';
    final firstChapter = generateFirstChapter
        ? '''${firstTitle}

手机屏幕亮起时，主角还以为那只是一条普通通知。

可通知栏里没有应用图标，只有一行像是直接刻进屏幕里的字：

【你已被临时选中，请在三分钟内完成第一次处理。】

他盯着那行字看了两秒，第一反应不是害怕，而是荒唐。这个世界每天都有太多骗局，快递、中奖、贷款、冒充客服，花样多到让人懒得生气。

直到房间里的灯忽然灭了。

窗外的城市还亮着，楼下车流照常穿过路口，远处便利店的招牌闪了一下又恢复稳定。停电的只有他的房间。

下一秒，门外传来敲门声。

咚。

咚。

咚。

每一下都不重，却像敲在他的后颈上。主角握住门把手，屏幕上的倒计时已经跳到两分二十一秒。

【请开门。】

他没有立刻照做，而是深吸一口气，先把手机录音打开，又把桌上的金属书挡在胸前。

门开了一道缝。

外面站着的不是邻居，也不是物业。那人穿着不合季节的黑色外套，脸色白得像许久没见过太阳。他抬起眼，声音沙哑：

“轮到你签收了。”

主角低头，看见对方递来的不是快递盒，而是一份泛黄的委托书。

委托书第一页写着他的名字。

第二页写着一个他从没去过的地点。

第三页只有一句话：

【规则已经失效，临时代理人即刻上任。】

倒计时归零。

房间深处，某个不属于现实的声音笑了起来。'''
        : '';

    return InspirationBookDraft(
      title: title,
      genre: cleanGenre,
      description: cleanInspiration.length > 78 ? '${cleanInspiration.substring(0, 78)}…' : cleanInspiration,
      sellingPoints: '''# 核心卖点

- 灵感核心：$cleanInspiration
- 类型定位：$cleanGenre
- 追读动力：主角每解决一个问题，都会牵出更大的规则漏洞。
- 情绪体验：用清晰目标、强冲突和结尾钩子推动连续阅读。
- 差异化：让主角用自己的现代经验/特殊视角改写既有秩序。''',
      worldview: '''# 世界观

## 基础规则

- 故事从一个异常事件切入，主角被迫进入隐藏在现实背后的系统/组织/规则。
- 这个世界有明确秩序，但秩序正在松动，主角的出现会触发连锁反应。
- 每次使用能力或改变规则都必须付出代价，代价可以是时间、记忆、人情、寿命、身份暴露或阵营敌意。

## 地点与势力

- 现实侧：主角日常生活的城市、工作/学校、人际关系。
- 隐秘侧：掌握规则的机构、旧势力、执行者和被规则压制的人。
- 灰色侧：利用漏洞牟利的人、知道真相却不站队的人。

## 限制与代价

- 主角不能无成本解决问题。
- 每个新能力必须有适用范围和反噬。
- 关键情报不能凭空出现，需要通过行动、交易或代价获得。''',
      characters: '''# 人物库

## 主角

- 身份：被灵感事件卷入的普通人/临时代理人。
- 外在目标：先活下来，再弄清自己为什么被选中。
- 内在欲望：证明自己不是被命运随意摆布的人。
- 弱点：经验不足，容易用现实逻辑误判隐秘规则。
- 成长方向：从被迫应对，到主动制定规则。

## 关键配角

- 引路人：知道部分真相，但隐藏核心信息。
- 现实牵挂：让主角不能彻底脱离普通生活。
- 竞争者：和主角同样接触规则，却选择更激进的道路。

## 阻碍者/反派

- 旧规则维护者：认为主角的存在会破坏秩序。
- 漏洞利用者：借混乱牟利，是前中期主要冲突来源。
- 幕后黑手：与主角被选中的原因有关。''',
      outline: '''# 大纲

## 主线

主角因“$cleanInspiration”进入异常秩序，起初只是为了自保，随后发现自己被选中并非偶然。随着事件升级，他必须在旧规则、现实牵挂和个人选择之间找到新的道路。

## 第一卷：被迫入局

- 第1章：异常通知出现，主角第一次接触隐藏规则。
- 第2章：主角完成第一次任务，却发现奖励背后藏着限制。
- 第3章：引路人出现，告诉主角他只是临时替补。
- 卷末钩子：真正的原代理人失踪，而线索指向主角身边的人。

## 第二卷：规则漏洞

- 主角尝试用现实经验拆解隐秘规则。
- 旧势力开始关注他。
- 竞争者登场，证明主角不是唯一被选中的人。
- 卷末钩子：主角发现自己一直在替某个存在补漏洞。

## 第三卷：主动改写

- 主角建立自己的小团队。
- 伏笔开始回收，现实侧和隐秘侧冲突合流。
- 主角必须决定：修补旧秩序，还是建立新秩序。

## 结局方向

主角不再只是临时代理人，而是成为能制定边界的人；结局保留更大世界入口，方便续写。''',
      foreshadowing: '''# 伏笔库

| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |
|---|---|---|---|---|
| 主角为什么被选中 | 第1章 | 第一卷末/第二卷中 | 未回收 | 与原代理人失踪有关 |
| 通知来源 | 第1章 | 第二卷 | 未回收 | 不是普通系统 |
| 引路人隐瞒的信息 | 第3章 | 第二卷末 | 未回收 | 会造成信任危机 |
| 能力代价 | 第1-3章 | 持续回收 | 进行中 | 每次使用都要留下痕迹 |''',
      timeline: '''# 时间线

- 故事开端：主角收到异常通知，被迫处理第一次事件。
- 第一阶段：主角学习规则，完成数个小任务。
- 第二阶段：旧势力介入，主角身份暴露风险增加。
- 第三阶段：主角发现被选中的真正原因。
- 第四阶段：主角主动改写规则，解决核心矛盾。''',
      lockedSettings: '''# 禁止改动设定

- 主角核心身份：由灵感“$cleanInspiration”触发，不能随意改成完全无关身份。
- 能力规则：每次解决问题都必须有边界和代价，禁止无敌开挂。
- 世界底层规则：现实侧和隐秘侧互相影响，但普通人不能轻易知道全貌。
- 文风红线：不要变成空泛说明文，不要忽略冲突和章节钩子。
- 连载原则：每章都要有明确目标、阻碍、变化和下一章承接。''',
      styleTemplate: '''# 文风模板

## 叙事语气

$cleanStyle

## 节奏要求

- 开头尽快进入场景和异常。
- 每章至少有一次信息反转或局势升级。
- 正文少解释，多用行动、对话和具体细节推动。

## 对话风格

- 主角语言偏现实、机敏，有自我保护意识。
- 隐秘侧人物说话要带规则感和压迫感。
- 避免所有角色都像旁白。

## 禁止事项

- 不要 AI 总结腔。
- 不要连续堆设定。
- 不要让主角轻易得到无代价答案。''',
      chapterCards: '''# 章节卡片

## 第1章 异常的开始

- 本章目标：让主角第一次接触异常事件，并被迫接受任务。
- 出场人物：主角、异常送信人/执行者。
- 核心冲突：主角想拒绝，但倒计时和现实异常迫使他行动。
- 爽点/情绪点：主角没有盲目服从，而是用现实办法自保。
- 结尾钩子：委托书显示主角已成为临时代理人。

## 第2章 第一次处理

- 本章目标：主角完成第一次小任务，理解规则不是玩笑。
- 核心冲突：任务看似简单，实际需要在规则漏洞中做选择。
- 爽点/情绪点：主角用非传统方式破局。
- 结尾钩子：任务奖励暴露出原代理人失踪线索。

## 第3章 引路人

- 本章目标：引路人出现，解释部分世界规则。
- 核心冲突：主角需要情报，但不能完全信任对方。
- 爽点/情绪点：主角反过来套出对方隐瞒的一点信息。
- 结尾钩子：旧势力开始记录主角。''',
      firstChapterTitle: firstTitle,
      firstChapterContent: firstChapter,
      incubationReport: '''# 灵感孵化报告

## 原始灵感

$cleanInspiration

## 已生成内容

- 小说名：$title
- 小说类型：$cleanGenre
- 核心卖点
- 世界观
- 人物库
- 主线大纲
- 前三章章节卡
- 第1章正文${generateFirstChapter ? '' : '（未生成，仅保留章节卡）'}

## 下一步建议

1. 打开《小说资料》检查世界观、人物库、禁止改动设定。
2. 打开《章节内容》第1章，继续扩写或润色。
3. 进入“长篇”模式，执行“写完归档”和“一致性检查”。''',
    );
  }

  String _guessTitle(String inspiration) {
    final text = inspiration.trim();
    if (text.contains('地府')) return '我在地府当代理人';
    if (text.contains('修仙')) return '我把修仙界整顿成公司';
    if (text.contains('末日')) return '末日临时管理员';
    if (text.contains('系统')) return '异常系统使用手册';
    if (text.contains('AI') || text.contains('人工智能')) return '失控智能纪元';
    if (text.contains('穿越')) return '穿越后我改写旧规则';
    return '规则之外的临时代理人';
  }

  String _localLongFormFallback(
    String taskName,
    WritingProject project,
    Chapter? chapter,
    String instruction,
    String draftCard,
  ) {
    final currentTitle = chapter?.title ?? '下一章';
    if (taskName.contains('小说大脑')) {
      return '''【本地小说大脑模板｜未连接 AI】

# 小说大脑补全建议

## 主线
- 主角当前目标：
- 阶段阻力：
- 最终矛盾：

## 角色
- 主角：身份｜欲望｜弱点｜秘密｜变化方向
- 关键配角：功能｜与主角关系｜可制造的冲突

## 世界规则
- 核心规则：
- 限制与代价：
- 可被主角利用的漏洞：

## 伏笔
- 近期伏笔：
- 中期伏笔：
- 长期伏笔：

补充要求：${instruction.trim().isEmpty ? '无' : instruction.trim()}''';
    }
    if (taskName.contains('章节卡')) {
      return '''【本地章节卡模板｜未连接 AI】

章节名：$currentTitle
本章目标：让主角面对一个必须立刻处理的问题。
出场人物：主角、关键阻碍者、信息提供者
核心冲突：主角想推进目标，但已有规则/人物立场形成阻碍。
爽点/情绪点：主角用独特方式破局，让读者获得期待感。
关键场景：
1. 开场压力
2. 信息揭示
3. 冲突升级
4. 主角选择
5. 结尾钩子
结尾钩子：暴露一个更大的未解问题。
字数目标：2500～3500字
写作禁忌：不要违背小说资料里的硬设定。''';
    }
    if (taskName.contains('正文')) {
      return '''【本地正文占位｜未连接 AI】

${draftCard.trim().isEmpty ? '他推开门，意识到眼前的局面比预想中更糟。' : '他按照本章任务单推进剧情，先处理眼前冲突，再留下下一章钩子。'}

这不是一次普通的选择。每一个细节都在提醒他，如果这一步走错，之前所有铺垫都会变成反噬。

可他还是向前走了一步。

因为退路，从一开始就不存在。''';
    }
    if (taskName.contains('总结') || taskName.contains('归档')) {
      return '''【本地章节归档模板｜未连接 AI】

## ${chapter?.title ?? '本章'}

### 剧情进展
- 本章推进了主线目标。

### 人物变化
- 主角做出选择，暴露新的能力/弱点。

### 新增设定
- 记录本章出现的新规则、地点、组织或道具。

### 新增伏笔
- 伏笔：
- 埋设章节：${chapter?.title ?? currentTitle}
- 回收计划：

### 下一章承接
- 让上章结尾问题立刻产生后果。''';
    }
    if (taskName.contains('一致性') || taskName.contains('质检')) {
      return '''【本地长篇质检清单｜未连接 AI】

1. 检查人物姓名、称呼、能力是否前后一致。
2. 检查主角目标是否偏离大纲。
3. 检查时间线是否出现同一人物同时在两地。
4. 检查伏笔是否长期未回收。
5. 检查章节是否缺少冲突、代价和结尾钩子。
6. 检查文风是否突然漂移。

当前未连接 API，配置 API Key 后会返回具体问题清单。''';
    }
    return '''【本地长篇创作模板｜未连接 AI】

任务：$taskName
作品：${project.title}
当前章节：$currentTitle

请配置 API Key 后使用完整长篇创作模式。''';
  }

  String _contextBlock({
    required WritingProject project,
    required Chapter chapter,
    required AiContextMode contextMode,
    required String selectedText,
  }) {
    final notes = project.notes
        .take(30)
        .map((note) => '[${note.tag}] ${note.title}: ${_compact(note.body, 520)}')
        .join('\n');

    if (contextMode == AiContextMode.selection && selectedText.trim().isNotEmpty) {
      return '''
设定资料：
${notes.isEmpty ? '无' : notes}

当前章节：${chapter.title}
选中文本：
${_compact(selectedText, 5200)}
''';
    }

    if (contextMode == AiContextMode.project) {
      final chapters = project.chapters
          .map((item) => '- ${item.title}：${_compact(item.content, 620)}')
          .join('\n');
      return '''
设定资料：
${notes.isEmpty ? '无' : notes}

全书章节摘要/节选：
${chapters.isEmpty ? '无' : chapters}

当前章节：${chapter.title}
当前章节全文节选：
${_compact(chapter.content, 4200)}
''';
    }

    return '''
设定资料：
${notes.isEmpty ? '无' : notes}

当前章节：${chapter.title}
当前正文：
${_compact(chapter.content, 6200)}
''';
  }

  String _projectBrief(WritingProject project) {
    final notes = project.notes.take(12).map((note) => '- ${note.title}: ${_compact(note.body, 240)}').join('\n');
    final chapters = project.chapters.take(30).map((chapter) => '- ${chapter.title}: ${_compact(chapter.content, 240)}').join('\n');
    return '''
《${project.title}》
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}

资料：
${notes.isEmpty ? '无' : notes}

章节：
${chapters.isEmpty ? '无' : chapters}
''';
  }

  String _bookAnalysisSourceBlock(WritingProject project, String depthLabel) {
    final perChapter = depthLabel == '深度' ? 1000 : depthLabel == '标准' ? 920 : 560;
    final selected = _selectBookAnalysisChapters(project, depthLabel);
    if (selected.isEmpty) return '无章节正文';
    return selected.map((chapter) {
      return '## ${chapter.title}\n${_analysisSlice(chapter.content, perChapter)}';
    }).join('\n\n---\n\n');
  }

  List<Chapter> _selectBookAnalysisChapters(WritingProject project, String depthLabel) {
    final chapters = project.chapters;
    if (chapters.isEmpty) return const [];
    final indexes = <int>{};

    void addRange(int start, int end) {
      for (var i = start; i < end && i < chapters.length; i++) {
        if (i >= 0) indexes.add(i);
      }
    }

    addRange(0, depthLabel == '快速' ? 8 : depthLabel == '标准' ? 20 : 30);

    final tailCount = depthLabel == '快速' ? 3 : depthLabel == '标准' ? 5 : 12;
    addRange(max(0, chapters.length - tailCount), chapters.length);

    if (depthLabel != '快速' && chapters.length > 12) {
      final samples = depthLabel == '深度' ? 18 : 8;
      for (var i = 1; i <= samples; i++) {
        indexes.add(((chapters.length - 1) * i / (samples + 1)).round());
      }
    }

    if (depthLabel == '深度') {
      for (final fixed in const [0, 1, 2, 4, 9, 19, 29, 49, 79, 119]) {
        if (fixed < chapters.length) indexes.add(fixed);
      }
    }

    final ordered = indexes.toList()..sort();
    final hardLimit = depthLabel == '深度' ? 48 : depthLabel == '标准' ? 36 : 14;
    return ordered.take(hardLimit).map((index) => chapters[index]).toList();
  }

  String _analysisSlice(String value, int maxChars) {
    final text = value.trim();
    if (text.length <= maxChars) return text;
    final headChars = max(120, (maxChars * 0.55).floor());
    final tailChars = max(100, (maxChars * 0.35).floor());
    final middleChars = max(80, maxChars - headChars - tailChars - 42);
    final middleStart = ((text.length - middleChars) / 2)
        .floor()
        .clamp(headChars, max(headChars, text.length - tailChars - middleChars))
        .toInt();
    final head = text.substring(0, min(headChars, text.length));
    final middleEnd = min(text.length - tailChars, middleStart + middleChars);
    final middle = text.substring(middleStart, max(middleStart, middleEnd));
    final tail = text.substring(max(0, text.length - tailChars));
    return '$head\n\n……中段抽样……\n$middle\n\n……结尾断点样本……\n$tail';
  }

  String _localBookAnalysisFallback(
    WritingProject project,
    String moduleTitle,
    String moduleTemplate,
    String depthLabel,
  ) {
    return '''# $moduleTitle

> 本地模板模式：当前未连接联网 AI。以下为可编辑的拆书报告骨架；填写 API Key 后会生成真实的爆款拆解。
> 分析对象：《${project.title}》；深度：$depthLabel；章节数：${project.chapters.length}；总字数：${project.totalCharacters}。

$moduleTemplate

## 本地填写提示
- 不要复述剧情，要记录“为什么能追读”。
- 每个栏目建议写：观察 → 判断 → 可复用做法。
- 重点提取：主角欲望、读者情绪、爽点闭环、断章钩子、付费点。
''';
  }

  InspirationBookDraft _localMethodologyBookDraft(WritingProject sourceProject, String methodology) {
    return InspirationBookDraft(
      title: '规则之外的新秩序',
      genre: sourceProject.genre,
      description: '一个普通人借由规则漏洞破局，逐步重建秩序的长篇爽文。',
      sellingPoints: '''# 核心卖点

## 读者承诺
- 主角持续发现规则、利用规则、重写规则。
- 每一卷都有明确目标、强压迫、阶段胜利和更大悬念。

## 差异化
- 复用来源作品的方法论，不复用人物、剧情、专有名词。
- 把“爆款机制”落成可执行爽点闭环。

## 爽点闭环
压迫 → 误判主角 → 主角找漏洞 → 低成本反击 → 获得资源/名望/线索 → 新危机。''',
      worldview: '''# 世界观

## 基础规则
- 世界存在一套可被观察、可被利用、但不能无代价突破的规则系统。

## 势力结构
- 旧规则维护者、漏洞利用者、中立观察者、主角阵营。

## 代价与限制
- 每次调用规则都会留下记录、人情债、身份暴露或现实关系受损。

## 长篇扩展空间
- 单章解决具体危机；每卷拆掉一层旧秩序。''',
      characters: '''# 人物库

## 主角
- 标签：清醒、能忍、会算账、有底线。
- 弧光：从求生者到秩序制定者。

## 配角体系
- 信息型伙伴、行动型伙伴、情绪锚点、利益同盟。

## 反派/阻碍者
- 不是单纯作恶，而是依赖旧规则获利。

## 人物关系网
- 用秘密、债务、误会和共同利益制造张力。''',
      outline: _localMethodologyNovelFallback(sourceProject, methodology),
      foreshadowing: '''# 伏笔库

| 伏笔 | 埋设章节 | 回收章节 | 状态 | 备注 |
|---|---|---|---|---|
| 主角第一次使用规则留下异常记录 | 第1章 | 第20章左右 | 未回收 | 引出旧势力追踪 |
| 配角知道规则漏洞但隐瞒代价 | 第3章 | 第12章左右 | 未回收 | 制造信任危机 |
| 旧规则维护者内部并不统一 | 第一卷中段 | 第一卷末 | 未回收 | 卷末反转 |''',
      timeline: '''# 时间线

- 开篇：主角被异常事件推入局。
- 第一阶段：主角发现规则漏洞，完成第一次小胜利。
- 第二阶段：对手升级，代价显现，主角组建小团队。
- 第三阶段：主角拆穿旧势力一层规则，获得阶段胜利。
- 后续：更高层规则和真实代价浮出水面。''',
      lockedSettings: '''# 禁止改动设定

- 主角核心身份：普通起点，被迫入局，靠观察和选择破局。
- 能力/金手指限制：不能无代价碾压，每次使用都要留下后果。
- 世界底层规则：规则可利用但不可随意推翻。
- 不能照搬来源作品：人物、剧情、专有名词、标志性桥段必须全部原创。''',
      styleTemplate: '''# 文风模板

## 叙事语气
- 快节奏、强目标、手机端易读。

## 节奏要求
- 每章有目标、阻力、获得感或新悬念。
- 每 3-5 章完成一个小闭环。

## 对话风格
- 对话推动信息差和人物关系，不做说明书式解释。

## 禁止事项
- 不要复述设定。
- 不要 AI 总结腔。
- 不要让主角无代价开挂。''',
      chapterCards: '''# 章节卡片

## 第1章
- 目标：主角被异常事件推入局。
- 冲突：旧规则压迫，普通方法失效。
- 爽点：主角发现一个小漏洞并完成第一次反击。
- 结尾钩子：这次反击留下了不可消除的记录。

## 第2章
- 目标：主角弄清代价和规则边界。
- 冲突：对手误判主角，现实关系受到牵连。
- 爽点：主角用信息差低成本破局。
- 结尾钩子：更高权限者注意到主角。

## 第3章
- 目标：主角第一次主动设计反击。
- 冲突：伙伴隐瞒关键信息。
- 爽点：反转压迫者，获得第一份资源。
- 结尾钩子：旧规则维护者内部出现分歧。''',
      firstChapterTitle: '第1章 规则之外',
      firstChapterContent: '',
      incubationReport: '''# 拆书方法论新书生成报告

## 来源方法
- 来源：《${sourceProject.title}》拆书方法论。

## 已复用结构
- 赛道定位、爽点闭环、人设弧光、章节断点和追更机制。

## 已规避元素
- 不复用来源作品人物、剧情、地点、专有名词和标志性桥段。

## 下一步建议
- 先完善世界观和人物库，再用章节卡片逐章写正文。''',
    );
  }

  String _localMethodologyNovelFallback(WritingProject sourceProject, String methodology) {
    return '''# 新小说创作方案

> 本地模板模式：当前未连接联网 AI。以下方案使用《${sourceProject.title}》拆书方法论作为结构模板，但需要你手动改写成全新设定。

## 书名候选
- 逆序成神
- 我靠规则漏洞改写世界
- 长夜之后我重建秩序

## 赛道与读者
- 赛道：${sourceProject.genre} 的强情绪、强目标、强升级变体。
- 读者：喜欢主角主动破局、连续爽点和阶段性胜利的长篇读者。

## 核心卖点
- 主角不是被动升级，而是持续发现规则、利用规则、重写规则。
- 每卷都有明确问题、对手和情绪承诺。

## 世界观差异化
- 保留“可复用机制”，替换全部人物、地点、势力、能力名称和关键事件。

## 主角人设
- 标签：清醒、能忍、会算账、有底线。
- 弧光：从求生者到秩序制定者。

## 开篇三章设计
1. 第一章：异常事件 + 主角被迫入局 + 小胜利。
2. 第二章：规则代价 + 对手压迫 + 新目标。
3. 第三章：第一次反转 + 爽点闭环 + 更大悬念。

## 爽点公式落地
压迫 → 误判主角 → 主角找漏洞 → 低成本反击 → 获得资源/名望/线索 → 新危机。

## 第一卷大纲
- 开端：主角发现世界规则有漏洞。
- 发展：连续解决三次危机，积累资源。
- 高潮：正面拆穿旧势力的一次局。
- 收束：赢得阶段胜利，同时暴露更大的敌人。

## 追更机制
- 每章结尾留下一个信息差。
- 每 3-5 章完成一个小闭环。
- 每 20-30 章完成一个阶段性大闭环。

## 风险与避坑
- 不要照搬原书剧情、人物和专有名词。
- 不要只写设定，必须用行动兑现爽点。
''';
  }

  String _localDistillFallback(WritingProject project, Chapter? chapter, String scope) {
    final chapterTitle = chapter?.title ?? '未指定章节';
    final recentChapters = project.chapters
        .take(12)
        .map((item) => '- ${item.title}：${_compact(item.content, 180)}')
        .join('\n');
    final materialTitles = project.notes
        .take(12)
        .map((item) => '- ${item.title}')
        .join('\n');

    return '''# 蒸馏记忆

> 本地模板模式：当前未连接联网 AI。以下内容可作为长期记忆骨架；填写 API Key 后会基于真实上下文自动蒸馏。

## 本次蒸馏范围

- 作品：《${project.title}》
- 类型：${project.genre}
- 范围：$scope
- 当前章节：$chapterTitle
- 章节数：${project.chapters.length}
- 总字数：${project.totalCharacters}

## 稳定设定

- 作品核心设定：${project.description.trim().isEmpty ? '待补充。' : project.description.trim()}
- 资料文件：
${materialTitles.isEmpty ? '- 暂无资料，请先补齐世界观、人物库、大纲、禁止改动设定。' : materialTitles}

## 人物状态

| 人物 | 当前身份 | 当前目标 | 关系/秘密 | 后续提醒 |
|---|---|---|---|---|
| 主角 | 待从人物库提取 | 待补充 | 待补充 | 保持动机连续 |
| 关键配角 | 待补充 | 待补充 | 待补充 | 不要功能化出场 |
| 反派/阻碍者 | 待补充 | 待补充 | 待补充 | 动机要自洽 |

## 世界规则

- 核心规则：待从世界观/正文中提取。
- 限制与代价：每个能力、系统、组织规则都需要明确代价。
- 红线：后续写作不能随意推翻已发生的硬设定。

## 主线进度

${recentChapters.isEmpty ? '- 暂无章节正文。' : recentChapters}

## 伏笔与悬念

| 伏笔/悬念 | 埋设位置 | 状态 | 建议回收方式 |
|---|---|---|---|
| 待提取 | $chapterTitle | 未确认 | 写完本章后归档 |

## 时间线

- 开篇阶段：明确主角被什么事件推入主线。
- 当前阶段：记录最新章节结束时的状态。
- 下一阶段：下一章必须承接上一章的后果。

## 文风约束

- 保持章节开头快速入戏。
- 每章至少有一个明确冲突、一个情绪点、一个结尾钩子。
- 不要长段解释设定，要用行动和对话呈现。

## 可丢弃内容

- 临时脑暴、重复设定、已经否定的方向、与正文冲突的旧方案。

## 下一步写作提醒

1. 先补齐《人物库》《世界观》《禁止改动设定》。
2. 每写完一章，归档剧情进展、人物变化、新伏笔。
3. 下一章必须承接本章结尾，避免断裂式换场。
''';
  }

  String _compact(String value, int maxChars) {
    final text = value.trim();
    if (text.length <= maxChars) return text;
    return '……前文省略……\n${text.substring(text.length - maxChars)}';
  }

  String _localChatFallback(String message, WritingProject? project) {
    final title = project == null ? '当前小说' : '《${project.title}》';
    return '''【本地 AI 工作台｜未连接 API】

你刚才的问题是：$message

建议把创作拆成 6 步：
1. 先在「小说资料」里补齐世界观、人物库、大纲。
2. 用「拆章规划」把大纲拆成 10～30 个章节。
3. 进入「章节内容」逐章写正文。
4. 写完一章后用「章节总结」和「设定提取」沉淀到资料库。
5. 用「章节质检」检查冲突、节奏、人物一致性。
6. 最后导出 TXT / Markdown / Word DOCX。

当前绑定：$title

填写 API Key 后，这里会变成真正的联网 AI 对话。''';
  }

  String _localDraft(
    AiSkill skill,
    WritingProject project,
    Chapter chapter,
    String extraInstruction,
    AiContextMode contextMode,
    String selectedText,
  ) {
    final instruction = extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim();
    final target = selectedText.trim().isNotEmpty && contextMode == AiContextMode.selection
        ? '选中文本'
        : '《${project.title}》的「${chapter.title}」';

    switch (skill.id) {
      case 'continue':
        return '''【本地续写模板｜未连接 AI】

他停在原地，像是终于听见了那个一直被忽略的声音。

周围的一切都没有变化，可他知道，真正改变的东西已经发生了。下一步不能再靠侥幸，也不能再把答案交给别人。

可就在他准备开口时，一个意料之外的人出现了。

目标：$target
补充要求：$instruction''';
      case 'outline':
      case 'chapter_splitter':
        return '''【本地章节规划模板｜未连接 AI】

1. 开场：用一个具体动作切入，让主角面对当前局面。
2. 目标：明确本章必须解决的问题。
3. 阻力：设置一个外部障碍和一个内心障碍。
4. 选择：让主角做出会付出代价的决定。
5. 反转：揭示一个新信息，改变读者对前文的理解。
6. 结尾钩子：留下一个问题，引到下一章。

作品：${project.title}
补充要求：$instruction''';
      case 'names':
        return '''【本地起名模板｜未连接 AI】

人物名：沈烬、陆无咎、林照夜、秦扶光、顾行舟、谢临渊
地点名：寒灯巷、归墟台、白骨渡、星坠城、万象司
组织名：巡夜司、无相门、青灯会、旧神档案馆
物品名：镇魂铃、借命符、赤霄令、无字碑

补充要求：$instruction''';
      case 'draft_to_files':
      case 'book_bible':
        return '''【本地资料入库模板｜未连接 AI】

【世界观】
- 规则：写清能力/制度的限制与代价。

【人物库】
- 人物：身份｜目标｜秘密｜关系｜变化。

【大纲】
- 主线目标：
- 阶段阻力：
- 反转点：

【章节摘要】
- ${chapter.title}：本章发生的关键事件、人物变化、伏笔、下一章承接点。

目标：$target
补充要求：$instruction''';
      case 'proofread':
      case 'chapter_review':
        return '''【本地质检模板｜未连接 AI】

优先检查：
1. 本章开头是否足够快进入矛盾。
2. 主角有没有明确目标。
3. 冲突是否有代价。
4. 对话是否区分人物。
5. 结尾是否有钩子。
6. 是否出现设定前后矛盾。

目标：$target
补充要求：$instruction''';
      default:
        return '''【本地技能模板｜未连接 AI】

技能：${skill.name}
目标：$target

请填写 API Key 后获得完整生成。当前可把这段作为占位草稿：
- 明确目标
- 增强冲突
- 保持人物动机一致
- 把结果写回正文或资料库

补充要求：$instruction''';
    }
  }
}

class AiException implements Exception {
  const AiException(this.message);
  final String message;

  @override
  String toString() => message;
}
