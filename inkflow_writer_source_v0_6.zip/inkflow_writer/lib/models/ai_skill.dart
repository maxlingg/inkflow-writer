import 'dart:convert';
import 'dart:io';

import 'package:archive/archive_io.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AiSkill {
  const AiSkill({
    required this.id,
    required this.name,
    required this.icon,
    required this.category,
    required this.shortDescription,
    required this.prompt,
    this.workflow = '',
    this.outputFormat = '',
    this.isCustom = false,
  });

  final String id;
  final String name;
  final String icon;
  final String category;
  final String shortDescription;
  final String prompt;
  final String workflow;
  final String outputFormat;
  final bool isCustom;

  String get systemInjection {
    final buffer = StringBuffer()
      ..writeln('【Skill：$name】')
      ..writeln('分类：$category')
      ..writeln('用途：$shortDescription')
      ..writeln('提示词：$prompt');
    if (workflow.trim().isNotEmpty) buffer.writeln('工作流：$workflow');
    if (outputFormat.trim().isNotEmpty) buffer.writeln('输出格式：$outputFormat');
    return buffer.toString().trim();
  }

  AiSkill copyWith({
    String? id,
    String? name,
    String? icon,
    String? category,
    String? shortDescription,
    String? prompt,
    String? workflow,
    String? outputFormat,
    bool? isCustom,
  }) {
    return AiSkill(
      id: id ?? this.id,
      name: name ?? this.name,
      icon: icon ?? this.icon,
      category: category ?? this.category,
      shortDescription: shortDescription ?? this.shortDescription,
      prompt: prompt ?? this.prompt,
      workflow: workflow ?? this.workflow,
      outputFormat: outputFormat ?? this.outputFormat,
      isCustom: isCustom ?? this.isCustom,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'icon': icon,
      'category': category,
      'shortDescription': shortDescription,
      'description': shortDescription,
      'prompt': prompt,
      'workflow': workflow,
      'outputFormat': outputFormat,
      'isCustom': isCustom,
    };
  }

  factory AiSkill.fromJson(Map<String, dynamic> json) {
    return AiSkill(
      id: (json['id'] as String?)?.trim().isNotEmpty == true
          ? (json['id'] as String).trim()
          : _newSkillId(),
      name: json['name'] as String? ?? json['title'] as String? ?? '未命名技能',
      icon: json['icon'] as String? ?? '✨',
      category: json['category'] as String? ?? '自定义',
      shortDescription: json['shortDescription'] as String? ??
          json['description'] as String? ??
          json['summary'] as String? ??
          '',
      prompt: json['prompt'] as String? ?? json['instruction'] as String? ?? '',
      workflow: json['workflow'] as String? ?? json['steps'] as String? ?? '',
      outputFormat: json['outputFormat'] as String? ?? json['output'] as String? ?? '',
      isCustom: json['isCustom'] as bool? ?? true,
    );
  }
}

const builtInAiSkills = <AiSkill>[
  AiSkill(
    id: 'novel_writer_core',
    name: 'novel-writer-core',
    icon: '✨',
    category: '内置核心',
    shortDescription: '长篇网文创作核心技能：剧情、人物、节奏、爽点、钩子。',
    prompt: '你是中文长篇小说创作助手，优先帮助作者保持设定一致、章节节奏清晰、人物动机合理、结尾有钩子。',
    workflow: '先识别当前上下文与作者目标，再判断这是生成、改写、规划、质检还是归档任务；输出前检查是否违背已有设定。',
    outputFormat: '正文类直接输出可粘贴正文；规划类使用标题与条目；质检类按优先级列出问题和建议。',
  ),
  AiSkill(
    id: 'continue',
    name: '续写本章',
    icon: '✍️',
    category: '正文生成',
    shortDescription: '延续语气和节奏，生成可直接接在后面的正文。',
    prompt: '请根据上下文自然续写，延续人物语气、叙事节奏和悬念。不要总结，不要解释，直接给出可放入正文的文本。',
    workflow: '读取当前章最后一段，判断人物目标、冲突和未解决问题，再续写一个新的推进段落。',
    outputFormat: '只输出正文，不要加标题、说明或列表。',
  ),
  AiSkill(
    id: 'scene_expand',
    name: '扩写场景',
    icon: '🌿',
    category: '正文生成',
    shortDescription: '补充环境、动作、心理和感官细节。',
    prompt: '请扩写当前场景，重点补充环境描写、人物动作、心理活动和感官细节，但不要推进过多新剧情。只输出扩写后的正文。',
    workflow: '找出场景中的地点、人物、情绪和冲突，补充画面感和节奏停顿。',
    outputFormat: '只输出扩写后的正文。',
  ),
  AiSkill(
    id: 'rewrite_style',
    name: '换风格改写',
    icon: '🎭',
    category: '正文生成',
    shortDescription: '按指定风格重写一段文本。',
    prompt: '请在不改变剧情事实和人物关系的前提下，按补充要求指定的风格改写文本。只输出改写后的正文。',
  ),
  AiSkill(
    id: 'dialogue',
    name: '优化对话',
    icon: '💬',
    category: '正文生成',
    shortDescription: '让对白更自然，并拉开角色差异。',
    prompt: '请优化当前片段中的对话，让每个角色说话更自然、更有辨识度，同时保留剧情目的。只输出优化后的正文。',
  ),
  AiSkill(
    id: 'polish',
    name: '润色文风',
    icon: '✨',
    category: '修订校对',
    shortDescription: '让语言更流畅、更有画面感。',
    prompt: '请润色当前文本，使表达更流畅、有画面感，保留原意、人物关系和剧情信息。只输出润色后的正文。',
  ),
  AiSkill(
    id: 'proofread',
    name: '错字病句',
    icon: '🔎',
    category: '修订校对',
    shortDescription: '检查错别字、病句、重复表达和逻辑不顺。',
    prompt: '请检查当前文本中的错别字、病句、重复表达、称呼不一致和逻辑不顺。用列表指出问题，并给出修改建议。',
  ),
  AiSkill(
    id: 'tighten',
    name: '压缩拖沓',
    icon: '✂️',
    category: '修订校对',
    shortDescription: '删掉废话，让节奏更快。',
    prompt: '请压缩当前文本中重复、拖沓和解释过度的内容，让节奏更紧凑。保留关键信息和情绪。只输出修改后的正文。',
  ),
  AiSkill(
    id: 'show_not_tell',
    name: '增强画面',
    icon: '🎬',
    category: '修订校对',
    shortDescription: '把平铺直叙改成动作、画面和细节。',
    prompt: '请把当前文本中直接说明情绪或设定的句子，改成动作、画面、细节和潜台词表达。只输出修改后的正文。',
  ),
  AiSkill(
    id: 'chapter_review',
    name: '章节质检',
    icon: '✅',
    category: '修订校对',
    shortDescription: '检查章节目标、冲突、节奏、人物一致性和钩子。',
    prompt: '请像网文编辑一样审稿当前章节，检查：开头吸引力、章节目标、冲突强度、人物动机、节奏拖沓、设定矛盾、结尾钩子，并给出优先修改清单。',
  ),
  AiSkill(
    id: 'outline',
    name: '章节大纲',
    icon: '🧭',
    category: '剧情规划',
    shortDescription: '生成当前章或下一章的结构。',
    prompt: '请根据作品信息和上下文，生成一个清晰的章节大纲，包含开场、目标、阻力、转折、高潮、结尾钩子。',
  ),
  AiSkill(
    id: 'conflict',
    name: '冲突升级',
    icon: '⚡',
    category: '剧情规划',
    shortDescription: '给剧情增加阻力、误会、代价或悬念。',
    prompt: '请为当前章节提出 6 个冲突升级方案。每个方案包含：触发点、人物反应、代价、后果、可埋伏笔。',
  ),
  AiSkill(
    id: 'plot_twist',
    name: '反转设计',
    icon: '🌀',
    category: '剧情规划',
    shortDescription: '设计合理但意外的剧情反转。',
    prompt: '请基于已有设定设计 5 个剧情反转。要求反转要能被前文细节支撑，避免突兀。每个反转说明铺垫、揭示方式和后续影响。',
  ),
  AiSkill(
    id: 'foreshadow',
    name: '伏笔清单',
    icon: '🧩',
    category: '剧情规划',
    shortDescription: '设计可埋、可回收的伏笔。',
    prompt: '请为当前剧情设计 8 个伏笔，分为近期回收、中期回收、长期回收。每个伏笔写出埋设位置、表现形式和回收方式。',
  ),
  AiSkill(
    id: 'summary',
    name: '章节总结',
    icon: '🧾',
    category: '整理归档',
    shortDescription: '总结剧情进展、人物变化和伏笔。',
    prompt: '请总结当前章节，分为：剧情进展、人物变化、已埋伏笔、待解决问题、下一章可承接点。',
  ),
  AiSkill(
    id: 'book_bible',
    name: '设定提取',
    icon: '📚',
    category: '整理归档',
    shortDescription: '从正文里提取人物、地点、组织、物品。',
    prompt: '请从上下文中提取可进入设定库的信息，按人物、地点、组织、物品、规则、伏笔分类。要求简洁、可复制到备忘录。',
  ),
  AiSkill(
    id: 'timeline',
    name: '时间线整理',
    icon: '🕰️',
    category: '整理归档',
    shortDescription: '把事件按先后顺序整理出来。',
    prompt: '请把上下文中的关键事件整理成时间线，标出每个事件的参与人物、地点、结果和可能的矛盾点。',
  ),
  AiSkill(
    id: 'draft_to_files',
    name: '资料入库',
    icon: '📥',
    category: '创作流程',
    shortDescription: '把正文/草稿拆分为世界观、人物库、大纲和章节摘要。',
    prompt: '请把当前文本提炼成可写入本地资料库的内容，按【世界观】【人物库】【大纲】【章节摘要】【伏笔】分类输出。',
  ),
  AiSkill(
    id: 'chapter_splitter',
    name: '拆章规划',
    icon: '🧱',
    category: '创作流程',
    shortDescription: '把长篇故事拆成章节标题、目标、冲突和钩子。',
    prompt: '请把当前大纲拆成章节计划。每章包含：章节名、核心事件、人物目标、主要冲突、结尾钩子、需要写入的资料文件。',
  ),
  AiSkill(
    id: 'names',
    name: '起名助手',
    icon: '🏷️',
    category: '灵感素材',
    shortDescription: '为人物、地点、组织生成名字。',
    prompt: '请根据作品类型和设定，生成 16 个可用名字。按人物名、地点名、组织名、物品名分类，并简短说明气质。',
  ),
  AiSkill(
    id: 'character_arc',
    name: '人物弧光',
    icon: '🧑‍🎤',
    category: '灵感素材',
    shortDescription: '设计人物欲望、弱点、选择和成长。',
    prompt: '请为相关人物设计人物弧光，包含：表层目标、深层欲望、缺陷、误信念、关键选择、成长节点、与主线冲突的关系。',
  ),
  AiSkill(
    id: 'world_rules',
    name: '世界规则',
    icon: '🌌',
    category: '灵感素材',
    shortDescription: '补全世界观规则和限制。',
    prompt: '请基于当前作品类型补全世界观规则，重点写清能力/制度/社会规则的限制、代价、漏洞和剧情用途。',
  ),
  AiSkill(
    id: 'skill_designer',
    name: 'skill-creator',
    icon: '🛠️',
    category: '技能管理',
    shortDescription: '创建新的技能 Skill、提示词和工作流。',
    prompt: '请把用户的写作需求改造成一个可复用的 AI 技能，输出：技能名、分类、触发场景、输入上下文、处理步骤、输出格式、注意事项、完整提示词。',
    workflow: '询问用户的目标、输入材料、处理步骤和输出格式，然后整理成 JSON skill。',
    outputFormat: '输出适合导入的 JSON：id、name、icon、category、shortDescription、prompt、workflow、outputFormat。',
  ),
  AiSkill(
    id: 'skill_interview',
    name: 'skill-interview',
    icon: '💡',
    category: '技能管理',
    shortDescription: '通过问答帮作者沉淀自己的专属写作流程。',
    prompt: '请用访谈方式追问用户的创作习惯、题材、读者预期、章节节奏、禁忌和输出格式，最后整理成可保存的技能。',
  ),
];

const skillCategories = <String>[
  '全部',
  '内置核心',
  '正文生成',
  '修订校对',
  '剧情规划',
  '整理归档',
  '创作流程',
  '灵感素材',
  '技能管理',
  '自定义',
];

class AiSkillStore {
  AiSkillStore._();

  static const _customSkillsKey = 'customAiSkillsV2';
  static const _legacyCustomSkillsKey = 'customAiSkillsV1';
  static const _activeSkillIdsKey = 'activeAiSkillIdsV1';

  static Future<List<AiSkill>> loadCustomSkills() async {
    final prefs = await SharedPreferences.getInstance();
    var raw = prefs.getString(_customSkillsKey);
    raw ??= prefs.getString(_legacyCustomSkillsKey);
    if (raw == null || raw.trim().isEmpty) return [];

    try {
      final decoded = jsonDecode(raw) as List;
      return decoded
          .whereType<Map>()
          .map((item) => AiSkill.fromJson(Map<String, dynamic>.from(item)).copyWith(isCustom: true))
          .toList();
    } on FormatException {
      await prefs.remove(_customSkillsKey);
      return [];
    }
  }

  static Future<List<AiSkill>> loadAllSkills() async {
    final custom = await loadCustomSkills();
    return [...builtInAiSkills, ...custom];
  }

  static Future<Set<String>> loadActiveSkillIds() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_activeSkillIdsKey);
    if (raw == null || raw.trim().isEmpty) {
      return builtInAiSkills.map((skill) => skill.id).toSet();
    }
    try {
      final decoded = jsonDecode(raw) as List;
      final ids = decoded.whereType<String>().toSet();
      if (ids.isEmpty) return <String>{};
      return ids;
    } on FormatException {
      await prefs.remove(_activeSkillIdsKey);
      return builtInAiSkills.map((skill) => skill.id).toSet();
    }
  }

  static Future<List<AiSkill>> loadActiveSkills() async {
    final skills = await loadAllSkills();
    final activeIds = await loadActiveSkillIds();
    return skills.where((skill) => activeIds.contains(skill.id)).toList();
  }

  static Future<bool> isSkillActive(String id) async {
    final activeIds = await loadActiveSkillIds();
    return activeIds.contains(id);
  }

  static Future<void> setSkillActive(String id, bool active) async {
    final prefs = await SharedPreferences.getInstance();
    final activeIds = await loadActiveSkillIds();
    if (active) {
      activeIds.add(id);
    } else {
      activeIds.remove(id);
    }
    await prefs.setString(_activeSkillIdsKey, jsonEncode(activeIds.toList()));
  }

  static Future<void> activateAllBuiltIns() async {
    final prefs = await SharedPreferences.getInstance();
    final activeIds = await loadActiveSkillIds();
    activeIds.addAll(builtInAiSkills.map((skill) => skill.id));
    await prefs.setString(_activeSkillIdsKey, jsonEncode(activeIds.toList()));
  }

  static Future<void> upsertCustomSkill(AiSkill skill, {bool activate = true}) async {
    final prefs = await SharedPreferences.getInstance();
    final skills = await loadCustomSkills();
    final nextSkill = skill.copyWith(
      id: skill.id.trim().isEmpty ? _newSkillId() : skill.id.trim(),
      name: skill.name.trim().isEmpty ? '未命名技能' : skill.name.trim(),
      category: skill.category.trim().isEmpty ? '自定义' : skill.category.trim(),
      isCustom: true,
    );
    final index = skills.indexWhere((item) => item.id == nextSkill.id);
    if (index == -1) {
      skills.add(nextSkill);
    } else {
      skills[index] = nextSkill;
    }
    await prefs.setString(
      _customSkillsKey,
      jsonEncode(skills.map((item) => item.toJson()).toList()),
    );
    if (activate) await setSkillActive(nextSkill.id, true);
  }

  static Future<void> deleteCustomSkill(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final skills = await loadCustomSkills();
    skills.removeWhere((item) => item.id == id);
    await prefs.setString(
      _customSkillsKey,
      jsonEncode(skills.map((item) => item.toJson()).toList()),
    );
    final activeIds = await loadActiveSkillIds();
    activeIds.remove(id);
    await prefs.setString(_activeSkillIdsKey, jsonEncode(activeIds.toList()));
  }

  static Future<int> importSkillJsonText(String text) async {
    final clean = _stripCodeFence(text.trim());
    final decoded = jsonDecode(clean);
    final imported = <AiSkill>[];
    if (decoded is List) {
      for (final item in decoded) {
        if (item is Map) imported.add(AiSkill.fromJson(Map<String, dynamic>.from(item)));
      }
    } else if (decoded is Map) {
      final map = Map<String, dynamic>.from(decoded);
      if (map['skills'] is List) {
        for (final item in map['skills'] as List) {
          if (item is Map) imported.add(AiSkill.fromJson(Map<String, dynamic>.from(item)));
        }
      } else {
        imported.add(AiSkill.fromJson(map));
      }
    }
    for (final skill in imported) {
      if (skill.name.trim().isEmpty || skill.prompt.trim().isEmpty) continue;
      await upsertCustomSkill(skill.copyWith(isCustom: true), activate: true);
    }
    return imported.length;
  }

  static Future<int> importFromFilePath(String path) async {
    final file = File(path);
    if (!await file.exists()) throw FileSystemException('文件不存在', path);
    final lower = path.toLowerCase();
    if (lower.endsWith('.zip')) return _importFromZip(path);
    if (lower.endsWith('.json') || lower.endsWith('.skill')) {
      return importSkillJsonText(await file.readAsString());
    }
    if (lower.endsWith('.md') || lower.endsWith('.txt')) {
      final raw = await file.readAsString();
      return importSkillJsonText(_extractJsonFromMarkdown(raw));
    }
    throw const FormatException('只支持 .json / .skill / .zip / .md / .txt 技能文件');
  }

  static Future<int> importFromDirectory(String path) async {
    final dir = Directory(path);
    if (!await dir.exists()) throw FileSystemException('目录不存在', path);
    var count = 0;
    await for (final entity in dir.list(recursive: true, followLinks: false)) {
      if (entity is! File) continue;
      final lower = entity.path.toLowerCase();
      if (lower.endsWith('.json') || lower.endsWith('.skill') || lower.endsWith('.md') || lower.endsWith('.txt')) {
        try {
          count += await importFromFilePath(entity.path);
        } catch (_) {}
      }
    }
    return count;
  }

  static Future<int> _importFromZip(String path) async {
    final bytes = await File(path).readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    var count = 0;
    for (final file in archive.files) {
      if (!file.isFile) continue;
      final name = file.name.toLowerCase();
      if (!(name.endsWith('.json') || name.endsWith('.skill') || name.endsWith('.md') || name.endsWith('.txt'))) {
        continue;
      }
      try {
        final data = file.content as List<int>;
        final text = utf8.decode(data);
        if (name.endsWith('.md') || name.endsWith('.txt')) {
          count += await importSkillJsonText(_extractJsonFromMarkdown(text));
        } else {
          count += await importSkillJsonText(text);
        }
      } catch (_) {}
    }
    return count;
  }

  static String activeSkillsSystemBlock(List<AiSkill> skills) {
    if (skills.isEmpty) return '当前没有激活 Skill。';
    return skills.map((skill) => skill.systemInjection).join('\n\n---\n\n');
  }
}

Future<AiSkill> skillById(String id) async {
  final all = await AiSkillStore.loadAllSkills();
  return all.firstWhere(
    (skill) => skill.id == id,
    orElse: () => builtInAiSkills.first,
  );
}

AiSkill builtInSkillById(String id) {
  return builtInAiSkills.firstWhere(
    (skill) => skill.id == id,
    orElse: () => builtInAiSkills.first,
  );
}

String _newSkillId() {
  return 'custom-skill-${DateTime.now().microsecondsSinceEpoch}';
}

String _stripCodeFence(String text) {
  if (text.startsWith('```')) {
    final lines = text.split('\n');
    if (lines.length >= 3) {
      final withoutFirst = lines.skip(1).join('\n');
      final lastFence = withoutFirst.lastIndexOf('```');
      if (lastFence >= 0) return withoutFirst.substring(0, lastFence).trim();
    }
  }
  return text;
}

String _extractJsonFromMarkdown(String text) {
  final fenced = RegExp(r'```(?:json)?\s*([\s\S]*?)```', caseSensitive: false).firstMatch(text);
  if (fenced != null) return fenced.group(1)!.trim();
  final startObject = text.indexOf('{');
  final startArray = text.indexOf('[');
  int start;
  if (startObject == -1) {
    start = startArray;
  } else if (startArray == -1) {
    start = startObject;
  } else {
    start = startObject < startArray ? startObject : startArray;
  }
  if (start == -1) return text;
  final endObject = text.lastIndexOf('}');
  final endArray = text.lastIndexOf(']');
  final end = endObject > endArray ? endObject : endArray;
  if (end <= start) return text;
  return text.substring(start, end + 1).trim();
}
