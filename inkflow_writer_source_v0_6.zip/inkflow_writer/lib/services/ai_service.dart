import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/ai_skill.dart';
import '../models/writing_project.dart';
import 'app_settings.dart';

enum AiContextMode { selection, chapter, project }

extension AiContextModeLabel on AiContextMode {
  String get label {
    return switch (this) {
      AiContextMode.selection => '选中文本优先',
      AiContextMode.chapter => '当前章节',
      AiContextMode.project => '作品设定 + 全书摘要',
    };
  }
}

class AiService {
  AiService._();

  static final AiService instance = AiService._();

  Future<String> runSkill({
    required AppSettings settings,
    required AiSkill skill,
    required WritingProject project,
    required Chapter chapter,
    required String extraInstruction,
    required AiContextMode contextMode,
    required String selectedText,
  }) async {
    final contextBlock = _contextBlock(
      project: project,
      chapter: chapter,
      contextMode: contextMode,
      selectedText: selectedText,
    );

    final userPrompt = '''
作品名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}

上下文模式：${contextMode.label}
$contextBlock

使用技能：${skill.name}
技能分类：${skill.category}
技能要求：${skill.prompt}
补充要求：${extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim()}

输出要求：
1. 严格尊重已有设定，不要和上下文冲突。
2. 能直接用于写作的技能，请直接输出正文；规划类技能请用清晰条目。
3. 不要说“当然可以”、不要解释你在做什么。
''';

    return complete(
      settings: settings,
      systemPrompt: '小说技能任务：根据用户选择的 Skill 和上下文完成写作、修订、规划或资料整理。',
      userPrompt: userPrompt,
      localFallback: _localDraft(skill, project, chapter, extraInstruction, contextMode, selectedText),
      maxTokens: 2600,
    );
  }

  Future<String> sendChat({
    required AppSettings settings,
    required String message,
    required WritingProject? project,
    required List<String> history,
  }) async {
    final projectContext = project == null ? '当前没有绑定小说。' : _projectBrief(project);
    final historyText = history.take(12).join('\n');
    final prompt = '''
用户消息：$message

当前绑定小说：
$projectContext

最近对话：
${historyText.trim().isEmpty ? '无' : historyText}

请用中文回答。可以给出明确的下一步，也可以生成大纲、正文片段、设定表或修改建议。不要声称已经直接修改文件，除非用户明确使用按钮保存/插入。
''';

    return complete(
      settings: settings,
      systemPrompt: '小说工作台对话：回答作者问题，帮助推进作品创作流程。',
      userPrompt: prompt,
      localFallback: _localChatFallback(message, project),
      maxTokens: 2600,
    );
  }

  Future<String> complete({
    required AppSettings settings,
    required String systemPrompt,
    required String userPrompt,
    required String localFallback,
    int maxTokens = 2200,
  }) async {
    final apiKey = settings.aiApiKey.trim();
    if (apiKey.isEmpty) return localFallback;

    final effectiveSystemPrompt = await _effectiveSystemPrompt(settings, systemPrompt);
    final baseUrl = settings.aiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.parse('$baseUrl/chat/completions');
    final response = await http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $apiKey',
          },
          body: jsonEncode({
            'model': settings.aiModel.trim().isEmpty ? 'gpt-4o-mini' : settings.aiModel.trim(),
            'messages': [
              {'role': 'system', 'content': effectiveSystemPrompt},
              {'role': 'user', 'content': userPrompt},
            ],
            'temperature': 0.86,
            'max_tokens': maxTokens,
          }),
        )
        .timeout(const Duration(seconds: 60));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw AiException('AI 请求失败：HTTP ${response.statusCode}\n${response.body}');
    }

    final decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final choices = decoded['choices'];
    if (choices is List && choices.isNotEmpty) {
      final first = choices.first;
      if (first is Map) {
        final message = first['message'];
        if (message is Map && message['content'] is String) {
          final text = (message['content'] as String).trim();
          if (text.isNotEmpty) return text;
        }
        if (first['text'] is String) {
          final text = (first['text'] as String).trim();
          if (text.isNotEmpty) return text;
        }
      }
    }
    throw const AiException('AI 返回为空，请稍后重试。');
  }

  Future<String> _effectiveSystemPrompt(AppSettings settings, String taskPrompt) async {
    final activeSkills = await AiSkillStore.loadActiveSkills();
    final skillBlock = AiSkillStore.activeSkillsSystemBlock(activeSkills.take(24).toList());
    return '''${settings.systemPrompt}

【当前任务说明】
$taskPrompt

【已激活 Skills】
$skillBlock

执行规则：
- 当用户选择某个 Skill 时，优先遵循该 Skill 的提示词、工作流和输出格式。
- 如果多个 Skill 相关，按任务目标组合使用，但不要输出内部分析过程。
- 若上下文不足，给出可执行的补充建议，不要编造已经写入本地文件的事实。''';
  }

  String _contextBlock({
    required WritingProject project,
    required Chapter chapter,
    required AiContextMode contextMode,
    required String selectedText,
  }) {
    final notes = project.notes
        .take(30)
        .map((note) => '[${note.tag}] ${note.title}: ${_compact(note.body, 520)}')
        .join('\n');

    if (contextMode == AiContextMode.selection && selectedText.trim().isNotEmpty) {
      return '''
设定资料：
${notes.isEmpty ? '无' : notes}

当前章节：${chapter.title}
选中文本：
${_compact(selectedText, 5200)}
''';
    }

    if (contextMode == AiContextMode.project) {
      final chapters = project.chapters
          .map((item) => '- ${item.title}：${_compact(item.content, 620)}')
          .join('\n');
      return '''
设定资料：
${notes.isEmpty ? '无' : notes}

全书章节摘要/节选：
${chapters.isEmpty ? '无' : chapters}

当前章节：${chapter.title}
当前章节全文节选：
${_compact(chapter.content, 4200)}
''';
    }

    return '''
设定资料：
${notes.isEmpty ? '无' : notes}

当前章节：${chapter.title}
当前正文：
${_compact(chapter.content, 6200)}
''';
  }

  String _projectBrief(WritingProject project) {
    final notes = project.notes.take(12).map((note) => '- ${note.title}: ${_compact(note.body, 240)}').join('\n');
    final chapters = project.chapters.take(30).map((chapter) => '- ${chapter.title}: ${_compact(chapter.content, 240)}').join('\n');
    return '''
《${project.title}》
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}

资料：
${notes.isEmpty ? '无' : notes}

章节：
${chapters.isEmpty ? '无' : chapters}
''';
  }

  String _compact(String value, int maxChars) {
    final text = value.trim();
    if (text.length <= maxChars) return text;
    return '……前文省略……\n${text.substring(text.length - maxChars)}';
  }

  String _localChatFallback(String message, WritingProject? project) {
    final title = project == null ? '当前小说' : '《${project.title}》';
    return '''【本地 AI 工作台｜未连接 API】

你刚才的问题是：$message

建议把创作拆成 6 步：
1. 先在「小说资料」里补齐世界观、人物库、大纲。
2. 用「拆章规划」把大纲拆成 10～30 个章节。
3. 进入「章节内容」逐章写正文。
4. 写完一章后用「章节总结」和「设定提取」沉淀到资料库。
5. 用「章节质检」检查冲突、节奏、人物一致性。
6. 最后导出 TXT / Markdown / Word DOCX。

当前绑定：$title

填写 API Key 后，这里会变成真正的联网 AI 对话。''';
  }

  String _localDraft(
    AiSkill skill,
    WritingProject project,
    Chapter chapter,
    String extraInstruction,
    AiContextMode contextMode,
    String selectedText,
  ) {
    final instruction = extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim();
    final target = selectedText.trim().isNotEmpty && contextMode == AiContextMode.selection
        ? '选中文本'
        : '《${project.title}》的「${chapter.title}」';

    switch (skill.id) {
      case 'continue':
        return '''【本地续写模板｜未连接 AI】

他停在原地，像是终于听见了那个一直被忽略的声音。

周围的一切都没有变化，可他知道，真正改变的东西已经发生了。下一步不能再靠侥幸，也不能再把答案交给别人。

可就在他准备开口时，一个意料之外的人出现了。

目标：$target
补充要求：$instruction''';
      case 'outline':
      case 'chapter_splitter':
        return '''【本地章节规划模板｜未连接 AI】

1. 开场：用一个具体动作切入，让主角面对当前局面。
2. 目标：明确本章必须解决的问题。
3. 阻力：设置一个外部障碍和一个内心障碍。
4. 选择：让主角做出会付出代价的决定。
5. 反转：揭示一个新信息，改变读者对前文的理解。
6. 结尾钩子：留下一个问题，引到下一章。

作品：${project.title}
补充要求：$instruction''';
      case 'names':
        return '''【本地起名模板｜未连接 AI】

人物名：沈烬、陆无咎、林照夜、秦扶光、顾行舟、谢临渊
地点名：寒灯巷、归墟台、白骨渡、星坠城、万象司
组织名：巡夜司、无相门、青灯会、旧神档案馆
物品名：镇魂铃、借命符、赤霄令、无字碑

补充要求：$instruction''';
      case 'draft_to_files':
      case 'book_bible':
        return '''【本地资料入库模板｜未连接 AI】

【世界观】
- 规则：写清能力/制度的限制与代价。

【人物库】
- 人物：身份｜目标｜秘密｜关系｜变化。

【大纲】
- 主线目标：
- 阶段阻力：
- 反转点：

【章节摘要】
- ${chapter.title}：本章发生的关键事件、人物变化、伏笔、下一章承接点。

目标：$target
补充要求：$instruction''';
      case 'proofread':
      case 'chapter_review':
        return '''【本地质检模板｜未连接 AI】

优先检查：
1. 本章开头是否足够快进入矛盾。
2. 主角有没有明确目标。
3. 冲突是否有代价。
4. 对话是否区分人物。
5. 结尾是否有钩子。
6. 是否出现设定前后矛盾。

目标：$target
补充要求：$instruction''';
      default:
        return '''【本地技能模板｜未连接 AI】

技能：${skill.name}
目标：$target

请填写 API Key 后获得完整生成。当前可把这段作为占位草稿：
- 明确目标
- 增强冲突
- 保持人物动机一致
- 把结果写回正文或资料库

补充要求：$instruction''';
    }
  }
}

class AiException implements Exception {
  const AiException(this.message);
  final String message;

  @override
  String toString() => message;
}
