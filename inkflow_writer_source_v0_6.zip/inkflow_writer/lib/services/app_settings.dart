import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  static const _themeModeKey = 'themeMode';
  static const _editorFontSizeKey = 'editorFontSize';
  static const _aiApiKeyKey = 'aiApiKey';
  static const _aiBaseUrlKey = 'aiBaseUrl';
  static const _aiModelKey = 'aiModel';
  static const _systemPromptKey = 'systemPromptV1';

  static const defaultSystemPrompt = '''你是墨舟写作的中文长篇小说 AI 助手，擅长网文、长篇连载、章节规划、人物弧光、世界观设定和正文修订。

工作原则：
1. 先尊重作者已有设定，再提出扩展。
2. 正文生成要能直接粘贴进章节，不要解释过程。
3. 规划类输出要结构清晰，包含目标、冲突、转折、钩子。
4. 修订类要尽量保留作者原意和人物关系。
5. 发现设定矛盾时先提示矛盾点，再给解决方案。
6. 不要替作者强行决定风格；需要时给 2～3 个可选方向。''';

  ThemeMode _themeMode = ThemeMode.system;
  double _editorFontSize = 18;
  String _aiApiKey = '';
  String _aiBaseUrl = 'https://api.openai.com/v1';
  String _aiModel = 'gpt-4o-mini';
  String _systemPrompt = defaultSystemPrompt;

  ThemeMode get themeMode => _themeMode;
  double get editorFontSize => _editorFontSize;
  String get aiApiKey => _aiApiKey;
  String get aiBaseUrl => _aiBaseUrl;
  String get aiModel => _aiModel;
  String get systemPrompt => _systemPrompt;
  bool get hasAiApiKey => _aiApiKey.trim().isNotEmpty;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _themeMode = _themeModeFromString(prefs.getString(_themeModeKey));
    _editorFontSize = (prefs.getDouble(_editorFontSizeKey) ?? 18).clamp(14, 28).toDouble();
    _aiApiKey = prefs.getString(_aiApiKeyKey) ?? '';
    _aiBaseUrl = prefs.getString(_aiBaseUrlKey) ?? _aiBaseUrl;
    _aiModel = prefs.getString(_aiModelKey) ?? _aiModel;
    _systemPrompt = prefs.getString(_systemPromptKey) ?? defaultSystemPrompt;
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    if (_themeMode == mode) return;
    _themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeModeKey, mode.name);
  }

  Future<void> setEditorFontSize(double size) async {
    final nextSize = size.clamp(14, 28).toDouble();
    if (_editorFontSize == nextSize) return;
    _editorFontSize = nextSize;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_editorFontSizeKey, nextSize);
  }

  Future<void> setAiApiKey(String value) async {
    _aiApiKey = value.trim();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aiApiKeyKey, _aiApiKey);
  }

  Future<void> setAiBaseUrl(String value) async {
    final next = value.trim().isEmpty ? 'https://api.openai.com/v1' : value.trim();
    _aiBaseUrl = next.replaceAll(RegExp(r'/+$'), '');
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aiBaseUrlKey, _aiBaseUrl);
  }

  Future<void> setAiModel(String value) async {
    _aiModel = value.trim().isEmpty ? 'gpt-4o-mini' : value.trim();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aiModelKey, _aiModel);
  }

  Future<void> setSystemPrompt(String value) async {
    _systemPrompt = value.trim().isEmpty ? defaultSystemPrompt : value.trim();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_systemPromptKey, _systemPrompt);
  }

  Future<void> resetSystemPrompt() => setSystemPrompt(defaultSystemPrompt);

  ThemeMode _themeModeFromString(String? value) {
    return switch (value) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
  }
}
