import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/writing_project.dart';
import 'docx_export_service.dart';

enum ExportFormat { txt, markdown, docx }

extension ExportFormatLabel on ExportFormat {
  String get label => switch (this) {
        ExportFormat.txt => 'TXT',
        ExportFormat.markdown => 'Markdown',
        ExportFormat.docx => 'Word DOCX',
      };

  String get extension => switch (this) {
        ExportFormat.txt => 'txt',
        ExportFormat.markdown => 'md',
        ExportFormat.docx => 'docx',
      };
}

class StorageService {
  StorageService._();

  static final StorageService instance = StorageService._();

  Future<List<WritingProject>> loadProjects() async {
    final file = await _projectFile();
    var projects = <WritingProject>[];

    if (await file.exists()) {
      final raw = await file.readAsString();
      if (raw.trim().isNotEmpty) {
        try {
          final decoded = jsonDecode(raw) as List;
          projects = decoded
              .whereType<Map>()
              .map((item) => WritingProject.fromJson(Map<String, dynamic>.from(item)))
              .toList();
        } on FormatException {
          final backup = File('${file.path}.broken-${DateTime.now().millisecondsSinceEpoch}');
          await file.rename(backup.path);
          projects = [];
        }
      }
    }

    final folderProjects = await _loadProjectsFromFolders();
    for (final project in folderProjects) {
      if (!projects.any((item) => item.id == project.id)) projects.add(project);
    }

    final hydrated = <WritingProject>[];
    for (final project in projects) {
      final withDefaults = _withDefaultMaterialFiles(project);
      hydrated.add(await _hydrateProjectFromDisk(withDefaults));
    }

    hydrated.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    await saveProjects(hydrated);
    for (final project in hydrated) {
      await _syncProjectToDisk(project);
    }
    return hydrated;
  }

  Future<void> saveProjects(List<WritingProject> projects) async {
    final file = await _projectFile();
    final data = projects.map((project) => project.toJson()).toList();
    const encoder = JsonEncoder.withIndent('  ');
    await file.writeAsString(encoder.convert(data), flush: true);
  }

  Future<void> upsertProject(WritingProject project) async {
    final projects = await loadProjects();
    final index = projects.indexWhere((item) => item.id == project.id);
    final next = _withDefaultMaterialFiles(project.copyWith(updatedAt: DateTime.now()));

    if (index == -1) {
      projects.add(next);
    } else {
      projects[index] = next;
    }
    await saveProjects(projects);
    await _syncProjectToDisk(next);
  }

  Future<void> deleteProject(String id) async {
    final projects = await loadProjects();
    final target = projects.where((project) => project.id == id).toList();
    projects.removeWhere((project) => project.id == id);
    await saveProjects(projects);

    for (final project in target) {
      final dir = await projectDirectory(project);
      if (await dir.exists()) await dir.delete(recursive: true);
    }
  }

  Future<String> exportProject(
    WritingProject project, {
    required ExportFormat format,
  }) async {
    final dir = await _exportDir();
    final filename = '${_safeName(project.title)}-${_dateStamp()}.${format.extension}';
    final file = File('${dir.path}${Platform.pathSeparator}$filename');

    if (format == ExportFormat.docx) {
      return DocxExportService.exportProject(project, file.path);
    }

    final content = switch (format) {
      ExportFormat.markdown => _toMarkdown(project),
      ExportFormat.txt => _toPlainText(project),
      ExportFormat.docx => '',
    };

    await file.writeAsString(content, flush: true);
    return file.path;
  }

  Future<WritingProject> addTextAsChapter({
    required WritingProject project,
    required String title,
    required String content,
  }) async {
    final now = DateTime.now();
    final chapter = Chapter(
      id: newEntityId('chapter'),
      title: _stripExtension(title.trim().isEmpty ? '新章节' : title.trim()),
      content: content,
      createdAt: now,
      updatedAt: now,
    );
    final next = project.copyWith(
      chapters: [...project.chapters, chapter],
      updatedAt: now,
    );
    await upsertProject(next);
    return next;
  }

  Future<WritingProject> importFileAsChapter(WritingProject project, String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) throw FileSystemException('文件不存在', filePath);

    final name = file.uri.pathSegments.isEmpty ? '导入章节' : file.uri.pathSegments.last;
    final lower = name.toLowerCase();
    String content;
    if (lower.endsWith('.docx')) {
      content = await DocxExportService.readDocxText(filePath);
    } else {
      content = await file.readAsString();
    }
    return addTextAsChapter(project: project, title: _stripExtension(name), content: content);
  }

  Future<WritingProject> appendMaterial({
    required WritingProject project,
    required String title,
    required String content,
    String tag = 'AI',
  }) async {
    final now = DateTime.now();
    final cleanTitle = _stripExtension(title.trim().isEmpty ? 'AI草稿' : title.trim());
    final index = project.notes.indexWhere((item) => _safeName(item.title) == _safeName(cleanTitle));
    final notes = [...project.notes];
    if (index == -1) {
      notes.add(
        ProjectNote(
          id: newEntityId('note'),
          title: cleanTitle,
          body: content,
          tag: tag,
          createdAt: now,
          updatedAt: now,
        ),
      );
    } else {
      final old = notes[index];
      notes[index] = old.copyWith(
        body: old.body.trim().isEmpty ? content : '${old.body.trim()}\n\n$content',
        tag: tag,
        updatedAt: now,
      );
    }
    final next = project.copyWith(notes: notes, updatedAt: now);
    await upsertProject(next);
    return next;
  }

  Future<Directory> projectDirectory(WritingProject project) async {
    final novels = await novelsDirectory();
    final dir = Directory('${novels.path}${Platform.pathSeparator}${_safeName(project.title)}');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<String> projectDirectoryPath(WritingProject project) async {
    return (await projectDirectory(project)).path;
  }

  Future<Directory> novelsDirectory() async {
    final base = await _baseDir();
    final dir = Directory('${base.path}${Platform.pathSeparator}novels');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<String> novelsDirectoryPath() async {
    return (await novelsDirectory()).path;
  }

  Future<Directory> baseDirectory() => _baseDir();

  Future<Directory> _baseDir() async {
    final internalRoot = await getApplicationDocumentsDirectory();
    Directory? root;

    try {
      root = await getExternalStorageDirectory();
    } catch (_) {
      root = null;
    }

    final dir = Directory('${(root ?? internalRoot).path}${Platform.pathSeparator}inkflow_writer');
    if (!await dir.exists()) await dir.create(recursive: true);

    if (root != null) {
      final oldDir = Directory('${internalRoot.path}${Platform.pathSeparator}inkflow_writer');
      await _migrateOldInternalData(oldDir, dir);
    }

    return dir;
  }

  Future<void> _migrateOldInternalData(Directory oldDir, Directory newDir) async {
    if (!await oldDir.exists()) return;
    final marker = File('${newDir.path}${Platform.pathSeparator}.migrated');
    if (await marker.exists()) return;

    await for (final entity in oldDir.list(recursive: false, followLinks: false)) {
      final name = entity.path.split(Platform.pathSeparator).last;
      final targetPath = '${newDir.path}${Platform.pathSeparator}$name';
      if (entity is File && !await File(targetPath).exists()) {
        await entity.copy(targetPath);
      }
      if (entity is Directory && !await Directory(targetPath).exists()) {
        await _copyDirectory(entity, Directory(targetPath));
      }
    }
    await marker.writeAsString(DateTime.now().toIso8601String());
  }

  Future<void> _copyDirectory(Directory source, Directory target) async {
    if (!await target.exists()) await target.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final name = entity.path.split(Platform.pathSeparator).last;
      final targetPath = '${target.path}${Platform.pathSeparator}$name';
      if (entity is File) await entity.copy(targetPath);
      if (entity is Directory) await _copyDirectory(entity, Directory(targetPath));
    }
  }

  Future<File> _projectFile() async {
    final dir = await _baseDir();
    return File('${dir.path}${Platform.pathSeparator}projects.json');
  }

  Future<Directory> _exportDir() async {
    final dir = Directory('${(await _baseDir()).path}${Platform.pathSeparator}exports');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<List<WritingProject>> _loadProjectsFromFolders() async {
    final novels = await novelsDirectory();
    final results = <WritingProject>[];
    await for (final entity in novels.list(recursive: false, followLinks: false)) {
      if (entity is! Directory) continue;
      final jsonFile = File('${entity.path}${Platform.pathSeparator}project.json');
      if (await jsonFile.exists()) {
        try {
          final decoded = jsonDecode(await jsonFile.readAsString()) as Map<String, dynamic>;
          results.add(WritingProject.fromJson(decoded));
          continue;
        } catch (_) {}
      }

      final now = DateTime.now();
      final title = entity.path.split(Platform.pathSeparator).last;
      results.add(
        WritingProject(
          id: newEntityId('project'),
          title: title,
          description: '',
          genre: '长篇小说',
          createdAt: now,
          updatedAt: now,
          chapters: const [],
          notes: const [],
        ),
      );
    }
    return results;
  }

  WritingProject _withDefaultMaterialFiles(WritingProject project) {
    final now = DateTime.now();
    final notes = [...project.notes];
    void ensureNote(String title, String body) {
      if (notes.any((item) => _safeName(item.title) == _safeName(title))) return;
      notes.add(
        ProjectNote(
          id: newEntityId('note'),
          title: title,
          body: body,
          tag: '资料',
          createdAt: now,
          updatedAt: now,
        ),
      );
    }

    ensureNote('世界观', '# 世界观\n\n## 基础规则\n\n## 地点与势力\n\n## 限制与代价\n');
    ensureNote('人物库', '# 人物库\n\n## 主角\n\n## 配角\n\n## 反派\n');
    ensureNote('大纲', '# 大纲\n\n## 主线\n\n## 阶段目标\n\n## 结局方向\n');
    ensureNote('章节摘要', '# 章节摘要\n\n用于保存每章发生了什么、人物变化、伏笔和下一章承接点。\n');
    ensureNote('AI草稿', '# AI草稿\n\nAI 生成但还没放入正文的内容可以先存到这里。\n');

    final chapters = [...project.chapters];
    if (chapters.isEmpty) {
      chapters.add(
        Chapter(
          id: newEntityId('chapter'),
          title: '第1章',
          content: '',
          createdAt: now,
          updatedAt: now,
        ),
      );
    }

    return project.copyWith(notes: notes, chapters: chapters);
  }

  Future<WritingProject> _hydrateProjectFromDisk(WritingProject project) async {
    final projectDir = await projectDirectory(project);
    final materialsDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料');
    final chaptersDir = Directory('${projectDir.path}${Platform.pathSeparator}章节内容');
    if (!await materialsDir.exists()) await materialsDir.create(recursive: true);
    if (!await chaptersDir.exists()) await chaptersDir.create(recursive: true);

    final notes = <ProjectNote>[];
    final knownNoteTitles = <String>{};
    for (final note in project.notes) {
      final file = File('${materialsDir.path}${Platform.pathSeparator}${_fileNameForTitle(note.title)}');
      var next = note;
      if (await file.exists()) next = note.copyWith(body: await file.readAsString());
      knownNoteTitles.add(_safeName(next.title));
      notes.add(next);
    }

    await for (final entity in materialsDir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final title = _titleFromFile(entity.path);
      if (knownNoteTitles.contains(_safeName(title))) continue;
      final now = DateTime.now();
      notes.add(ProjectNote(
        id: newEntityId('note'),
        title: title,
        body: await entity.readAsString(),
        tag: '资料',
        createdAt: now,
        updatedAt: now,
      ));
    }

    final chapters = <Chapter>[];
    final knownChapterTitles = <String>{};
    for (final chapter in project.chapters) {
      final file = File('${chaptersDir.path}${Platform.pathSeparator}${_fileNameForTitle(chapter.title)}');
      var next = chapter;
      if (await file.exists()) next = chapter.copyWith(content: await file.readAsString());
      knownChapterTitles.add(_safeName(next.title));
      chapters.add(next);
    }

    final extraChapterFiles = <File>[];
    await for (final entity in chaptersDir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final title = _titleFromFile(entity.path);
      if (!knownChapterTitles.contains(_safeName(title))) extraChapterFiles.add(entity);
    }
    extraChapterFiles.sort((a, b) => _chapterSortKey(_titleFromFile(a.path)).compareTo(_chapterSortKey(_titleFromFile(b.path))));
    for (final file in extraChapterFiles) {
      final now = DateTime.now();
      chapters.add(Chapter(
        id: newEntityId('chapter'),
        title: _titleFromFile(file.path),
        content: await file.readAsString(),
        createdAt: now,
        updatedAt: now,
      ));
    }

    return project.copyWith(notes: notes, chapters: chapters);
  }

  Future<void> _syncProjectToDisk(WritingProject project) async {
    final projectDir = await projectDirectory(project);
    final materialsDir = Directory('${projectDir.path}${Platform.pathSeparator}小说资料');
    final chaptersDir = Directory('${projectDir.path}${Platform.pathSeparator}章节内容');
    if (!await materialsDir.exists()) await materialsDir.create(recursive: true);
    if (!await chaptersDir.exists()) await chaptersDir.create(recursive: true);

    const encoder = JsonEncoder.withIndent('  ');
    await File('${projectDir.path}${Platform.pathSeparator}project.json')
        .writeAsString(encoder.convert(project.toJson()), flush: true);

    final expectedMaterialFiles = <String>{};
    for (final note in project.notes) {
      final fileName = _fileNameForTitle(note.title);
      expectedMaterialFiles.add(fileName);
      final file = File('${materialsDir.path}${Platform.pathSeparator}$fileName');
      await file.writeAsString(note.body, flush: true);
    }
    await _deleteUnexpectedMarkdownFiles(materialsDir, expectedMaterialFiles);

    final expectedChapterFiles = <String>{};
    for (final chapter in project.chapters) {
      final fileName = _fileNameForTitle(chapter.title);
      expectedChapterFiles.add(fileName);
      final file = File('${chaptersDir.path}${Platform.pathSeparator}$fileName');
      await file.writeAsString(chapter.content, flush: true);
    }
    await _deleteUnexpectedMarkdownFiles(chaptersDir, expectedChapterFiles);
  }

  Future<void> _deleteUnexpectedMarkdownFiles(Directory dir, Set<String> expectedNames) async {
    await for (final entity in dir.list(recursive: false, followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.md')) continue;
      final name = entity.path.split(Platform.pathSeparator).last;
      if (!expectedNames.contains(name)) await entity.delete();
    }
  }

  String _toPlainText(WritingProject project) {
    final buffer = StringBuffer()
      ..writeln(project.title)
      ..writeln(project.genre)
      ..writeln()
      ..writeln(project.description)
      ..writeln('\n====================\n');

    for (final chapter in project.chapters) {
      buffer
        ..writeln(chapter.title)
        ..writeln(List.filled(chapter.title.length.clamp(1, 80), '-').join())
        ..writeln()
        ..writeln(chapter.content.trim())
        ..writeln('\n');
    }

    if (project.notes.isNotEmpty) {
      buffer.writeln('\n====================\n小说资料\n');
      for (final note in project.notes) {
        buffer
          ..writeln('[${note.tag}] ${note.title}')
          ..writeln(note.body.trim())
          ..writeln();
      }
    }
    return buffer.toString();
  }

  String _toMarkdown(WritingProject project) {
    final buffer = StringBuffer()
      ..writeln('# ${project.title}')
      ..writeln()
      ..writeln('> 类型：${project.genre}')
      ..writeln()
      ..writeln(project.description)
      ..writeln();

    for (final chapter in project.chapters) {
      buffer
        ..writeln('## ${chapter.title}')
        ..writeln()
        ..writeln(chapter.content.trim())
        ..writeln();
    }

    if (project.notes.isNotEmpty) {
      buffer.writeln('---\n\n## 小说资料\n');
      for (final note in project.notes) {
        buffer
          ..writeln('### ${note.title}')
          ..writeln()
          ..writeln('- 标签：${note.tag}')
          ..writeln()
          ..writeln(note.body.trim())
          ..writeln();
      }
    }
    return buffer.toString();
  }

  String _fileNameForTitle(String title) => '${_safeName(_stripExtension(title))}.md';

  String _titleFromFile(String path) {
    final name = path.split(Platform.pathSeparator).last;
    return _stripExtension(name);
  }

  String _stripExtension(String title) {
    final trimmed = title.trim();
    for (final ext in const ['.md', '.txt', '.docx']) {
      if (trimmed.toLowerCase().endsWith(ext)) {
        return trimmed.substring(0, trimmed.length - ext.length);
      }
    }
    return trimmed;
  }

  String _safeName(String value) {
    final safe = value.trim().replaceAll(RegExp(r'[\\/:*?"<>|\s]+'), '_');
    return safe.isEmpty ? 'untitled' : safe;
  }

  int _chapterSortKey(String title) {
    final match = RegExp(r'(\d+)').firstMatch(title);
    if (match == null) return 999999;
    return int.tryParse(match.group(1) ?? '') ?? 999999;
  }

  String _dateStamp() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${now.year}${two(now.month)}${two(now.day)}-${two(now.hour)}${two(now.minute)}';
  }
}
