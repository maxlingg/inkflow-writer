# 墨舟写作 InkFlow Writer

一个原创、本地优先的小说写作工具 Flutter MVP。

## v0.2 更新

- 首页作品卡片改为更紧凑的小卡片。
- 新增 AI 技能库入口。
- 编辑器新增 AI 技能面板：续写、润色、扩写、优化对话、冲突升级、章节大纲、章节总结、起名、错字检查。
- 设置页新增 AI 服务配置：API Key、接口地址、模型名。
- 未填写 API Key 时，AI 技能会返回本地模板，方便离线测试 UI 流程。

## 主要功能

- 作品列表、新建/删除作品
- 章节管理、新建/重命名/删除章节
- 长文本编辑器、自动保存、字数统计
- 设定备忘录/人物世界观笔记
- TXT / Markdown 导出并调用系统分享
- 深色/浅色主题、编辑器字号设置
- OpenAI-compatible AI 技能调用

## 本机运行

```bash
flutter create inkflow_writer_app --org com.yourname.inkflow --platforms=android
cp -R inkflow_writer/lib inkflow_writer_app/
cp inkflow_writer/pubspec.yaml inkflow_writer_app/pubspec.yaml
cp inkflow_writer/analysis_options.yaml inkflow_writer_app/analysis_options.yaml
cd inkflow_writer_app
flutter pub get
flutter run
```

## 构建 APK

```bash
flutter build apk --release
```

AI 联网功能需要 Android INTERNET 权限。云端构建时请在 `android/app/src/main/AndroidManifest.xml` 的 `<manifest>` 节点内加入：

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

如果继续使用本项目提供的 GitHub Actions 工作流，请使用我给你的新版 workflow，它会自动插入该权限。
