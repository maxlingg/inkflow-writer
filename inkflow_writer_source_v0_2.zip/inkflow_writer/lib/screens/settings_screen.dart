import 'package:flutter/material.dart';

import '../services/app_settings.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('设置')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '外观',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      const SizedBox(height: 8),
                      RadioListTile<ThemeMode>(
                        value: ThemeMode.system,
                        groupValue: settings.themeMode,
                        onChanged: (value) {
                          if (value != null) settings.setThemeMode(value);
                        },
                        title: const Text('跟随系统'),
                      ),
                      RadioListTile<ThemeMode>(
                        value: ThemeMode.light,
                        groupValue: settings.themeMode,
                        onChanged: (value) {
                          if (value != null) settings.setThemeMode(value);
                        },
                        title: const Text('浅色'),
                      ),
                      RadioListTile<ThemeMode>(
                        value: ThemeMode.dark,
                        groupValue: settings.themeMode,
                        onChanged: (value) {
                          if (value != null) settings.setThemeMode(value);
                        },
                        title: const Text('深色'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '编辑器字号：${settings.editorFontSize.toStringAsFixed(0)}',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      Slider(
                        value: settings.editorFontSize,
                        min: 14,
                        max: 28,
                        divisions: 14,
                        label: settings.editorFontSize.toStringAsFixed(0),
                        onChanged: (value) {
                          settings.setEditorFontSize(value);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(4),
                  child: Column(
                    children: [
                      ListTile(
                        leading: Icon(
                          settings.hasAiApiKey
                              ? Icons.auto_awesome_rounded
                              : Icons.auto_awesome_outlined,
                        ),
                        title: const Text('AI 服务'),
                        subtitle: Text(
                          settings.hasAiApiKey
                              ? '已填写 API Key，将使用联网生成。'
                              : '未填写 API Key，技能会返回本地模板。',
                        ),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        title: const Text('API Key'),
                        subtitle: Text(
                          settings.hasAiApiKey ? '已保存，点此修改' : '点此填写',
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () => _editValue(
                          context: context,
                          title: 'API Key',
                          initialValue: settings.aiApiKey,
                          hintText: 'sk-...',
                          obscureText: true,
                          onSave: settings.setAiApiKey,
                        ),
                      ),
                      ListTile(
                        title: const Text('接口地址'),
                        subtitle: Text(settings.aiBaseUrl),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () => _editValue(
                          context: context,
                          title: '接口地址',
                          initialValue: settings.aiBaseUrl,
                          hintText: 'https://api.openai.com/v1',
                          onSave: settings.setAiBaseUrl,
                        ),
                      ),
                      ListTile(
                        title: const Text('模型名'),
                        subtitle: Text(settings.aiModel),
                        trailing: const Icon(Icons.chevron_right_rounded),
                        onTap: () => _editValue(
                          context: context,
                          title: '模型名',
                          initialValue: settings.aiModel,
                          hintText: 'gpt-4o-mini',
                          onSave: settings.setAiModel,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.verified_user_rounded),
                  title: const Text('隐私与数据'),
                  subtitle: const Text('作品默认保存在本机；AI Key 测试版保存在本机偏好设置中。正式发布前建议改为安全存储。'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _editValue({
    required BuildContext context,
    required String title,
    required String initialValue,
    required String hintText,
    required Future<void> Function(String value) onSave,
    bool obscureText = false,
  }) async {
    final controller = TextEditingController(text: initialValue);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          obscureText: obscureText,
          decoration: InputDecoration(hintText: hintText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('保存'),
          ),
        ],
      ),
    );
    if (value == null) return;
    await onSave(value);
  }
}
