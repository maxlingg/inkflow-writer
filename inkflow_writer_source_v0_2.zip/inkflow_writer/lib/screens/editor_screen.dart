import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/ai_skill.dart';
import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../utils/text_stats.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({
    super.key,
    required this.project,
    required this.chapterId,
    required this.settings,
  });

  final WritingProject project;
  final String chapterId;
  final AppSettings settings;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late WritingProject _project;
  late Chapter _chapter;
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  Timer? _saveTimer;
  bool _saving = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _chapter = _project.chapters.firstWhere((item) => item.id == widget.chapterId);
    _titleController = TextEditingController(text: _chapter.title);
    _contentController = TextEditingController(text: _chapter.content);
    _titleController.addListener(_scheduleSave);
    _contentController.addListener(_scheduleSave);
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final content = _contentController.text;

    return WillPopScope(
      onWillPop: () async {
        await _saveNow();
        return true;
      },
      child: AnimatedBuilder(
        animation: widget.settings,
        builder: (context, _) {
          return Scaffold(
            appBar: AppBar(
              title: _saving
                  ? const Text('正在保存…')
                  : Text(_dirty ? '未保存更改' : '已自动保存'),
              actions: [
                IconButton(
                  tooltip: 'AI 技能',
                  onPressed: _openAiAssistant,
                  icon: const Icon(Icons.auto_awesome_rounded),
                ),
                IconButton(
                  tooltip: '立即保存',
                  onPressed: _saveNow,
                  icon: const Icon(Icons.cloud_done_rounded),
                ),
              ],
            ),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: TextField(
                    controller: _titleController,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                    decoration: const InputDecoration(
                      hintText: '章节标题',
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: TextField(
                      controller: _contentController,
                      expands: true,
                      maxLines: null,
                      minLines: null,
                      textAlignVertical: TextAlignVertical.top,
                      keyboardType: TextInputType.multiline,
                      style: TextStyle(
                        fontSize: widget.settings.editorFontSize,
                        height: 1.75,
                      ),
                      decoration: InputDecoration(
                        hintText: '写下这一章发生了什么…',
                        filled: true,
                        fillColor: colors.surfaceContainerHighest.withOpacity(0.42),
                        contentPadding: const EdgeInsets.all(18),
                      ),
                    ),
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: colors.outlineVariant.withOpacity(0.5)),
                      ),
                    ),
                    child: Row(
                      children: [
                        _EditorStat(label: '字符', value: '${TextStats.characters(content)}'),
                        const SizedBox(width: 12),
                        _EditorStat(label: '词/字', value: '${TextStats.words(content)}'),
                        const Spacer(),
                        FilledButton.tonalIcon(
                          onPressed: _openAiAssistant,
                          icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                          label: const Text('AI 技能'),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          TextStats.readingTimeLabel(content),
                          style: TextStyle(color: colors.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _scheduleSave() {
    if (!_dirty) {
      setState(() => _dirty = true);
    }
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 650), _saveNow);
  }

  Future<void> _saveNow() async {
    if (_saving) return;
    _saveTimer?.cancel();

    setState(() => _saving = true);
    final now = DateTime.now();
    final nextChapter = _chapter.copyWith(
      title: _titleController.text.trim().isEmpty
          ? '未命名章节'
          : _titleController.text.trim(),
      content: _contentController.text,
      updatedAt: now,
    );
    final chapters = _project.chapters
        .map((item) => item.id == nextChapter.id ? nextChapter : item)
        .toList();
    final nextProject = _project.copyWith(chapters: chapters, updatedAt: now);
    await StorageService.instance.upsertProject(nextProject);

    if (!mounted) return;
    setState(() {
      _chapter = nextChapter;
      _project = nextProject;
      _saving = false;
      _dirty = false;
    });
  }

  Future<void> _openAiAssistant() async {
    await _saveNow();
    if (!mounted) return;

    final result = await showModalBottomSheet<_AiAssistantResult>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => _AiAssistantSheet(
        settings: widget.settings,
        project: _project,
        chapter: _chapter,
      ),
    );

    if (result == null || result.text.trim().isEmpty) return;
    _applyAiText(result);
  }

  void _applyAiText(_AiAssistantResult result) {
    final text = result.text.trimRight();
    final value = _contentController.value;

    if (result.mode == _AiInsertMode.insert && value.selection.isValid) {
      final start = value.selection.start.clamp(0, value.text.length).toInt();
      final end = value.selection.end.clamp(0, value.text.length).toInt();
      final nextText = value.text.replaceRange(start, end, text);
      _contentController.value = TextEditingValue(
        text: nextText,
        selection: TextSelection.collapsed(offset: start + text.length),
      );
    } else {
      final prefix = value.text.trim().isEmpty ? '' : '\n\n';
      final nextText = '${value.text}$prefix$text';
      _contentController.value = TextEditingValue(
        text: nextText,
        selection: TextSelection.collapsed(offset: nextText.length),
      );
    }
    _scheduleSave();
  }
}

class _AiAssistantSheet extends StatefulWidget {
  const _AiAssistantSheet({
    required this.settings,
    required this.project,
    required this.chapter,
  });

  final AppSettings settings;
  final WritingProject project;
  final Chapter chapter;

  @override
  State<_AiAssistantSheet> createState() => _AiAssistantSheetState();
}

class _AiAssistantSheetState extends State<_AiAssistantSheet> {
  AiSkill _skill = builtInAiSkills.first;
  final _instructionController = TextEditingController();
  bool _loading = false;
  String? _output;
  String? _error;

  @override
  void dispose() {
    _instructionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return AnimatedPadding(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(bottom: bottom),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.86,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'AI 技能',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.w900,
                                ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            widget.settings.hasAiApiKey
                                ? '联网生成：${widget.settings.aiModel}'
                                : '未配置 API Key：当前使用本地模板',
                            style: TextStyle(color: colors.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                    if (_loading)
                      const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(strokeWidth: 3),
                      ),
                  ],
                ),
              ),
              SizedBox(
                height: 54,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  scrollDirection: Axis.horizontal,
                  itemCount: builtInAiSkills.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final skill = builtInAiSkills[index];
                    return ChoiceChip(
                      selected: _skill.id == skill.id,
                      label: Text('${skill.icon} ${skill.name}'),
                      onSelected: _loading
                          ? null
                          : (_) => setState(() {
                                _skill = skill;
                                _output = null;
                                _error = null;
                              }),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _skill.shortDescription,
                      style: TextStyle(color: colors.onSurfaceVariant),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _instructionController,
                      minLines: 2,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        labelText: '补充要求，可不填',
                        hintText: '例如：更热血一点、控制在300字、偏悬疑氛围……',
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _loading ? null : _generate,
                        icon: const Icon(Icons.auto_awesome_rounded),
                        label: Text(_loading ? '生成中…' : '运行「${_skill.name}」'),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: colors.surfaceContainerHighest.withOpacity(0.48),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: _buildOutput(context),
                ),
              ),
              if ((_output ?? '').trim().isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                  child: Row(
                    children: [
                      OutlinedButton.icon(
                        onPressed: _copyOutput,
                        icon: const Icon(Icons.copy_rounded),
                        label: const Text('复制'),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.tonal(
                          onPressed: () => Navigator.pop(
                            context,
                            _AiAssistantResult(
                              text: _output!,
                              mode: _AiInsertMode.insert,
                            ),
                          ),
                          child: const Text('插入光标'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton(
                          onPressed: () => Navigator.pop(
                            context,
                            _AiAssistantResult(
                              text: _output!,
                              mode: _AiInsertMode.append,
                            ),
                          ),
                          child: const Text('追加文末'),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOutput(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    if (_error != null) {
      return SingleChildScrollView(
        child: Text(
          _error!,
          style: TextStyle(color: colors.error),
        ),
      );
    }
    if ((_output ?? '').trim().isEmpty) {
      return Center(
        child: Text(
          '选择一个技能，然后点击生成。\n输出会显示在这里，可复制、插入光标或追加到文末。',
          textAlign: TextAlign.center,
          style: TextStyle(color: colors.onSurfaceVariant),
        ),
      );
    }
    return SingleChildScrollView(
      child: SelectableText(
        _output!,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.65),
      ),
    );
  }

  Future<void> _generate() async {
    setState(() {
      _loading = true;
      _error = null;
      _output = null;
    });

    try {
      final output = await AiService.instance.runSkill(
        settings: widget.settings,
        skill: _skill,
        project: widget.project,
        chapter: widget.chapter,
        extraInstruction: _instructionController.text,
      );
      if (!mounted) return;
      setState(() => _output = output);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _copyOutput() async {
    final output = _output;
    if (output == null || output.trim().isEmpty) return;
    await Clipboard.setData(ClipboardData(text: output));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已复制到剪贴板')),
    );
  }
}

class _AiAssistantResult {
  const _AiAssistantResult({required this.text, required this.mode});

  final String text;
  final _AiInsertMode mode;
}

enum _AiInsertMode { insert, append }

class _EditorStat extends StatelessWidget {
  const _EditorStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text('$label $value'),
    );
  }
}
