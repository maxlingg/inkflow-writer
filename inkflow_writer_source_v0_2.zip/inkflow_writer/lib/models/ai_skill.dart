class AiSkill {
  const AiSkill({
    required this.id,
    required this.name,
    required this.icon,
    required this.shortDescription,
    required this.prompt,
  });

  final String id;
  final String name;
  final String icon;
  final String shortDescription;
  final String prompt;
}

const builtInAiSkills = <AiSkill>[
  AiSkill(
    id: 'continue',
    name: '续写本章',
    icon: '✍️',
    shortDescription: '根据现有正文自然续写一段，不改变设定。',
    prompt: '请根据当前章节内容自然续写，延续人物语气和叙事节奏。不要总结，不要解释，直接给出可放入正文的文本。',
  ),
  AiSkill(
    id: 'polish',
    name: '润色文风',
    icon: '✨',
    shortDescription: '让语言更流畅、更有画面感。',
    prompt: '请润色当前文本，使表达更流畅、有画面感，保留原意、人物关系和剧情信息。只输出润色后的正文。',
  ),
  AiSkill(
    id: 'expand',
    name: '扩写场景',
    icon: '🌿',
    shortDescription: '增加环境、动作、心理和细节。',
    prompt: '请扩写当前场景，重点补充环境描写、人物动作、心理活动和细节，但不要推进过多新剧情。只输出扩写后的正文。',
  ),
  AiSkill(
    id: 'dialogue',
    name: '优化对话',
    icon: '💬',
    shortDescription: '让对白更自然、有角色差异。',
    prompt: '请优化当前片段里的对话，让每个角色说话更自然、更有辨识度，同时保留剧情目的。只输出优化后的正文。',
  ),
  AiSkill(
    id: 'conflict',
    name: '冲突升级',
    icon: '⚡',
    shortDescription: '给本章增加阻力、误会或悬念。',
    prompt: '请为当前章节提出 5 个冲突升级方案，每个方案包含：触发点、人物反应、后果、可埋伏笔。',
  ),
  AiSkill(
    id: 'outline',
    name: '章节大纲',
    icon: '🧭',
    shortDescription: '生成下一章或当前章结构。',
    prompt: '请根据作品信息和当前章节，生成一个清晰的章节大纲，包含开场、转折、高潮、结尾钩子。',
  ),
  AiSkill(
    id: 'summary',
    name: '章节总结',
    icon: '🧾',
    shortDescription: '总结剧情进展和伏笔。',
    prompt: '请总结当前章节，分为：剧情进展、人物变化、伏笔、下一章可承接点。',
  ),
  AiSkill(
    id: 'names',
    name: '起名助手',
    icon: '🏷️',
    shortDescription: '为人物、地点、组织生成名字。',
    prompt: '请根据作品类型和设定，生成 12 个可用名字。按人物名、地点名、组织名分类，并简短说明气质。',
  ),
  AiSkill(
    id: 'proofread',
    name: '错字检查',
    icon: '🔎',
    shortDescription: '检查错别字、病句和重复表达。',
    prompt: '请检查当前文本中的错别字、病句、重复表达和不通顺处。用列表指出问题，并给出修改建议。',
  ),
];

AiSkill skillById(String id) {
  return builtInAiSkills.firstWhere(
    (skill) => skill.id == id,
    orElse: () => builtInAiSkills.first,
  );
}
