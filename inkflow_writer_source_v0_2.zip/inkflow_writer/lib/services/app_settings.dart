import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  static const _themeModeKey = 'themeMode';
  static const _editorFontSizeKey = 'editorFontSize';
  static const _aiApiKeyKey = 'aiApiKey';
  static const _aiBaseUrlKey = 'aiBaseUrl';
  static const _aiModelKey = 'aiModel';

  ThemeMode _themeMode = ThemeMode.system;
  double _editorFontSize = 18;
  String _aiApiKey = '';
  String _aiBaseUrl = 'https://api.openai.com/v1';
  String _aiModel = 'gpt-4o-mini';

  ThemeMode get themeMode => _themeMode;
  double get editorFontSize => _editorFontSize;
  String get aiApiKey => _aiApiKey;
  String get aiBaseUrl => _aiBaseUrl;
  String get aiModel => _aiModel;
  bool get hasAiApiKey => _aiApiKey.trim().isNotEmpty;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _themeMode = _themeModeFromString(prefs.getString(_themeModeKey));
    _editorFontSize = (prefs.getDouble(_editorFontSizeKey) ?? 18).clamp(14, 28).toDouble();
    _aiApiKey = prefs.getString(_aiApiKeyKey) ?? '';
    _aiBaseUrl = prefs.getString(_aiBaseUrlKey) ?? _aiBaseUrl;
    _aiModel = prefs.getString(_aiModelKey) ?? _aiModel;
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    if (_themeMode == mode) return;
    _themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeModeKey, mode.name);
  }

  Future<void> setEditorFontSize(double size) async {
    final nextSize = size.clamp(14, 28).toDouble();
    if (_editorFontSize == nextSize) return;
    _editorFontSize = nextSize;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_editorFontSizeKey, nextSize);
  }

  Future<void> setAiApiKey(String value) async {
    _aiApiKey = value.trim();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aiApiKeyKey, _aiApiKey);
  }

  Future<void> setAiBaseUrl(String value) async {
    final next = value.trim().isEmpty ? 'https://api.openai.com/v1' : value.trim();
    _aiBaseUrl = next.replaceAll(RegExp(r'/+$'), '');
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aiBaseUrlKey, _aiBaseUrl);
  }

  Future<void> setAiModel(String value) async {
    _aiModel = value.trim().isEmpty ? 'gpt-4o-mini' : value.trim();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_aiModelKey, _aiModel);
  }

  ThemeMode _themeModeFromString(String? value) {
    return switch (value) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
  }
}
