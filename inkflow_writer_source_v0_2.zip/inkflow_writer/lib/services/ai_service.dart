import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/ai_skill.dart';
import '../models/writing_project.dart';
import 'app_settings.dart';

class AiService {
  AiService._();

  static final AiService instance = AiService._();

  Future<String> runSkill({
    required AppSettings settings,
    required AiSkill skill,
    required WritingProject project,
    required Chapter chapter,
    required String extraInstruction,
  }) async {
    final apiKey = settings.aiApiKey.trim();
    if (apiKey.isEmpty) {
      return _localDraft(skill, project, chapter, extraInstruction);
    }

    final baseUrl = settings.aiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.parse('$baseUrl/chat/completions');
    final content = _compact(chapter.content, 5200);
    final notes = project.notes
        .take(12)
        .map((note) => '[${note.tag}] ${note.title}: ${_compact(note.body, 280)}')
        .join('\n');

    final userPrompt = '''
作品名：${project.title}
类型：${project.genre}
简介：${project.description.isEmpty ? '无' : project.description}

设定备忘：
${notes.isEmpty ? '无' : notes}

当前章节：${chapter.title}
当前正文节选：
$content

使用技能：${skill.name}
技能要求：${skill.prompt}
补充要求：${extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim()}
''';

    final response = await http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $apiKey',
          },
          body: jsonEncode({
            'model': settings.aiModel.trim().isEmpty ? 'gpt-4o-mini' : settings.aiModel.trim(),
            'messages': [
              {
                'role': 'system',
                'content': '你是一个中文小说创作助手。你尊重作者已有设定，输出内容可直接用于写作，不要编造与上下文冲突的信息。',
              },
              {'role': 'user', 'content': userPrompt},
            ],
            'temperature': 0.85,
            'max_tokens': 1600,
          }),
        )
        .timeout(const Duration(seconds: 45));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw AiException('AI 请求失败：HTTP ${response.statusCode}\n${response.body}');
    }

    final decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final choices = decoded['choices'];
    if (choices is List && choices.isNotEmpty) {
      final first = choices.first;
      if (first is Map) {
        final message = first['message'];
        if (message is Map && message['content'] is String) {
          final text = (message['content'] as String).trim();
          if (text.isNotEmpty) return text;
        }
        if (first['text'] is String) {
          final text = (first['text'] as String).trim();
          if (text.isNotEmpty) return text;
        }
      }
    }
    throw const AiException('AI 返回为空，请稍后重试。');
  }

  String _compact(String value, int maxChars) {
    final text = value.trim();
    if (text.length <= maxChars) return text;
    return '……前文省略……\n${text.substring(text.length - maxChars)}';
  }

  String _localDraft(
    AiSkill skill,
    WritingProject project,
    Chapter chapter,
    String extraInstruction,
  ) {
    final instruction = extraInstruction.trim().isEmpty ? '无' : extraInstruction.trim();
    switch (skill.id) {
      case 'continue':
        return '''【本地灵感草稿｜未连接 AI】

他停在原地，像是终于听见了那个一直被忽略的声音。

周围的一切都没有变化，可他知道，真正改变的东西已经发生了。下一步不能再靠侥幸，也不能再把答案交给别人。

可就在他准备开口时，一个意料之外的人出现了。

补充要求：$instruction''';
      case 'outline':
        return '''【本地大纲模板｜未连接 AI】

1. 开场：用一个具体动作切入，交代${chapter.title}的当前局面。
2. 阻力：让主角遇到一个无法回避的问题。
3. 选择：主角做出决定，并承担代价。
4. 反转：揭示一个新信息，改变读者对前文的理解。
5. 结尾钩子：留下一个问题，引到下一章。

作品：${project.title}
补充要求：$instruction''';
      case 'conflict':
        return '''【本地冲突卡｜未连接 AI】

- 误会升级：让一个善意行为被关键人物误解。
- 时间压力：给主角加一个必须马上完成的倒计时。
- 利益交换：让主角必须牺牲一样重要的东西才能得到线索。
- 旧事回响：让过去的选择在本章产生后果。
- 盟友动摇：让可信任的人提出反对意见。

补充要求：$instruction''';
      case 'names':
        return '''【本地起名卡｜未连接 AI】

人物名：沈渡、林见微、顾长宁、许照夜
地点名：雾港、白塔街、沉星镇、旧钟楼
组织名：拾火会、青岚司、北境商盟、无名档案馆

补充要求：$instruction''';
      case 'proofread':
        return '''【本地检查提示｜未连接 AI】

请重点检查：
1. 同一段里是否重复使用相同动词。
2. 人物称呼是否前后一致。
3. 时间线是否跳跃过快。
4. 对话后是否缺少动作或情绪承接。
5. 长句是否可以拆成两句。

补充要求：$instruction''';
      default:
        return '''【本地技能提示｜未连接 AI】

技能：${skill.name}
用法：${skill.shortDescription}

建议先在“设置 → AI 服务”里填写 API Key、接口地址和模型名。未填写前，应用只会返回本地模板，不会联网生成。

补充要求：$instruction''';
    }
  }
}

class AiException implements Exception {
  const AiException(this.message);
  final String message;

  @override
  String toString() => message;
}
