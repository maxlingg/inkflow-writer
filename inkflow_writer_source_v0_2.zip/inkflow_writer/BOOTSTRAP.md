# Bootstrap

1. 用 Flutter 创建原生壳：

```bash
flutter create inkflow_writer_app --org com.yourname.inkflow --platforms=android
```

2. 复制源码：

```bash
cp -R inkflow_writer/lib inkflow_writer_app/
cp inkflow_writer/pubspec.yaml inkflow_writer_app/pubspec.yaml
cp inkflow_writer/analysis_options.yaml inkflow_writer_app/analysis_options.yaml
```

3. 如果要使用联网 AI，给 Android 加 INTERNET 权限：

```bash
python3 - <<'PY'
from pathlib import Path
path = Path('inkflow_writer_app/android/app/src/main/AndroidManifest.xml')
text = path.read_text()
needle = '<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
permission = '    <uses-permission android:name="android.permission.INTERNET" />'
if 'android.permission.INTERNET' not in text:
    text = text.replace(needle, needle + '\n' + permission)
    path.write_text(text)
PY
```

4. 获取依赖并运行：

```bash
cd inkflow_writer_app
flutter pub get
flutter run
```

5. 构建 APK：

```bash
flutter build apk --release
```
