import 'dart:async';

import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../utils/text_stats.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({
    super.key,
    required this.project,
    required this.chapterId,
    required this.settings,
  });

  final WritingProject project;
  final String chapterId;
  final AppSettings settings;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late WritingProject _project;
  late Chapter _chapter;
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  Timer? _saveTimer;
  bool _saving = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _chapter = _project.chapters.firstWhere((item) => item.id == widget.chapterId);
    _titleController = TextEditingController(text: _chapter.title);
    _contentController = TextEditingController(text: _chapter.content);
    _titleController.addListener(_scheduleSave);
    _contentController.addListener(_scheduleSave);
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final content = _contentController.text;

    return WillPopScope(
      onWillPop: () async {
        await _saveNow();
        return true;
      },
      child: AnimatedBuilder(
        animation: widget.settings,
        builder: (context, _) {
          return Scaffold(
            appBar: AppBar(
              title: _saving
                  ? const Text('正在保存…')
                  : Text(_dirty ? '未保存更改' : '已自动保存'),
              actions: [
                IconButton(
                  tooltip: '立即保存',
                  onPressed: _saveNow,
                  icon: const Icon(Icons.cloud_done_rounded),
                ),
              ],
            ),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: TextField(
                    controller: _titleController,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                    decoration: const InputDecoration(
                      hintText: '章节标题',
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: TextField(
                      controller: _contentController,
                      expands: true,
                      maxLines: null,
                      minLines: null,
                      textAlignVertical: TextAlignVertical.top,
                      keyboardType: TextInputType.multiline,
                      style: TextStyle(
                        fontSize: widget.settings.editorFontSize,
                        height: 1.75,
                      ),
                      decoration: InputDecoration(
                        hintText: '写下这一章发生了什么…',
                        filled: true,
                        fillColor: colors.surfaceContainerHighest.withOpacity(0.42),
                        contentPadding: const EdgeInsets.all(18),
                      ),
                    ),
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: colors.outlineVariant.withOpacity(0.5)),
                      ),
                    ),
                    child: Row(
                      children: [
                        _EditorStat(label: '字符', value: '${TextStats.characters(content)}'),
                        const SizedBox(width: 12),
                        _EditorStat(label: '词/字', value: '${TextStats.words(content)}'),
                        const Spacer(),
                        Text(
                          TextStats.readingTimeLabel(content),
                          style: TextStyle(color: colors.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _scheduleSave() {
    if (!_dirty) {
      setState(() => _dirty = true);
    }
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 650), _saveNow);
  }

  Future<void> _saveNow() async {
    if (_saving) return;
    _saveTimer?.cancel();

    setState(() => _saving = true);
    final now = DateTime.now();
    final nextChapter = _chapter.copyWith(
      title: _titleController.text.trim().isEmpty
          ? '未命名章节'
          : _titleController.text.trim(),
      content: _contentController.text,
      updatedAt: now,
    );
    final chapters = _project.chapters
        .map((item) => item.id == nextChapter.id ? nextChapter : item)
        .toList();
    final nextProject = _project.copyWith(chapters: chapters, updatedAt: now);
    await StorageService.instance.upsertProject(nextProject);

    if (!mounted) return;
    setState(() {
      _chapter = nextChapter;
      _project = nextProject;
      _saving = false;
      _dirty = false;
    });
  }
}

class _EditorStat extends StatelessWidget {
  const _EditorStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text('$label $value'),
    );
  }
}
