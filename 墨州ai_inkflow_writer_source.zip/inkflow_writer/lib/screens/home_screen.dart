import 'package:flutter/material.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../utils/text_stats.dart';
import '../widgets/empty_state.dart';
import 'project_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<WritingProject> _projects = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final projects = await StorageService.instance.loadProjects();
    if (!mounted) return;
    setState(() {
      _projects = projects;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final totalChars = _projects.fold<int>(
      0,
      (value, project) => value + project.totalCharacters,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('墨舟写作'),
        actions: [
          IconButton(
            tooltip: '设置',
            icon: const Icon(Icons.tune_rounded),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => SettingsScreen(settings: widget.settings),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreateProjectDialog,
        icon: const Icon(Icons.add_rounded),
        label: const Text('新建作品'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                    sliver: SliverToBoxAdapter(
                      child: _DashboardCard(
                        projectCount: _projects.length,
                        characterCount: totalChars,
                      ),
                    ),
                  ),
                  if (_projects.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: EmptyState(
                        icon: Icons.edit_note_rounded,
                        title: '从一个故事开始',
                        message: '创建作品、拆分章节、记录设定，让灵感稳定落地。',
                        action: FilledButton.icon(
                          onPressed: _showCreateProjectDialog,
                          icon: const Icon(Icons.add_rounded),
                          label: const Text('创建第一部作品'),
                        ),
                      ),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                      sliver: SliverList.separated(
                        itemCount: _projects.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final project = _projects[index];
                          return _ProjectCard(
                            project: project,
                            onOpen: () async {
                              await Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ProjectScreen(
                                    project: project,
                                    settings: widget.settings,
                                  ),
                                ),
                              );
                              await _load();
                            },
                            onDelete: () => _confirmDeleteProject(project),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
      backgroundColor: colors.surface,
    );
  }

  Future<void> _showCreateProjectDialog() async {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    final genreController = TextEditingController(text: '长篇小说');

    final result = await showDialog<WritingProject>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('新建作品'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  autofocus: true,
                  decoration: const InputDecoration(labelText: '作品名'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: genreController,
                  decoration: const InputDecoration(labelText: '类型'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: descriptionController,
                  minLines: 3,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: '一句话简介'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                final now = DateTime.now();
                final title = titleController.text.trim();
                if (title.isEmpty) return;
                Navigator.pop(
                  context,
                  WritingProject(
                    id: newEntityId('project'),
                    title: title,
                    description: descriptionController.text.trim(),
                    genre: genreController.text.trim().isEmpty
                        ? '原创'
                        : genreController.text.trim(),
                    createdAt: now,
                    updatedAt: now,
                    chapters: const [],
                    notes: const [],
                  ),
                );
              },
              child: const Text('创建'),
            ),
          ],
        );
      },
    );

    if (result == null) return;
    await StorageService.instance.upsertProject(result);
    await _load();
  }

  Future<void> _confirmDeleteProject(WritingProject project) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${project.title}」？'),
        content: const Text('作品、章节和备忘录都会从本机数据中移除。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );

    if (shouldDelete != true) return;
    await StorageService.instance.deleteProject(project.id);
    await _load();
  }
}

class _DashboardCard extends StatelessWidget {
  const _DashboardCard({
    required this.projectCount,
    required this.characterCount,
  });

  final int projectCount;
  final int characterCount;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            colors.primaryContainer,
            colors.secondaryContainer,
          ],
        ),
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '今日也把想象写成文字',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: colors.onPrimaryContainer,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            '本地保存 · 自动落盘 · 可导出分享',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: colors.onPrimaryContainer.withOpacity(0.78),
                ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              _MetricPill(label: '作品', value: '$projectCount'),
              const SizedBox(width: 10),
              _MetricPill(label: '字符', value: '$characterCount'),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetricPill extends StatelessWidget {
  const _MetricPill({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: colors.surface.withOpacity(0.64),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Text(
            value,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(width: 6),
          Text(label),
        ],
      ),
    );
  }
}

class _ProjectCard extends StatelessWidget {
  const _ProjectCard({
    required this.project,
    required this.onOpen,
    required this.onDelete,
  });

  final WritingProject project;
  final VoidCallback onOpen;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final text = project.chapters.map((chapter) => chapter.content).join('\n');

    return Card(
      color: colors.surfaceContainerHighest.withOpacity(0.58),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onOpen,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          project.title,
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          project.description.isEmpty
                              ? '还没有简介'
                              : project.description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: colors.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'delete') onDelete();
                    },
                    itemBuilder: (context) => const [
                      PopupMenuItem(value: 'delete', child: Text('删除作品')),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _InfoChip(icon: Icons.auto_stories_rounded, label: project.genre),
                  _InfoChip(
                    icon: Icons.notes_rounded,
                    label: '${project.totalChapters} 章',
                  ),
                  _InfoChip(
                    icon: Icons.text_fields_rounded,
                    label: '${TextStats.characters(text)} 字符',
                  ),
                  _InfoChip(
                    icon: Icons.schedule_rounded,
                    label: TextStats.readingTimeLabel(text),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Chip(
      avatar: Icon(icon, size: 18),
      label: Text(label),
      backgroundColor: colors.surface,
      side: BorderSide.none,
    );
  }
}
