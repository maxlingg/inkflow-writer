import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../utils/text_stats.dart';
import '../widgets/empty_state.dart';
import 'editor_screen.dart';
import 'notes_screen.dart';

class ProjectScreen extends StatefulWidget {
  const ProjectScreen({super.key, required this.project, required this.settings});

  final WritingProject project;
  final AppSettings settings;

  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  late WritingProject _project;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _refresh();
  }

  Future<void> _refresh() async {
    final projects = await StorageService.instance.loadProjects();
    WritingProject? fresh;
    for (final item in projects) {
      if (item.id == _project.id) {
        fresh = item;
        break;
      }
    }
    if (fresh == null || !mounted) return;
    setState(() => _project = fresh!);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final allText = _project.chapters.map((chapter) => chapter.content).join('\n');

    return Scaffold(
      appBar: AppBar(
        title: Text(_project.title),
        actions: [
          IconButton(
            tooltip: '设定备忘',
            icon: const Icon(Icons.dashboard_customize_rounded),
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => NotesScreen(project: _project),
                ),
              );
              await _refresh();
            },
          ),
          PopupMenuButton<String>(
            onSelected: (value) async {
              switch (value) {
                case 'txt':
                  await _export(ExportFormat.txt);
                  break;
                case 'md':
                  await _export(ExportFormat.markdown);
                  break;
                case 'ideas':
                  _showInspirationSheet();
                  break;
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'ideas', child: Text('灵感助手')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'txt', child: Text('导出 TXT')),
              PopupMenuItem(value: 'md', child: Text('导出 Markdown')),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createChapter,
        icon: const Icon(Icons.add_rounded),
        label: const Text('新章节'),
      ),
      body: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: colors.surfaceContainerHighest.withOpacity(0.58),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _project.description.isEmpty
                          ? '这个故事还没有简介。'
                          : _project.description,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _ProjectStat(label: '类型', value: _project.genre),
                        _ProjectStat(label: '章节', value: '${_project.totalChapters}'),
                        _ProjectStat(
                          label: '字符',
                          value: '${TextStats.characters(allText)}',
                        ),
                        _ProjectStat(
                          label: '备忘',
                          value: '${_project.notes.length}',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (_project.chapters.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: EmptyState(
                icon: Icons.menu_book_rounded,
                title: '还没有章节',
                message: '先写一个开篇，后续再慢慢拆分场景。',
                action: FilledButton.icon(
                  onPressed: _createChapter,
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('创建章节'),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
              sliver: SliverList.separated(
                itemCount: _project.chapters.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final chapter = _project.chapters[index];
                  return _ChapterTile(
                    index: index,
                    chapter: chapter,
                    onOpen: () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => EditorScreen(
                            project: _project,
                            chapterId: chapter.id,
                            settings: widget.settings,
                          ),
                        ),
                      );
                      await _refresh();
                    },
                    onRename: () => _renameChapter(chapter),
                    onDelete: () => _deleteChapter(chapter),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _createChapter() async {
    final controller = TextEditingController(text: '第 ${_project.chapters.length + 1} 章');
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('新建章节'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: '章节标题'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('创建'),
          ),
        ],
      ),
    );

    if (title == null || title.isEmpty) return;
    final now = DateTime.now();
    final chapter = Chapter(
      id: newEntityId('chapter'),
      title: title,
      content: '',
      createdAt: now,
      updatedAt: now,
    );
    final next = _project.copyWith(
      chapters: [..._project.chapters, chapter],
      updatedAt: now,
    );
    await StorageService.instance.upsertProject(next);
    setState(() => _project = next);

    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => EditorScreen(
          project: next,
          chapterId: chapter.id,
          settings: widget.settings,
        ),
      ),
    );
    await _refresh();
  }

  Future<void> _renameChapter(Chapter chapter) async {
    final controller = TextEditingController(text: chapter.title);
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('重命名章节'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: '章节标题'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('保存'),
          ),
        ],
      ),
    );

    if (title == null || title.isEmpty) return;
    final chapters = _project.chapters
        .map((item) => item.id == chapter.id
            ? item.copyWith(title: title, updatedAt: DateTime.now())
            : item)
        .toList();
    final next = _project.copyWith(chapters: chapters, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    setState(() => _project = next);
  }

  Future<void> _deleteChapter(Chapter chapter) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${chapter.title}」？'),
        content: const Text('该章节正文会从本机数据中移除。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );

    if (shouldDelete != true) return;
    final chapters = _project.chapters.where((item) => item.id != chapter.id).toList();
    final next = _project.copyWith(chapters: chapters, updatedAt: DateTime.now());
    await StorageService.instance.upsertProject(next);
    setState(() => _project = next);
  }

  Future<void> _export(ExportFormat format) async {
    await _refresh();
    final path = await StorageService.instance.exportProject(_project, format: format);
    await Share.shareXFiles(
      [XFile(path)],
      text: '「${_project.title}」已导出',
    );
  }

  void _showInspirationSheet() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        final cards = [
          ('人物动机', '让主角在本章做一个会付出代价的选择。'),
          ('冲突升级', '把外部阻力和内心恐惧放在同一个场景里。'),
          ('章节收束', '用一个未被回答的问题结尾，推动读者进入下一章。'),
          ('伏笔回收', '挑一个早期细节，让它在当前章节改变局势。'),
        ];
        return SafeArea(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            itemCount: cards.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final (title, body) = cards[index];
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.auto_awesome_rounded),
                  title: Text(title),
                  subtitle: Text(body),
                ),
              );
            },
          ),
        );
      },
    );
  }
}

class _ProjectStat extends StatelessWidget {
  const _ProjectStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: colors.onSurfaceVariant)),
        ],
      ),
    );
  }
}

class _ChapterTile extends StatelessWidget {
  const _ChapterTile({
    required this.index,
    required this.chapter,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
  });

  final int index;
  final Chapter chapter;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: colors.surfaceContainerHighest.withOpacity(0.52),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        leading: CircleAvatar(
          child: Text('${index + 1}'),
        ),
        title: Text(
          chapter.title,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          '${TextStats.characters(chapter.content)} 字符 · ${TextStats.readingTimeLabel(chapter.content)}',
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (value) {
            if (value == 'rename') onRename();
            if (value == 'delete') onDelete();
          },
          itemBuilder: (context) => const [
            PopupMenuItem(value: 'rename', child: Text('重命名')),
            PopupMenuItem(value: 'delete', child: Text('删除')),
          ],
        ),
        onTap: onOpen,
      ),
    );
  }
}
