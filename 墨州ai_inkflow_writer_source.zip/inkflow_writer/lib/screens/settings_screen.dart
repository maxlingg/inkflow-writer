import 'package:flutter/material.dart';

import '../services/app_settings.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('设置')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '外观',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      const SizedBox(height: 8),
                      RadioListTile<ThemeMode>(
                        value: ThemeMode.system,
                        groupValue: settings.themeMode,
                        onChanged: (value) => settings.setThemeMode(value!),
                        title: const Text('跟随系统'),
                      ),
                      RadioListTile<ThemeMode>(
                        value: ThemeMode.light,
                        groupValue: settings.themeMode,
                        onChanged: (value) => settings.setThemeMode(value!),
                        title: const Text('浅色'),
                      ),
                      RadioListTile<ThemeMode>(
                        value: ThemeMode.dark,
                        groupValue: settings.themeMode,
                        onChanged: (value) => settings.setThemeMode(value!),
                        title: const Text('深色'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '编辑器字号：${settings.editorFontSize.toStringAsFixed(0)}',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                      Slider(
                        value: settings.editorFontSize,
                        min: 14,
                        max: 28,
                        divisions: 14,
                        label: settings.editorFontSize.toStringAsFixed(0),
                        onChanged: settings.setEditorFontSize,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.verified_user_rounded),
                  title: const Text('隐私与数据'),
                  subtitle: const Text('作品默认保存在本机应用文档目录；导出时才会生成分享文件。'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
