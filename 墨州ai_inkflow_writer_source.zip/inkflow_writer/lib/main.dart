import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'services/app_settings.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = AppSettings();
  runApp(InkFlowApp(settings: settings));
}

class InkFlowApp extends StatelessWidget {
  const InkFlowApp({super.key, required this.settings});

  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: '墨舟写作',
          themeMode: settings.themeMode,
          theme: _theme(Brightness.light),
          darkTheme: _theme(Brightness.dark),
          home: HomeScreen(settings: settings),
        );
      },
    );
  }

  ThemeData _theme(Brightness brightness) {
    final seedColor = brightness == Brightness.light
        ? const Color(0xFF4F46E5)
        : const Color(0xFFA5B4FC);

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: ColorScheme.fromSeed(
        seedColor: seedColor,
        brightness: brightness,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
