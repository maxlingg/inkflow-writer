import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/writing_project.dart';

enum ExportFormat { txt, markdown }

class StorageService {
  StorageService._();

  static final StorageService instance = StorageService._();

  Future<List<WritingProject>> loadProjects() async {
    final file = await _projectFile();
    if (!await file.exists()) return [];

    final raw = await file.readAsString();
    if (raw.trim().isEmpty) return [];

    try {
      final decoded = jsonDecode(raw) as List;
      final projects = decoded
          .whereType<Map>()
          .map((item) => WritingProject.fromJson(Map<String, dynamic>.from(item)))
          .toList();
      projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      return projects;
    } on FormatException {
      final backup = File('${file.path}.broken-${DateTime.now().millisecondsSinceEpoch}');
      await file.rename(backup.path);
      return [];
    }
  }

  Future<void> saveProjects(List<WritingProject> projects) async {
    final file = await _projectFile();
    final data = projects.map((project) => project.toJson()).toList();
    const encoder = JsonEncoder.withIndent('  ');
    await file.writeAsString(encoder.convert(data), flush: true);
  }

  Future<void> upsertProject(WritingProject project) async {
    final projects = await loadProjects();
    final index = projects.indexWhere((item) => item.id == project.id);
    final next = project.copyWith(updatedAt: DateTime.now());

    if (index == -1) {
      projects.add(next);
    } else {
      projects[index] = next;
    }
    await saveProjects(projects);
  }

  Future<void> deleteProject(String id) async {
    final projects = await loadProjects();
    projects.removeWhere((project) => project.id == id);
    await saveProjects(projects);
  }

  Future<String> exportProject(
    WritingProject project, {
    required ExportFormat format,
  }) async {
    final dir = await _exportDir();
    final extension = format == ExportFormat.markdown ? 'md' : 'txt';
    final filename = '${_safeName(project.title)}-${_dateStamp()}.$extension';
    final file = File('${dir.path}${Platform.pathSeparator}$filename');

    final content = switch (format) {
      ExportFormat.markdown => _toMarkdown(project),
      ExportFormat.txt => _toPlainText(project),
    };

    await file.writeAsString(content, flush: true);
    return file.path;
  }

  Future<Directory> _baseDir() async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory('${root.path}${Platform.pathSeparator}inkflow_writer');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  Future<Directory> _exportDir() async {
    final base = await _baseDir();
    final dir = Directory('${base.path}${Platform.pathSeparator}exports');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  Future<File> _projectFile() async {
    final dir = await _baseDir();
    return File('${dir.path}${Platform.pathSeparator}projects.json');
  }

  String _toPlainText(WritingProject project) {
    final buffer = StringBuffer()
      ..writeln(project.title)
      ..writeln(project.genre)
      ..writeln()
      ..writeln(project.description)
      ..writeln('\n====================\n');

    for (final chapter in project.chapters) {
      buffer
        ..writeln(chapter.title)
        ..writeln(List.filled(chapter.title.length.clamp(1, 80), '-').join())
        ..writeln()
        ..writeln(chapter.content.trim())
        ..writeln('\n');
    }

    if (project.notes.isNotEmpty) {
      buffer.writeln('\n====================\n设定与备忘\n');
      for (final note in project.notes) {
        buffer
          ..writeln('[${note.tag}] ${note.title}')
          ..writeln(note.body.trim())
          ..writeln();
      }
    }
    return buffer.toString();
  }

  String _toMarkdown(WritingProject project) {
    final buffer = StringBuffer()
      ..writeln('# ${project.title}')
      ..writeln()
      ..writeln('> 类型：${project.genre}')
      ..writeln()
      ..writeln(project.description)
      ..writeln();

    for (final chapter in project.chapters) {
      buffer
        ..writeln('## ${chapter.title}')
        ..writeln()
        ..writeln(chapter.content.trim())
        ..writeln();
    }

    if (project.notes.isNotEmpty) {
      buffer.writeln('---\n\n## 设定与备忘\n');
      for (final note in project.notes) {
        buffer
          ..writeln('### ${note.title}')
          ..writeln()
          ..writeln('- 标签：${note.tag}')
          ..writeln()
          ..writeln(note.body.trim())
          ..writeln();
      }
    }
    return buffer.toString();
  }

  String _safeName(String value) {
    final safe = value.trim().replaceAll(RegExp(r'[\\/:*?"<>|\s]+'), '_');
    return safe.isEmpty ? 'untitled' : safe;
  }

  String _dateStamp() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${now.year}${two(now.month)}${two(now.day)}-${two(now.hour)}${two(now.minute)}';
  }
}
