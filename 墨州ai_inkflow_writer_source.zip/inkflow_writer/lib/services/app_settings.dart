import 'package:flutter/material.dart';

class AppSettings extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system;
  double _editorFontSize = 18;

  ThemeMode get themeMode => _themeMode;
  double get editorFontSize => _editorFontSize;

  void setThemeMode(ThemeMode mode) {
    if (_themeMode == mode) return;
    _themeMode = mode;
    notifyListeners();
  }

  void setEditorFontSize(double size) {
    final nextSize = size.clamp(14, 28).toDouble();
    if (_editorFontSize == nextSize) return;
    _editorFontSize = nextSize;
    notifyListeners();
  }
}
