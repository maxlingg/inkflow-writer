# 把源码变成可运行 Flutter Android 工程

这个包重点提供原创业务源码。为了避免夹带过时的 Android/iOS 模板文件，平台目录建议用你本机安装的 Flutter 版本生成。

## 推荐方式

```bash
# 1. 先创建一个全新的 Flutter 壳工程
flutter create inkflow_writer_app --org com.yourname.inkflow --platforms=android,ios

# 2. 把本源码包里的 pubspec.yaml、analysis_options.yaml、lib/ 复制覆盖到新工程
cp -R inkflow_writer/lib inkflow_writer_app/
cp inkflow_writer/pubspec.yaml inkflow_writer_app/pubspec.yaml
cp inkflow_writer/analysis_options.yaml inkflow_writer_app/analysis_options.yaml

# 3. 安装依赖并运行
cd inkflow_writer_app
flutter pub get
flutter run
```

## 只做 Android

```bash
flutter create inkflow_writer_app --org com.yourname.inkflow --platforms=android
```

然后执行同样的复制、`flutter pub get`、`flutter run`。

## 生成 APK

```bash
flutter build apk --release
```

生成文件通常在：

```text
build/app/outputs/flutter-apk/app-release.apk
```
