# 墨舟写作 InkFlow Writer

一个原创 UI + 原创代码的本地优先写作工具 MVP。它借鉴“写作工作台/章节管理/导出/备忘录”这类通用产品形态，但不复制任何第三方应用的源码、图标、文案或素材。

## 已实现

- 作品列表：新建、查看、删除作品
- 章节管理：新建、重命名、删除章节
- 写作编辑器：标题编辑、正文编辑、自动保存、字数/字符统计
- 设定备忘录：人物、世界观、伏笔等笔记管理
- 导出：导出 TXT / Markdown，并通过系统分享面板发送文件
- 设置：深色/浅色/跟随系统，编辑器字号
- 灵感助手：本地提示卡片，后续可替换为 AI 接口

## 运行方式

本包重点提供业务源码。建议先用你本机 Flutter 版本生成平台目录，再复制本包的 `lib/` 与 `pubspec.yaml`。完整步骤见 `BOOTSTRAP.md`。

```bash
flutter create inkflow_writer_app --org com.yourname.inkflow --platforms=android
cp -R inkflow_writer/lib inkflow_writer_app/
cp inkflow_writer/pubspec.yaml inkflow_writer_app/pubspec.yaml
cd inkflow_writer_app
flutter pub get
flutter run
```

如果你已经在本目录生成好了 Android/iOS 平台目录，也可以直接：

```bash
flutter pub get
flutter run
```

## 生成 Android 安装包

```bash
flutter build apk --release
```

生成文件通常在：

```text
build/app/outputs/flutter-apk/app-release.apk
```

## 项目结构

```text
lib/
  main.dart
  models/writing_project.dart
  services/app_settings.dart
  services/storage_service.dart
  screens/home_screen.dart
  screens/project_screen.dart
  screens/editor_screen.dart
  screens/notes_screen.dart
  screens/settings_screen.dart
  utils/text_stats.dart
  widgets/empty_state.dart
```

## 后续建议

1. 接入云同步：Firebase、Supabase 或自建后端。
2. 接入 AI：把 `ProjectScreen` 里的灵感助手替换为 OpenAI/通义/智谱等接口。
3. 增加 DOCX 导出：可在服务层新增 `docx_export_service.dart`。
4. 增加版本历史：保存每次编辑快照，支持回滚。
5. 增加写作目标：每日字数目标、连续写作天数、统计图。
