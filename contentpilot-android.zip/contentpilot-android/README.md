# ContentPilot Android

ContentPilot 是一个安卓端内容运营自动化 MVP。当前版本围绕：热点监测、选题推荐、竞品分析、AI 内容生成、质量优化、多平台适配草稿、内容库管理，做成完整可测试 APK 原型。

## 当前版本重点更新

1. **新增 AI 设置与接入能力**
   - 新增 AI 设置页，可配置接口地址、API Key、模型、温度和系统提示词。
   - 支持接口地址自动补全：填写 `https://api-inference.modelscope.cn/v1` 会自动转成 `/v1/chat/completions`。
   - 支持从当前接口自动请求 `/models`，弹出可用模型列表并一键选择；不支持模型列表的服务仍可手动填写模型 ID。
   - 支持 OpenAI 兼容 Chat Completions 格式、Claude / Anthropic Messages API，也可填写自有后端代理地址。
   - 生成内容时优先调用 AI，失败时自动回退本地规则引擎。
   - 标题、开头、标签的局部重新生成支持 AI 改写。
   - 提供连接测试与清除 API Key 操作。

2. **主页新增当下热点卡片**
   - 自动展示当下热点，无需输入。
   - 展示热度分数、来源、更新时间、热度趋势、内容切口。
   - 支持“刷新热点”和“用热点开始配置”。
   - 当前为原型内置热点源，后续可接入百度热搜、抖音热点、小红书趋势、B站话题等真实数据源。

3. **生成结果拆成可编辑模块**
   - 标题
   - 开头钩子
   - 正文
   - CTA
   - 标签
   - 多平台适配草稿

4. **新增内容库 / 历史记录页**
   - 每次生成后自动保存。
   - 支持加载历史方案、分享历史方案、清空内容库。
   - 支持手动保存编辑后的草稿。

5. **多平台发布改为“适配草稿 + 人工确认发布”**
   - 输出公众号、小红书、抖音/视频号、B站版本。
   - 发布前提醒人工确认事实、敏感词、素材版权、链接和账号规则。

6. **新增局部重新生成能力**
   - 重新生成标题
   - 重新生成开头
   - 重新生成标签

## 页面结构

- **主页**：当下热点 + 核心功能卡片
- **生成配置**：产品/账号定位、目标人群、竞品、内容语气、热点种子词
- **自动化流程**：流程进度、可编辑草稿、AI/本地局部重写、复制、分享、保存
- **内容库**：历史内容方案管理
- **AI 设置**：接口地址自动补全、API Key、获取可用模型、模型选择、温度、系统提示词、连接测试

## AI 接入说明

测试阶段可以在 App 的 **AI** 页直接填写接口信息。正式产品不要把固定 API Key 写入 APK，建议改为：

```text
Android App → 你的后端 API → AI 模型服务 → 返回生成结果
```

当前客户端支持接口地址自动补全，并在 AI 设置页提供“获取可用模型”按钮：

- 生成/测试时，OpenAI 兼容接口会把 `https://api-inference.modelscope.cn/v1` 自动补全为 `https://api-inference.modelscope.cn/v1/chat/completions`。
- 获取模型列表时，会把 `https://api-inference.modelscope.cn/v1` 或 `.../v1/chat/completions` 自动转为 `.../v1/models`。
- Claude 模式可填写 `https://api.anthropic.com/v1`，保存后会自动补全为 `https://api.anthropic.com/v1/messages`。
- 如果服务不支持 `/models`，可以继续手动填写模型 ID。

当前客户端支持两类接口：

### OpenAI 兼容模式

- 默认接口：`https://api.openai.com/v1/chat/completions`
- 默认模型：`gpt-4o-mini`
- 鉴权：`Authorization: Bearer <API Key>`
- 请求格式：`model`、`messages`、`temperature`、`max_tokens`
- 响应读取：`choices[0].message.content`

### Claude 模式

- 默认接口：`https://api.anthropic.com/v1/messages`
- 默认模型：`claude-sonnet-4-6`
- 鉴权：`x-api-key: <API Key>`
- 固定版本头：`anthropic-version: 2023-06-01`
- 请求格式：`model`、`system`、`messages`、`temperature`、`max_tokens`
- 响应读取：`content[].text`

## GitHub Actions 打包 APK

如果仓库里只上传了 `contentpilot-android.zip`，请使用你之前添加的 `build-apk-from-zip.yml` 工作流。

如果仓库里是解压后的完整项目，可直接运行：

```bash
./scripts/build_local.sh
```

或在 GitHub Actions 中运行 Android 构建。

## 测试 APK

打包完成后下载：

- `app-debug.apk`：用于手机测试安装
- `app-release-unsigned.apk`：未签名 Release 包，正式分发前需要签名

## 后续真实产品化建议

- 接入真实热点数据源 API。
- 增加账号授权、草稿箱、定时发布和发布状态回传。
- 增加效果复盘：曝光、点赞、收藏、评论、转化、最佳发布时间。
- 增加违规词和敏感词云端更新。
