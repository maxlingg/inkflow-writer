# Local-only MVP; add API/client keep rules here when integrating SDKs.
