package com.example.contentpilot;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PipelineResult {
    public final String product;
    public final String audience;
    public final String competitors;
    public final String tone;
    public final List<TrendSignal> trends;
    public final List<String> topicRecommendations;
    public final String competitorAnalysis;
    public final DraftSections draftSections;
    public final String generatedDraft;
    public final String qualityReport;
    public final List<PlatformVariant> platformVariants;
    public final int qualityScore;
    public final String createdAt;

    public PipelineResult(
            String product,
            String audience,
            String competitors,
            String tone,
            List<TrendSignal> trends,
            List<String> topicRecommendations,
            String competitorAnalysis,
            DraftSections draftSections,
            String generatedDraft,
            String qualityReport,
            List<PlatformVariant> platformVariants,
            int qualityScore
    ) {
        this.product = product;
        this.audience = audience;
        this.competitors = competitors;
        this.tone = tone;
        this.trends = trends;
        this.topicRecommendations = topicRecommendations;
        this.competitorAnalysis = competitorAnalysis;
        this.draftSections = draftSections;
        this.generatedDraft = generatedDraft;
        this.qualityReport = qualityReport;
        this.platformVariants = platformVariants;
        this.qualityScore = qualityScore;
        this.createdAt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(new Date());
    }


    public PipelineResult copyWithAiDraft(AiDraftResponse aiDraft, String aiNote) {
        String note = aiNote == null || aiNote.trim().length() == 0 ? "AI 接入：已使用 AI 生成草稿。" : aiNote.trim();
        String newQuality = aiDraft.qualityReport == null || aiDraft.qualityReport.trim().length() == 0
                ? qualityReport + "\n- " + note + "\n"
                : aiDraft.qualityReport.trim() + "\n- " + note + "\n";
        return new PipelineResult(
                product,
                audience,
                competitors,
                tone,
                trends,
                topicRecommendations,
                competitorAnalysis,
                aiDraft.sections,
                aiDraft.sections.toPlainText(),
                newQuality,
                platformVariants,
                Math.min(99, qualityScore + 3)
        );
    }

    public PipelineResult copyWithQualityNote(String note) {
        String safeNote = note == null ? "" : note.trim();
        String newQuality = safeNote.length() == 0 ? qualityReport : qualityReport + "\n- " + safeNote + "\n";
        return new PipelineResult(
                product,
                audience,
                competitors,
                tone,
                trends,
                topicRecommendations,
                competitorAnalysis,
                draftSections,
                generatedDraft,
                newQuality,
                platformVariants,
                qualityScore
        );
    }

    public String toMarkdown() {
        return toMarkdownWithSections(
                draftSections.title,
                draftSections.hook,
                draftSections.body,
                draftSections.cta,
                draftSections.tags,
                draftSections.platformDrafts
        );
    }

    public String toMarkdownWithSections(String title, String hook, String body, String cta, String tags, String platformDrafts) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ContentPilot 自动化内容方案\n\n");
        sb.append("生成时间：").append(createdAt).append("\n");
        sb.append("产品/账号：").append(product).append("\n");
        sb.append("目标人群：").append(audience).append("\n");
        sb.append("竞品：").append(competitors).append("\n");
        sb.append("语气：").append(tone).append("\n");
        sb.append("发布模式：多平台适配草稿，人工确认后发布\n\n");

        sb.append("## 1. 热点监测\n");
        for (TrendSignal trend : trends) {
            sb.append("- 【").append(trend.heat).append("】")
                    .append(trend.keyword)
                    .append("｜来源：").append(trend.source)
                    .append("｜趋势：").append(trend.direction)
                    .append("｜更新：").append(trend.updatedAt)
                    .append("\n  洞察：")
                    .append(trend.insight).append("\n  切入：")
                    .append(trend.contentAngle).append("\n");
        }

        sb.append("\n## 2. 选题推荐\n");
        for (int i = 0; i < topicRecommendations.size(); i++) {
            sb.append(i + 1).append(". ").append(topicRecommendations.get(i)).append("\n");
        }

        sb.append("\n## 3. 竞品分析\n");
        sb.append(competitorAnalysis).append("\n");

        sb.append("\n## 4. 可编辑内容草稿\n");
        sb.append("标题：").append(title).append("\n\n");
        sb.append("开头钩子：").append(hook).append("\n\n");
        sb.append("正文：\n").append(body).append("\n\n");
        sb.append("CTA：").append(cta).append("\n\n");
        sb.append("标签：").append(tags).append("\n");

        sb.append("\n## 5. 质量优化\n");
        sb.append("综合评分：").append(qualityScore).append("/100\n");
        sb.append(qualityReport).append("\n");

        sb.append("\n## 6. 多平台适配草稿\n");
        sb.append(platformDrafts).append("\n\n");
        sb.append("发布检查：以上内容为平台草稿，请人工确认事实、敏感词、素材版权、链接和账号授权后再发布。\n");
        return sb.toString();
    }
}
