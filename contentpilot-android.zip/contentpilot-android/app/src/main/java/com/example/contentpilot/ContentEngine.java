package com.example.contentpilot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.Date;

public class ContentEngine {
    private static final List<String> DEFAULT_SIGNALS = Arrays.asList(
            "AI效率", "低成本增长", "私域运营", "情绪价值", "年度复盘", "爆款拆解", "新手避坑", "真实案例"
    );

    private static final List<String> HOT_POOL = Arrays.asList(
            "AI视频生成", "DeepSeek工作流", "小红书电商", "短剧出海", "低成本获客", "企业微信私域",
            "知识付费复盘", "内容矩阵", "本地生活种草", "直播切片", "AIGC降本", "老板IP"
    );

    private static final List<String> HOT_SOURCES = Arrays.asList(
            "百度热搜模拟源", "小红书趋势模拟源", "抖音热点模拟源", "B站话题模拟源", "微信指数模拟源"
    );

    public PipelineResult run(String product, String audience, String competitors, String tone, String seedTopics) {
        String cleanProduct = nonBlank(product, "AI 内容运营助手");
        String cleanAudience = nonBlank(audience, "小微企业主、内容运营、独立创作者");
        String cleanCompetitors = nonBlank(competitors, "同行账号、行业大号、同类 SaaS 工具");
        String cleanTone = nonBlank(tone, "专业、克制、有执行感");
        String cleanSeeds = nonBlank(seedTopics, "AI效率, 低成本获客, 多平台适配, 内容自动化");

        List<TrendSignal> trends = monitorTrends(cleanSeeds, cleanAudience);
        List<String> topics = recommendTopics(cleanProduct, cleanAudience, trends);
        String competitorReport = analyzeCompetitors(cleanProduct, cleanAudience, cleanCompetitors);
        List<PlatformVariant> variants = adaptForPlatforms(cleanProduct, cleanAudience, cleanTone, trends);
        DraftSections sections = generateDraftSections(cleanProduct, cleanAudience, cleanTone, trends, topics, competitorReport, variants);
        String draft = sections.toPlainText();
        int score = qualityScore(draft, topics, trends);
        String quality = optimizeQuality(draft, score);

        return new PipelineResult(
                cleanProduct,
                cleanAudience,
                cleanCompetitors,
                cleanTone,
                trends,
                topics,
                competitorReport,
                sections,
                draft,
                quality,
                variants,
                score
        );
    }

    public List<TrendSignal> getTodayHotTrends() {
        StringBuilder seeds = new StringBuilder();
        for (String item : HOT_POOL) {
            if (seeds.length() > 0) seeds.append(", ");
            seeds.append(item);
        }
        return monitorTrends(seeds.toString(), "泛内容运营人群");
    }

    public String rewriteTitle(PipelineResult result, int round) {
        if (result == null || result.trends.size() == 0) return "用自动化流程提升内容生产效率";
        String trend = result.trends.get(round % result.trends.size()).keyword;
        String[] patterns = {
                "别再手动追热点：用%s把「%s」做成内容流水线",
                "从热点到草稿：%s如何抓住「%s」内容机会",
                "我用%s，把「%s」变成可发布的多平台草稿",
                "%s实战：围绕「%s」生成选题、文案和平台版本"
        };
        return String.format(Locale.CHINA, patterns[round % patterns.length], result.product, trend);
    }

    public String rewriteHook(PipelineResult result, int round) {
        if (result == null || result.trends.size() == 0) return "热点每天都在变，但真正拖慢团队的，往往是从选题到发布的中间流程。";
        String trend = result.trends.get(round % result.trends.size()).keyword;
        String[] hooks = {
                "热点不是缺少，而是太多。真正的问题是：看到「%s」之后，团队能不能在当天产出可发布草稿。",
                "很多内容团队追「%s」只停留在收藏热搜，但没有把它变成标题、正文、标签和发布检查。",
                "如果你也经常看到「%s」爆了，却不知道怎么结合自己的产品，这套流程可以直接复用。",
                "内容运营最怕的不是没有灵感，而是热点、竞品、草稿和平台规则全部割裂。"
        };
        return String.format(Locale.CHINA, hooks[round % hooks.length], trend);
    }

    public String rewriteTags(PipelineResult result, int round) {
        if (result == null || result.trends.size() == 0) return "#内容运营 #AI效率 #自动化 #多平台适配";
        String trend = result.trends.get(round % result.trends.size()).keyword.replace(" ", "");
        String[] tags = {
                "#" + trend + " #内容运营 #AI效率 #自动化SOP #多平台适配",
                "#" + trend + " #运营工具 #选题方法 #草稿生成 #发布检查",
                "#" + trend + " #小红书运营 #短视频运营 #公众号运营 #内容增长",
                "#" + trend + " #AIGC #低成本获客 #内容矩阵 #效率工具"
        };
        return tags[round % tags.length];
    }

    private List<TrendSignal> monitorTrends(String seedTopics, String audience) {
        Set<String> keywords = new LinkedHashSet<>();
        for (String item : seedTopics.split("[,，;；\\n]")) {
            String cleaned = item.trim();
            if (cleaned.length() > 0) keywords.add(cleaned);
        }
        keywords.addAll(DEFAULT_SIGNALS);

        List<TrendSignal> trends = new ArrayList<>();
        int dayBoost = Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % 17;
        String updatedAt = new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
        int index = 0;
        for (String keyword : keywords) {
            int heat = 68 + Math.abs((keyword.hashCode() + dayBoost + index * 13) % 30);
            String insight;
            String angle;
            if (keyword.contains("AI") || keyword.toLowerCase(Locale.ROOT).contains("agent") || keyword.toLowerCase(Locale.ROOT).contains("deepseek")) {
                insight = "用户关注从“能不能用”转向“怎样落地、省时、降本”。";
                angle = "用真实任务链路证明节省的人力和时间。";
            } else if (keyword.contains("获客") || keyword.contains("增长") || keyword.contains("私域") || keyword.contains("电商")) {
                insight = "增长焦虑仍强，受众更愿意看可复制的渠道组合。";
                angle = "展示从流量到线索再到转化的闭环。";
            } else if (keyword.contains("避坑") || keyword.contains("拆解") || keyword.contains("案例") || keyword.contains("复盘")) {
                insight = "案例型内容降低理解成本，天然适合收藏与转发。";
                angle = "以“错误做法 vs 正确做法”组织结构。";
            } else {
                insight = "话题具备持续讨论空间，适合做系列化内容。";
                angle = "用清单、模板和行动步骤提升完播与收藏。";
            }
            String source = HOT_SOURCES.get(Math.abs(keyword.hashCode() + index) % HOT_SOURCES.size());
            String direction = heat >= 90 ? "快速上升" : heat >= 82 ? "上升" : heat >= 76 ? "持平" : "小幅波动";
            trends.add(new TrendSignal(keyword, Math.min(99, heat), insight + " 目标人群：" + audience + "。", angle, source, direction, updatedAt));
            index++;
            if (trends.size() == 10) break;
        }
        Collections.sort(trends, new Comparator<TrendSignal>() {
            @Override
            public int compare(TrendSignal a, TrendSignal b) {
                return b.heat - a.heat;
            }
        });
        if (trends.size() > 8) {
            return new ArrayList<>(trends.subList(0, 8));
        }
        return trends;
    }

    private List<String> recommendTopics(String product, String audience, List<TrendSignal> trends) {
        List<String> topics = new ArrayList<>();
        if (trends.size() > 0) {
            topics.add("7天实测：用" + product + "把「" + trends.get(0).keyword + "」做成可复用内容流水线");
        }
        if (trends.size() > 1) {
            topics.add("别再盲目追热点：面向" + audience + "的" + trends.get(1).keyword + "选题筛选公式");
        }
        if (trends.size() > 2) {
            topics.add("我拆了3个竞品账号，发现" + product + "最适合切入的差异化内容角度");
        }
        topics.add("从选题到确认发布：一条内容如何适配公众号、小红书、抖音和B站");
        topics.add("收藏级模板：热点监测、标题生成、质量评分、发布检查一次完成");
        return topics;
    }

    private String analyzeCompetitors(String product, String audience, String competitors) {
        StringBuilder sb = new StringBuilder();
        sb.append("竞品对象：").append(competitors).append("\n");
        sb.append("- 内容强项：通常擅长单点爆款、强钩子标题和案例包装。\n");
        sb.append("- 内容弱项：流程割裂，热点、选题、文案、发布适配之间缺少可追踪闭环。\n");
        sb.append("- 可占位机会：强调“自动化生成草稿 + 人工确认发布”，让").append(audience).append("看到稳定产出，同时保留审核安全。\n");
        sb.append("- 差异化主张：").append(product).append("不只生成文案，还输出趋势依据、竞品切口、质量评分和多平台版本。\n");
        sb.append("- 风险提示：避免夸大 AI 自动发布能力，涉及平台 API、账号授权、审核机制时要明确人工确认环节。\n");
        return sb.toString();
    }

    private DraftSections generateDraftSections(String product, String audience, String tone, List<TrendSignal> trends, List<String> topics, String competitorReport, List<PlatformVariant> variants) {
        TrendSignal primary = trends.get(0);
        String mainTopic = topics.get(0);
        String hook = "热点每天都在变，选题会开很多会，竞品也一直在更新，但真正能发布的内容经常卡在最后一步。";
        StringBuilder body = new StringBuilder();
        body.append("核心观点：对").append(audience).append("来说，内容增长不应该只靠灵感，而应该被拆成一条可执行的自动化流水线。\n\n");
        body.append("正文结构：\n");
        body.append("1. 热点监测：围绕“").append(primary.keyword).append("”持续收集信号，判断来源、热度、趋势和内容切口。\n");
        body.append("2. 选题推荐：把热点转换成可发布标题，并按收藏率、讨论度、转化潜力排序。\n");
        body.append("3. 竞品分析：不是照搬竞品，而是找出它们没讲透、没闭环、没模板化的空白。\n");
        body.append("4. 内容生成：拆成标题、开头钩子、正文、CTA、标签，方便逐段编辑。\n");
        body.append("5. 质量优化：检查钩子、信息密度、可信度、行动指令和平台风险词。\n");
        body.append("6. 多平台适配草稿：按平台节奏重写标题、正文、标签和发布检查清单，人工确认后再发布。\n\n");
        body.append("示例卖点：用").append(product).append("，把“发现热点 → 生成选题 → 形成内容 → 质量评分 → 多平台草稿”压缩成一个连续动作。\n\n");
        body.append("语气要求：").append(tone).append("。\n\n");
        body.append("竞品启发摘要：").append(competitorReport.split("\\n")[1]);

        String cta = "评论区留下你的行业，我可以用同一套流程帮你生成一组可测试选题。";
        String tags = "#" + primary.keyword.replace(" ", "") + " #内容运营 #AI效率 #自动化SOP #多平台适配";
        StringBuilder platformDrafts = new StringBuilder();
        for (PlatformVariant variant : variants) {
            platformDrafts.append("【").append(variant.platform).append("】\n");
            platformDrafts.append("标题：").append(variant.title).append("\n");
            platformDrafts.append("正文：").append(variant.body).append("\n");
            platformDrafts.append("标签：").append(join(variant.tags, " ")).append("\n");
            platformDrafts.append("发布前检查：").append(join(variant.checklist, "；")).append("\n\n");
        }
        return new DraftSections(mainTopic, hook, body.toString(), cta, tags, platformDrafts.toString().trim());
    }

    private int qualityScore(String draft, List<String> topics, List<TrendSignal> trends) {
        int score = 72;
        if (draft.contains("CTA") || draft.contains("评论区")) score += 6;
        if (draft.length() > 450) score += 7;
        if (topics.size() >= 5) score += 5;
        if (trends.size() >= 6) score += 5;
        if (draft.contains("风险") || draft.contains("人工确认")) score += 3;
        return Math.min(98, score);
    }

    private String optimizeQuality(String draft, int score) {
        StringBuilder sb = new StringBuilder();
        sb.append("- 钩子强度：高。开头直接命中“热点多、发布慢”的痛点。\n");
        sb.append("- 信息密度：中高。建议正式发布时加入1个真实数据或客户案例。\n");
        sb.append("- 可信度：中高。已避免绝对化承诺，平台授权和审核需保留人工确认。\n");
        sb.append("- 转化路径：清晰。评论 CTA 可继续补充“领取模板/预约演示”。\n");
        sb.append("- 平台风险：注意避免“保证爆款、全自动无人值守发布”等表述。\n");
        if (score < 88) {
            sb.append("- 优化建议：增加案例、截图、对比表和明确时间收益，如“每条内容节省30分钟”。\n");
        } else {
            sb.append("- 优化建议：当前版本可进入小流量测试，观察收藏率、完播率和私信转化。\n");
        }
        return sb.toString();
    }

    private List<PlatformVariant> adaptForPlatforms(String product, String audience, String tone, List<TrendSignal> trends) {
        String firstTrend = trends.get(0).keyword;
        List<PlatformVariant> variants = new ArrayList<>();
        variants.add(new PlatformVariant(
                "微信公众号",
                "内容团队如何用一套自动化流程跑完热点、选题、生成与审核",
                "适合长文深度讲解。先交代行业痛点，再展示" + product + "的六步流程，最后给出模板领取或演示预约入口。",
                Arrays.asList("#内容运营", "#AI效率", "#自动化"),
                Arrays.asList("标题不超过28字", "首屏放流程图", "文末放可转化 CTA", "人工确认链接和二维码")
        ));
        variants.add(new PlatformVariant(
                "小红书",
                "我把追热点做成了自动化SOP，运营终于不熬夜了",
                "封面写“热点→选题→文案→审核”。正文用清单体：痛点、工具、步骤、避坑、模板。语气保持" + nonBlank(tone, "专业") + "，突出收藏价值。",
                Arrays.asList("#运营工具", "#小红书运营", "#AI工具", "#内容SOP"),
                Arrays.asList("封面强对比", "前3行给结果", "结尾引导收藏评论", "确认平台敏感词")
        ));
        variants.add(new PlatformVariant(
                "抖音/视频号",
                "别再手动追热点了，内容自动化可以这样做",
                "15秒结构：3秒痛点：“热点来了，内容还没写完？”；8秒演示六步流水线；4秒 CTA：“评论行业，生成你的选题”。",
                Arrays.asList("#AI内容", "#运营效率", "#短视频运营"),
                Arrays.asList("口播控制在45秒内", "字幕突出数字", "结尾保留互动问题", "发布前人工预览")
        ));
        variants.add(new PlatformVariant(
                "B站",
                "我做了一个内容自动化系统：从热点监测到多平台草稿",
                "适合做8-12分钟演示。章节：为什么追" + firstTrend + "低效、系统架构、真实生成过程、竞品分析、质量评分、多平台改写。",
                Arrays.asList("AI", "内容运营", "效率工具", "产品设计"),
                Arrays.asList("简介放章节目录", "评论区置顶模板", "封面突出自动化链路", "确认素材版权")
        ));
        return variants;
    }

    private static String join(List<String> list, String separator) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(separator);
            sb.append(list.get(i));
        }
        return sb.toString();
    }

    private String nonBlank(String value, String fallback) {
        if (value == null) return fallback;
        String trimmed = value.trim();
        return trimmed.length() == 0 ? fallback : trimmed;
    }
}
