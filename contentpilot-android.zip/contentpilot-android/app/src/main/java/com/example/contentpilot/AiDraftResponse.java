package com.example.contentpilot;

public class AiDraftResponse {
    public final DraftSections sections;
    public final String qualityReport;

    public AiDraftResponse(DraftSections sections, String qualityReport) {
        this.sections = sections;
        this.qualityReport = qualityReport;
    }
}
