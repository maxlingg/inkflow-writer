package com.example.contentpilot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class AiClient {
    private static final int CONNECT_TIMEOUT_MS = 20000;
    private static final int READ_TIMEOUT_MS = 60000;

    public AiDraftResponse generateDraft(AiConfig config, PipelineResult baseResult) throws Exception {
        String prompt = buildDraftPrompt(baseResult);
        String content = callAiModel(config, prompt, 2600);
        return parseDraftResponse(content, baseResult);
    }

    public String rewriteField(AiConfig config, PipelineResult baseResult, String fieldName, String currentMarkdown) throws Exception {
        String prompt = "请基于下面的内容方案，只重新生成指定字段。\n"
                + "指定字段：" + fieldName + "\n"
                + "要求：只输出新字段正文，不要解释，不要 Markdown 代码块。\n\n"
                + currentMarkdown;
        String content = callAiModel(config, prompt, 900).trim();
        return stripCodeFence(content);
    }

    public List<String> fetchAvailableModels(AiConfig config) throws Exception {
        if (config == null) {
            throw new IllegalArgumentException("AI 配置为空");
        }
        if (config.endpoint.length() == 0 || config.apiKey.length() == 0) {
            throw new IllegalArgumentException("请先填写接口地址和 API Key");
        }
        URL url = new URL(resolveModelsEndpoint(config.endpoint));
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestProperty("Accept", "application/json");
        if (config.isClaude()) {
            connection.setRequestProperty("x-api-key", config.apiKey);
            connection.setRequestProperty("anthropic-version", "2023-06-01");
        } else {
            connection.setRequestProperty("Authorization", "Bearer " + config.apiKey);
        }

        String response = getJson(connection);
        List<String> models = parseModelListResponse(response);
        if (models.isEmpty()) {
            throw new RuntimeException("模型列表为空，请确认当前接口是否支持 /models");
        }
        return models;
    }

    public String testConnection(AiConfig config) throws Exception {
        String content = callAiModel(config, "连接测试：请只回复 OK。", 32).trim();
        if (content.length() == 0) return "AI 接口已响应，但返回为空";
        return "AI 接口连接成功，返回：" + content;
    }

    private String callAiModel(AiConfig config, String userPrompt, int maxTokens) throws Exception {
        if (config == null || !config.hasRequiredFields()) {
            throw new IllegalArgumentException("AI 配置不完整");
        }
        if (config.isClaude()) {
            return callClaudeMessages(config, userPrompt, maxTokens);
        }
        return callOpenAiCompatible(config, userPrompt, maxTokens);
    }

    private String callOpenAiCompatible(AiConfig config, String userPrompt, int maxTokens) throws Exception {
        URL url = new URL(config.endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + config.apiKey);

        JSONObject payload = new JSONObject();
        payload.put("model", config.model);
        payload.put("temperature", config.temperature);
        payload.put("max_tokens", maxTokens);
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", config.systemPrompt));
        messages.put(new JSONObject().put("role", "user").put("content", userPrompt));
        payload.put("messages", messages);

        String response = postJson(connection, payload);
        JSONObject json = new JSONObject(response);
        JSONArray choices = json.optJSONArray("choices");
        if (choices == null || choices.length() == 0) {
            throw new RuntimeException("OpenAI 兼容响应缺少 choices 字段");
        }
        JSONObject first = choices.getJSONObject(0);
        JSONObject message = first.optJSONObject("message");
        if (message == null) {
            throw new RuntimeException("OpenAI 兼容响应缺少 message 字段");
        }
        String content = message.optString("content", "");
        if (content.length() == 0) {
            throw new RuntimeException("OpenAI 兼容响应内容为空");
        }
        return content;
    }

    private String callClaudeMessages(AiConfig config, String userPrompt, int maxTokens) throws Exception {
        URL url = new URL(config.endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("x-api-key", config.apiKey);
        connection.setRequestProperty("anthropic-version", "2023-06-01");

        JSONObject payload = new JSONObject();
        payload.put("model", config.model);
        payload.put("temperature", config.temperature);
        payload.put("max_tokens", maxTokens);
        payload.put("system", config.systemPrompt);
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "user").put("content", userPrompt));
        payload.put("messages", messages);

        String response = postJson(connection, payload);
        JSONObject json = new JSONObject(response);
        JSONArray contentBlocks = json.optJSONArray("content");
        if (contentBlocks == null || contentBlocks.length() == 0) {
            throw new RuntimeException("Claude 响应缺少 content 字段");
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < contentBlocks.length(); i++) {
            Object block = contentBlocks.opt(i);
            if (block instanceof JSONObject) {
                JSONObject obj = (JSONObject) block;
                String text = obj.optString("text", "");
                if (text.length() > 0) {
                    if (sb.length() > 0) sb.append('\n');
                    sb.append(text);
                }
            } else if (block != null) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(String.valueOf(block));
            }
        }
        String content = sb.toString().trim();
        if (content.length() == 0) {
            throw new RuntimeException("Claude 响应内容为空");
        }
        return content;
    }

    private String postJson(HttpURLConnection connection, JSONObject payload) throws Exception {
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        OutputStream outputStream = connection.getOutputStream();
        outputStream.write(body);
        outputStream.flush();
        outputStream.close();

        int statusCode = connection.getResponseCode();
        InputStream inputStream = statusCode >= 200 && statusCode < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        String response = readAll(inputStream);
        connection.disconnect();

        if (statusCode < 200 || statusCode >= 300) {
            throw new RuntimeException("HTTP " + statusCode + "：" + readableApiError(response));
        }
        return response;
    }

    private String getJson(HttpURLConnection connection) throws Exception {
        int statusCode = connection.getResponseCode();
        InputStream inputStream = statusCode >= 200 && statusCode < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        String response = readAll(inputStream);
        connection.disconnect();

        if (statusCode < 200 || statusCode >= 300) {
            throw new RuntimeException("HTTP " + statusCode + "：" + readableApiError(response));
        }
        return response;
    }

    private String resolveModelsEndpoint(String endpoint) {
        String cleaned = endpoint == null ? "" : endpoint.trim();
        while (cleaned.endsWith("/")) {
            cleaned = cleaned.substring(0, cleaned.length() - 1);
        }
        String lower = cleaned.toLowerCase();
        if (lower.endsWith("/chat/completions")) {
            return cleaned.substring(0, cleaned.length() - "/chat/completions".length()) + "/models";
        }
        if (lower.endsWith("/messages")) {
            return cleaned.substring(0, cleaned.length() - "/messages".length()) + "/models";
        }
        if (lower.endsWith("/completions")) {
            return cleaned.substring(0, cleaned.length() - "/completions".length()) + "/models";
        }
        int v1Index = lower.indexOf("/v1/");
        if (v1Index >= 0) {
            return cleaned.substring(0, v1Index + 3) + "/models";
        }
        if (lower.endsWith("/v1")) {
            return cleaned + "/models";
        }
        return cleaned + "/models";
    }

    private List<String> parseModelListResponse(String response) throws Exception {
        Set<String> ids = new LinkedHashSet<>();
        String cleaned = response == null ? "" : response.trim();
        if (cleaned.startsWith("[")) {
            JSONArray array = new JSONArray(cleaned);
            collectModelIds(array, ids);
        } else {
            JSONObject json = new JSONObject(cleaned);
            JSONArray data = json.optJSONArray("data");
            if (data == null) data = json.optJSONArray("models");
            if (data == null) data = json.optJSONArray("items");
            if (data != null) collectModelIds(data, ids);

            String directId = json.optString("id", "").trim();
            if (directId.length() > 0) ids.add(directId);
        }
        return new ArrayList<>(ids);
    }

    private void collectModelIds(JSONArray array, Set<String> ids) {
        for (int i = 0; i < array.length(); i++) {
            Object item = array.opt(i);
            if (item instanceof JSONObject) {
                JSONObject obj = (JSONObject) item;
                String id = obj.optString("id", "").trim();
                if (id.length() == 0) id = obj.optString("name", "").trim();
                if (id.length() == 0) id = obj.optString("model", "").trim();
                if (id.length() > 0) ids.add(id);
            } else if (item != null) {
                String id = String.valueOf(item).trim();
                if (id.length() > 0) ids.add(id);
            }
        }
    }

    private String buildDraftPrompt(PipelineResult result) {
        StringBuilder sb = new StringBuilder();
        sb.append("请根据下面的内容运营上下文，生成一份可编辑的内容草稿。\n");
        sb.append("必须只输出合法 JSON，不要 Markdown 代码块，不要解释。\n");
        sb.append("JSON 字段必须包含：title, hook, body, cta, tags, platformDrafts, qualityReport。\n");
        sb.append("字段说明：\n");
        sb.append("- title：一个适合内容发布的标题。\n");
        sb.append("- hook：开头钩子，2-4 句话。\n");
        sb.append("- body：正文，包含核心观点、步骤、案例化表达和风险提醒。\n");
        sb.append("- cta：行动引导。\n");
        sb.append("- tags：标签字符串，用 # 开头。\n");
        sb.append("- platformDrafts：多平台适配草稿，包含公众号、小红书、抖音/视频号、B站。\n");
        sb.append("- qualityReport：质量优化建议，使用条目化中文。\n\n");
        sb.append("产品/账号定位：").append(result.product).append("\n");
        sb.append("目标人群：").append(result.audience).append("\n");
        sb.append("竞品/参考对象：").append(result.competitors).append("\n");
        sb.append("语气：").append(result.tone).append("\n\n");
        sb.append("热点信号：\n");
        for (TrendSignal trend : result.trends) {
            sb.append("- ").append(trend.keyword)
                    .append("，热度 ").append(trend.heat)
                    .append("，来源 ").append(trend.source)
                    .append("，趋势 ").append(trend.direction)
                    .append("，切口：").append(trend.contentAngle)
                    .append("\n");
        }
        sb.append("\n选题推荐：\n");
        for (String topic : result.topicRecommendations) {
            sb.append("- ").append(topic).append("\n");
        }
        sb.append("\n竞品分析：\n").append(result.competitorAnalysis).append("\n");
        sb.append("\n本地规则引擎初稿，可参考但需要重写得更自然：\n").append(result.generatedDraft).append("\n");
        return sb.toString();
    }

    private AiDraftResponse parseDraftResponse(String content, PipelineResult fallback) throws Exception {
        String jsonText = extractJson(content);
        JSONObject json = new JSONObject(jsonText);
        DraftSections old = fallback.draftSections;
        String title = valueOrFallback(json.optString("title"), old.title);
        String hook = valueOrFallback(json.optString("hook"), old.hook);
        String body = valueOrFallback(json.optString("body"), old.body);
        String cta = valueOrFallback(json.optString("cta"), old.cta);
        String tags = readTags(json, old.tags);
        String platformDrafts = readPlatformDrafts(json, old.platformDrafts);
        String qualityReport = valueOrFallback(json.optString("qualityReport"), fallback.qualityReport);
        return new AiDraftResponse(new DraftSections(title, hook, body, cta, tags, platformDrafts), qualityReport);
    }

    private String readTags(JSONObject json, String fallback) {
        Object value = json.opt("tags");
        if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < array.length(); i++) {
                String tag = array.optString(i).trim();
                if (tag.length() == 0) continue;
                if (sb.length() > 0) sb.append(" ");
                sb.append(tag.startsWith("#") ? tag : "#" + tag);
            }
            return sb.length() == 0 ? fallback : sb.toString();
        }
        return valueOrFallback(json.optString("tags"), fallback);
    }

    private String readPlatformDrafts(JSONObject json, String fallback) {
        Object value = json.opt("platformDrafts");
        if (value == null) return fallback;
        if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < array.length(); i++) {
                Object item = array.opt(i);
                if (item instanceof JSONObject) {
                    JSONObject obj = (JSONObject) item;
                    sb.append("【").append(obj.optString("platform", "平台" + (i + 1))).append("】\n");
                    sb.append(valueOrFallback(obj.optString("content"), obj.optString("body"))).append("\n");
                    String tags = obj.optString("tags");
                    if (tags.length() > 0) sb.append("标签：").append(tags).append("\n");
                    String checklist = obj.optString("checklist");
                    if (checklist.length() > 0) sb.append("发布前检查：").append(checklist).append("\n");
                    sb.append("\n");
                } else {
                    sb.append(String.valueOf(item)).append("\n\n");
                }
            }
            String result = sb.toString().trim();
            return result.length() == 0 ? fallback : result;
        }
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            StringBuilder sb = new StringBuilder();
            JSONArray keys = obj.names();
            if (keys != null) {
                for (int i = 0; i < keys.length(); i++) {
                    String key = keys.optString(i);
                    sb.append("【").append(key).append("】\n").append(obj.optString(key)).append("\n\n");
                }
            }
            String result = sb.toString().trim();
            return result.length() == 0 ? fallback : result;
        }
        return valueOrFallback(String.valueOf(value), fallback);
    }

    private String extractJson(String content) {
        String cleaned = stripCodeFence(content).trim();
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        if (start >= 0 && end > start) {
            return cleaned.substring(start, end + 1);
        }
        return cleaned;
    }

    private String stripCodeFence(String value) {
        String cleaned = value == null ? "" : value.trim();
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replaceFirst("^```[a-zA-Z]*", "").trim();
            if (cleaned.endsWith("```")) {
                cleaned = cleaned.substring(0, cleaned.length() - 3).trim();
            }
        }
        return cleaned;
    }

    private String valueOrFallback(String value, String fallback) {
        if (value == null) return fallback;
        String trimmed = value.trim();
        return trimmed.length() == 0 ? fallback : trimmed;
    }

    private String readAll(InputStream inputStream) throws Exception {
        if (inputStream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append('\n');
        }
        reader.close();
        return sb.toString();
    }

    private static String readableApiError(String response) {
        String cleaned = response == null ? "" : response.trim();
        try {
            JSONObject json = new JSONObject(cleaned);
            JSONObject error = json.optJSONObject("error");
            if (error != null) {
                String message = error.optString("message", "");
                String type = error.optString("type", "");
                String combined = (type.length() > 0 ? type + "：" : "") + message;
                if (combined.trim().length() > 0) return shorten(combined, 220);
            }
            String message = json.optString("message", "");
            if (message.length() > 0) return shorten(message, 220);
        } catch (Exception ignored) {
        }
        return shorten(cleaned, 220);
    }

    private static String shorten(String value, int max) {
        if (value == null) return "";
        String cleaned = value.replace('\n', ' ').trim();
        return cleaned.length() <= max ? cleaned : cleaned.substring(0, max) + "...";
    }
}
