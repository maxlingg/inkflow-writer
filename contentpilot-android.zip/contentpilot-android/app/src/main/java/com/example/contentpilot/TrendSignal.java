package com.example.contentpilot;

public class TrendSignal {
    public final String keyword;
    public final int heat;
    public final String insight;
    public final String contentAngle;
    public final String source;
    public final String direction;
    public final String updatedAt;

    public TrendSignal(String keyword, int heat, String insight, String contentAngle) {
        this(keyword, heat, insight, contentAngle, "本地热点池", "上升", "刚刚");
    }

    public TrendSignal(String keyword, int heat, String insight, String contentAngle, String source, String direction, String updatedAt) {
        this.keyword = keyword;
        this.heat = heat;
        this.insight = insight;
        this.contentAngle = contentAngle;
        this.source = source;
        this.direction = direction;
        this.updatedAt = updatedAt;
    }
}
