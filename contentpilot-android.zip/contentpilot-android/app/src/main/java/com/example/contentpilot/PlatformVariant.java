package com.example.contentpilot;

import java.util.List;

public class PlatformVariant {
    public final String platform;
    public final String title;
    public final String body;
    public final List<String> tags;
    public final List<String> checklist;

    public PlatformVariant(String platform, String title, String body, List<String> tags, List<String> checklist) {
        this.platform = platform;
        this.title = title;
        this.body = body;
        this.tags = tags;
        this.checklist = checklist;
    }
}
