package com.example.contentpilot;

public class DraftSections {
    public final String title;
    public final String hook;
    public final String body;
    public final String cta;
    public final String tags;
    public final String platformDrafts;

    public DraftSections(String title, String hook, String body, String cta, String tags, String platformDrafts) {
        this.title = title;
        this.hook = hook;
        this.body = body;
        this.cta = cta;
        this.tags = tags;
        this.platformDrafts = platformDrafts;
    }

    public String toPlainText() {
        StringBuilder sb = new StringBuilder();
        sb.append("标题：").append(title).append("\n\n");
        sb.append("开头钩子：").append(hook).append("\n\n");
        sb.append("正文：\n").append(body).append("\n\n");
        sb.append("CTA：").append(cta).append("\n\n");
        sb.append("标签：").append(tags).append("\n\n");
        sb.append("多平台适配草稿：\n").append(platformDrafts);
        return sb.toString();
    }
}
