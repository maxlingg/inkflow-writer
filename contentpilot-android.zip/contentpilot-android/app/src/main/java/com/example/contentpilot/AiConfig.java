package com.example.contentpilot;

import android.content.Context;
import android.content.SharedPreferences;

public class AiConfig {
    public static final String PREFS = "contentpilot_ai_prefs";
    public static final String PROVIDER_OPENAI = "openai";
    public static final String PROVIDER_CLAUDE = "claude";

    private static final String KEY_ENABLED = "ai_enabled";
    private static final String KEY_PROVIDER = "ai_provider";
    private static final String KEY_ENDPOINT = "ai_endpoint";
    private static final String KEY_API_KEY = "ai_api_key";
    private static final String KEY_MODEL = "ai_model";
    private static final String KEY_TEMPERATURE = "ai_temperature";
    private static final String KEY_SYSTEM_PROMPT = "ai_system_prompt";

    public final boolean enabled;
    public final String provider;
    public final String endpoint;
    public final String apiKey;
    public final String model;
    public final double temperature;
    public final String systemPrompt;

    public AiConfig(boolean enabled, String provider, String endpoint, String apiKey, String model, double temperature, String systemPrompt) {
        this.enabled = enabled;
        this.provider = normalizeProvider(provider);
        this.endpoint = normalizeEndpointForProvider(this.provider, endpoint);
        this.apiKey = safe(apiKey);
        this.model = safe(model).length() == 0 ? defaultModelForProvider(this.provider) : safe(model);
        this.temperature = temperature;
        this.systemPrompt = safe(systemPrompt).length() == 0 ? defaultSystemPrompt() : safe(systemPrompt);
    }

    public static AiConfig load(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String savedEndpoint = prefs.getString(KEY_ENDPOINT, "");
        String savedModel = prefs.getString(KEY_MODEL, "");
        String provider = prefs.getString(KEY_PROVIDER, inferProvider(savedEndpoint, savedModel));
        provider = normalizeProvider(provider);
        return new AiConfig(
                prefs.getBoolean(KEY_ENABLED, false),
                provider,
                safe(savedEndpoint).length() == 0 ? defaultEndpointForProvider(provider) : savedEndpoint,
                prefs.getString(KEY_API_KEY, ""),
                safe(savedModel).length() == 0 ? defaultModelForProvider(provider) : savedModel,
                parseTemperature(prefs.getString(KEY_TEMPERATURE, "0.7")),
                prefs.getString(KEY_SYSTEM_PROMPT, defaultSystemPrompt())
        );
    }

    public void save(Context context) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        editor.putBoolean(KEY_ENABLED, enabled);
        editor.putString(KEY_PROVIDER, provider);
        editor.putString(KEY_ENDPOINT, endpoint);
        editor.putString(KEY_API_KEY, apiKey);
        editor.putString(KEY_MODEL, model);
        editor.putString(KEY_TEMPERATURE, String.valueOf(temperature));
        editor.putString(KEY_SYSTEM_PROMPT, systemPrompt);
        editor.apply();
    }

    public AiConfig withEnabled(boolean value) {
        return new AiConfig(value, provider, endpoint, apiKey, model, temperature, systemPrompt);
    }

    public AiConfig withProviderPreset(String targetProvider) {
        String normalized = normalizeProvider(targetProvider);
        return new AiConfig(enabled, normalized, defaultEndpointForProvider(normalized), apiKey, defaultModelForProvider(normalized), temperature, systemPrompt);
    }

    public boolean isClaude() {
        return PROVIDER_CLAUDE.equals(provider);
    }

    public boolean hasRequiredFields() {
        return endpoint.length() > 0 && apiKey.length() > 0 && model.length() > 0;
    }

    public String providerDisplayName() {
        return providerDisplayName(provider);
    }

    public String statusText() {
        if (!enabled) return "未启用：当前使用本地规则引擎生成内容";
        if (!hasRequiredFields()) return "已启用但配置不完整：请填写接口类型、接口地址、API Key 和模型名";
        return "已启用：" + providerDisplayName() + " 将优先用于生成、局部重写，失败时自动回退本地规则引擎";
    }

    public String maskedKey() {
        if (apiKey.length() == 0) return "未填写";
        if (apiKey.length() <= 8) return "********";
        return apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4);
    }

    public static String defaultSystemPrompt() {
        return "你是 ContentPilot 的内容增长助手，擅长把热点、目标人群、竞品分析转化为可发布内容。请输出中文，表达具体、克制、可执行，避免夸大承诺。涉及发布必须保留人工确认、事实核查、敏感词和版权检查。";
    }

    public static double parseTemperature(String value) {
        try {
            double parsed = Double.parseDouble(safe(value));
            if (parsed < 0) return 0;
            if (parsed > 2) return 2;
            return parsed;
        } catch (Exception e) {
            return 0.7;
        }
    }

    public static String defaultEndpointForProvider(String provider) {
        String normalized = normalizeProvider(provider);
        if (PROVIDER_CLAUDE.equals(normalized)) {
            return "https://api.anthropic.com/v1/messages";
        }
        return "https://api.openai.com/v1/chat/completions";
    }

    public static String normalizeEndpointForProvider(String provider, String endpoint) {
        String normalizedProvider = normalizeProvider(provider);
        String cleaned = safe(endpoint);
        if (cleaned.length() == 0) {
            return defaultEndpointForProvider(normalizedProvider);
        }
        if (!cleaned.startsWith("http://") && !cleaned.startsWith("https://")) {
            cleaned = "https://" + cleaned;
        }
        while (cleaned.endsWith("/")) {
            cleaned = cleaned.substring(0, cleaned.length() - 1);
        }

        String lower = cleaned.toLowerCase();
        if (PROVIDER_CLAUDE.equals(normalizedProvider)) {
            if (lower.endsWith("/v1")) return cleaned + "/messages";
            if (lower.endsWith("/messages")) return cleaned;
            if (lower.endsWith("/models")) return cleaned.substring(0, cleaned.length() - "/models".length()) + "/messages";
            if (lower.endsWith("/chat/completions")) {
                return cleaned.substring(0, cleaned.length() - "/chat/completions".length()) + "/messages";
            }
            if (lower.endsWith("/completions")) {
                return cleaned.substring(0, cleaned.length() - "/completions".length()) + "/messages";
            }
            return cleaned;
        }

        if (lower.endsWith("/v1")) return cleaned + "/chat/completions";
        if (lower.endsWith("/chat/completions")) return cleaned;
        if (lower.endsWith("/models")) return cleaned.substring(0, cleaned.length() - "/models".length()) + "/chat/completions";
        if (lower.endsWith("/messages")) return cleaned.substring(0, cleaned.length() - "/messages".length()) + "/chat/completions";
        if (lower.endsWith("/completions") && !lower.endsWith("/chat/completions")) {
            return cleaned.substring(0, cleaned.length() - "/completions".length()) + "/chat/completions";
        }
        return cleaned;
    }

    public static String defaultModelForProvider(String provider) {
        String normalized = normalizeProvider(provider);
        if (PROVIDER_CLAUDE.equals(normalized)) {
            return "claude-sonnet-4-6";
        }
        return "gpt-4o-mini";
    }

    public static String providerDisplayName(String provider) {
        String normalized = normalizeProvider(provider);
        if (PROVIDER_CLAUDE.equals(normalized)) return "Claude / Anthropic Messages API";
        return "OpenAI 兼容 Chat Completions";
    }

    public static String normalizeProvider(String value) {
        String cleaned = safe(value).toLowerCase();
        if (cleaned.contains("claude") || cleaned.contains("anthropic")) return PROVIDER_CLAUDE;
        return PROVIDER_OPENAI;
    }

    public static String inferProvider(String endpoint, String model) {
        String joined = (safe(endpoint) + " " + safe(model)).toLowerCase();
        if (joined.contains("anthropic") || joined.contains("claude") || joined.contains("/v1/messages")) {
            return PROVIDER_CLAUDE;
        }
        return PROVIDER_OPENAI;
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
