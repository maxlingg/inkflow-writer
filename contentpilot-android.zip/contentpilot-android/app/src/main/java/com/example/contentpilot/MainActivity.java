package com.example.contentpilot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final ContentEngine engine = new ContentEngine();
    private final AiClient aiClient = new AiClient();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private EditText productInput;
    private EditText audienceInput;
    private EditText competitorInput;
    private EditText toneInput;
    private EditText topicInput;

    private EditText aiProviderInput;
    private EditText aiEndpointInput;
    private EditText aiApiKeyInput;
    private EditText aiModelInput;
    private EditText aiTemperatureInput;
    private EditText aiSystemPromptInput;

    private EditText titleEdit;
    private EditText hookEdit;
    private EditText bodyEdit;
    private EditText ctaEdit;
    private EditText tagsEdit;
    private EditText platformEdit;

    private TextView outputText;
    private TextView scoreText;
    private final List<TextView> stepViews = new ArrayList<>();
    private PipelineResult lastResult;

    private int currentPage = 0;
    private int activeStep = -1;
    private int hotOffset = 0;
    private int rewriteRound = 0;
    private String currentStatus = "当前状态：等待生成";
    private String currentOutput = "还没有生成内容。请先到“生成配置”页填写内容并开始。";

    private String productValue = "AI内容运营助手";
    private String audienceValue = "小微企业主、内容运营、独立创作者";
    private String competitorValue = "同行账号、行业大号、同类SaaS工具";
    private String toneValue = "专业、克制、有执行感";
    private String topicValue = "AI效率, 低成本获客, 多平台适配, 内容自动化";

    private String draftTitleValue = "";
    private String draftHookValue = "";
    private String draftBodyValue = "";
    private String draftCtaValue = "";
    private String draftTagsValue = "";
    private String draftPlatformValue = "";

    private static final String PREFS = "contentpilot_prefs";
    private static final String KEY_LAST_MARKDOWN = "last_markdown";
    private static final String KEY_HISTORY_COUNT = "history_count";
    private static final String KEY_HISTORY_TITLE = "history_title_";
    private static final String KEY_HISTORY_MARKDOWN = "history_markdown_";
    private static final String KEY_HISTORY_CREATED = "history_created_";
    private static final String KEY_HISTORY_SCORE = "history_score_";
    private static final int MAX_HISTORY = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(getColor(R.color.surface));

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(18), dp(24), dp(18), dp(32));
        scrollView.addView(main, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));

        TextView badge = pill("Automated Content Ops MVP");
        main.addView(badge);

        TextView title = text("ContentPilot", 34, true, R.color.text_primary);
        title.setPadding(0, dp(12), 0, dp(4));
        main.addView(title);

        TextView subtitle = text(pageSubtitle(), 15, false, R.color.text_secondary);
        subtitle.setLineSpacing(4, 1f);
        main.addView(subtitle);

        main.addView(tabBar());

        if (currentPage == 0) {
            buildHomePage(main);
        } else if (currentPage == 1) {
            buildConfigPage(main);
        } else if (currentPage == 2) {
            buildAutomationPage(main);
        } else if (currentPage == 3) {
            buildLibraryPage(main);
        } else {
            buildAiSettingsPage(main);
        }

        setContentView(scrollView);
        applyProcessState();
    }

    private String pageSubtitle() {
        if (currentPage == 1) {
            return "第二页：生成配置。填写产品定位、目标人群、竞品和热点种子词，再启动自动化生成。";
        }
        if (currentPage == 2) {
            return "第三页：自动化流程。展示执行进度、可编辑草稿、重写按钮和人工确认发布入口。";
        }
        if (currentPage == 3) {
            return "第四页：内容库。保存每次生成的内容方案，方便回看、加载和再次分享。";
        }
        if (currentPage == 4) {
            return "AI设置：支持 OpenAI 兼容接口和 Claude / Anthropic Messages API，生成时优先接入 AI。";
        }
        return "主页：自动展示当下热点，并把核心能力拆成独立卡片。";
    }

    private View tabBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(16), 0, 0);

        row.addView(navButton("主页", 0), tabLp(0));
        row.addView(navButton("配置", 1), tabLp(dp(5)));
        row.addView(navButton("流程", 2), tabLp(dp(5)));
        row.addView(navButton("内容库", 3), tabLp(dp(5)));
        row.addView(navButton("AI", 4), tabLp(dp(5)));
        return row;
    }

    private LinearLayout.LayoutParams tabLp(int leftMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(leftMargin, 0, 0, 0);
        return lp;
    }

    private Button navButton(String label, int page) {
        Button button = currentPage == page ? primaryButton(label) : secondaryButton(label);
        button.setTextSize(11);
        button.setPadding(dp(2), dp(6), dp(2), dp(6));
        button.setOnClickListener(v -> showPage(page));
        return button;
    }

    private void showPage(int page) {
        syncInputValues();
        syncDraftEditors();
        currentPage = page;
        outputText = null;
        scoreText = null;
        titleEdit = null;
        hookEdit = null;
        bodyEdit = null;
        ctaEdit = null;
        tagsEdit = null;
        platformEdit = null;
        aiProviderInput = null;
        aiEndpointInput = null;
        aiApiKeyInput = null;
        aiModelInput = null;
        aiTemperatureInput = null;
        aiSystemPromptInput = null;
        stepViews.clear();
        buildUi();
    }

    private void buildHomePage(LinearLayout main) {
        main.addView(currentHotCard());

        main.addView(featureDetailCard(
                "🔥 热点监测",
                "定位：发现当前最值得追的内容机会。",
                "输入：行业关键词、产品定位、目标人群。",
                "输出：热点来源、更新时间、热度趋势、关联理由和可切入角度。"
        ));
        main.addView(featureDetailCard(
                "🧠 选题推荐",
                "定位：把热点转成可发布的具体选题。",
                "输入：热点信号、目标人群痛点、账号定位。",
                "输出：标题建议、优先级、核心观点、内容结构。"
        ));
        main.addView(featureDetailCard(
                "🕵️ 竞品分析",
                "定位：拆解同行内容策略，找到差异化机会。",
                "输入：竞品/参考账号、行业大号、同类工具。",
                "输出：竞品强项、弱项、可借鉴点和避坑建议。"
        ));
        main.addView(featureDetailCard(
                "✍️ 内容生成",
                "定位：基于选题直接生成可编辑草稿。",
                "输入：选题、语气、产品卖点、CTA 目标。",
                "输出：标题、开头钩子、正文、CTA 和标签，支持逐段编辑。"
        ));
        main.addView(featureDetailCard(
                "✅ 质量优化",
                "定位：检查内容是否清晰、可信、可转化。",
                "输入：生成草稿和平台要求。",
                "输出：质量评分、优化建议、风险词提醒和改写方向。"
        ));
        main.addView(featureDetailCard(
                "🚀 多平台适配草稿",
                "定位：把同一内容改写成不同平台版本，人工确认后再发布。",
                "输入：优化后的主稿和目标平台。",
                "输出：公众号、小红书、抖音/视频号、B站等适配草稿和发布前检查。"
        ));
    }

    private View currentHotCard() {
        List<TrendSignal> hotList = engine.getTodayHotTrends();
        final TrendSignal hot = hotList.get(hotOffset % hotList.size());

        LinearLayout card = card();
        card.addView(text("⚡ 当下热点", 19, true, R.color.text_primary));
        TextView desc = text("自动获取当下可追内容机会，无需输入。当前为原型内置热点源，可后续接入真实平台 API。", 14, false, R.color.text_secondary);
        desc.setPadding(0, dp(6), 0, dp(8));
        desc.setLineSpacing(4, 1f);
        card.addView(desc);

        card.addView(metaLine("今日 TOP 热点：" + hot.keyword));
        card.addView(metaLine("热度分数：" + hot.heat + "/100"));
        card.addView(metaLine("来源：" + hot.source));
        card.addView(metaLine("更新时间：" + hot.updatedAt));
        card.addView(metaLine("热度趋势：" + hot.direction));

        TextView angle = text("内容切口：" + hot.contentAngle, 14, false, R.color.text_primary);
        angle.setPadding(0, dp(8), 0, dp(8));
        angle.setLineSpacing(4, 1f);
        card.addView(angle);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button use = primaryButton("用热点开始配置");
        use.setOnClickListener(v -> {
            topicValue = hot.keyword + ", " + topicValue;
            Toast.makeText(this, "已同步到生成配置", Toast.LENGTH_SHORT).show();
            showPage(1);
        });
        row.addView(use, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button refresh = secondaryButton("刷新热点");
        refresh.setOnClickListener(v -> {
            hotOffset++;
            buildUi();
        });
        LinearLayout.LayoutParams refreshLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        refreshLp.setMargins(dp(10), 0, 0, 0);
        row.addView(refresh, refreshLp);
        card.addView(row);
        return withTopMargin(card, 18);
    }

    private View featureDetailCard(String title, String desc, String input, String output) {
        LinearLayout card = card();
        card.addView(text(title, 18, true, R.color.text_primary));
        TextView descView = text(desc, 14, false, R.color.text_secondary);
        descView.setPadding(0, dp(8), 0, dp(6));
        descView.setLineSpacing(4, 1f);
        card.addView(descView);
        card.addView(metaLine(input));
        card.addView(metaLine(output));
        return withTopMargin(card, 12);
    }

    private TextView metaLine(String value) {
        TextView tv = text(value, 13, false, R.color.text_primary);
        tv.setPadding(0, dp(3), 0, dp(3));
        tv.setLineSpacing(3, 1f);
        return tv;
    }

    private void buildConfigPage(LinearLayout main) {
        LinearLayout card = card();
        card.addView(text("生成配置", 19, true, R.color.text_primary));
        TextView desc = text("第二页专门用于配置生成参数。配置完成后，系统会跳转到第三页展示自动化流程和可编辑草稿。AI 接入可在右上 AI 页配置。", 14, false, R.color.text_secondary);
        desc.setPadding(0, dp(6), 0, dp(8));
        desc.setLineSpacing(4, 1f);
        card.addView(desc);
        card.addView(metaLine("AI状态：" + AiConfig.load(this).statusText()));

        productInput = input("产品/账号定位", productValue);
        audienceInput = input("目标人群", audienceValue);
        competitorInput = input("竞品/参考账号", competitorValue);
        toneInput = input("内容语气", toneValue);
        topicInput = input("热点种子词，用逗号分隔", topicValue);
        topicInput.setMinLines(2);

        card.addView(label("产品/账号定位"));
        card.addView(productInput);
        card.addView(label("目标人群"));
        card.addView(audienceInput);
        card.addView(label("竞品/参考账号"));
        card.addView(competitorInput);
        card.addView(label("内容语气"));
        card.addView(toneInput);
        card.addView(label("热点种子词"));
        card.addView(topicInput);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(14), 0, 0);

        Button generate = primaryButton("生成并进入流程");
        generate.setOnClickListener(v -> startPipeline());
        row.addView(generate, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button sample = secondaryButton("恢复示例");
        sample.setOnClickListener(v -> restoreSample());
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        sampleLp.setMargins(dp(10), 0, 0, 0);
        row.addView(sample, sampleLp);
        card.addView(row);

        main.addView(withTopMargin(card, 18));

        LinearLayout tip = card();
        tip.addView(text("配置建议", 18, true, R.color.text_primary));
        TextView tipText = text("• 产品定位越具体，选题越精准\n• 竞品可填写账号名、品牌名或参考内容方向\n• 热点种子词建议 3-6 个，用逗号分隔\n• 多平台内容先生成草稿，发布前建议人工确认", 14, false, R.color.text_secondary);
        tipText.setPadding(0, dp(8), 0, 0);
        tipText.setLineSpacing(5, 1f);
        tip.addView(tipText);
        main.addView(withTopMargin(tip, 12));
    }

    private void buildAutomationPage(LinearLayout main) {
        LinearLayout intro = card();
        intro.addView(text("自动化流程", 19, true, R.color.text_primary));
        TextView desc = text("第三页集中展示执行步骤。生成完成后，内容会拆成可编辑模块，并提供 AI/本地重写标题、重写开头、重写标签按钮。", 14, false, R.color.text_secondary);
        desc.setPadding(0, dp(6), 0, dp(10));
        desc.setLineSpacing(4, 1f);
        intro.addView(desc);

        Button backConfig = secondaryButton("返回生成配置");
        backConfig.setOnClickListener(v -> showPage(1));
        intro.addView(backConfig);
        main.addView(withTopMargin(intro, 18));

        main.addView(progressCard());
        main.addView(outputCard());
    }

    private View progressCard() {
        LinearLayout card = card();
        card.addView(text("流程进度", 18, true, R.color.text_primary));
        card.addView(text("每一步都会产出可复用结果，最终汇总为一份可编辑、可复制、可分享的内容方案。", 14, false, R.color.text_secondary));

        LinearLayout steps = new LinearLayout(this);
        steps.setOrientation(LinearLayout.VERTICAL);
        steps.setPadding(0, dp(10), 0, 0);
        String[] names = {"1 热点监测", "2 选题推荐", "3 竞品分析", "4 内容生成", "5 质量优化", "6 平台适配草稿"};
        for (String name : names) {
            TextView step = text(name, 14, true, R.color.text_secondary);
            step.setGravity(Gravity.CENTER_VERTICAL);
            step.setPadding(dp(12), dp(9), dp(12), dp(9));
            step.setBackgroundResource(R.drawable.step_idle);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            lp.setMargins(0, dp(5), 0, dp(5));
            steps.addView(step, lp);
            stepViews.add(step);
        }
        card.addView(steps);

        scoreText = text(currentStatus, 14, true, R.color.primary);
        scoreText.setPadding(0, dp(12), 0, 0);
        card.addView(scoreText);
        return withTopMargin(card, 12);
    }

    private View outputCard() {
        LinearLayout card = card();
        card.addView(text(lastResult == null ? "输出结果" : "可编辑生成草稿", 18, true, R.color.text_primary));
        card.addView(text(lastResult == null ? "生成后可复制到飞书/Notion，也可直接分享给微信、邮件或团队群。" : "生成结果已拆成模块。修改任意模块后，再复制、保存或人工确认发布。", 14, false, R.color.text_secondary));

        if (lastResult == null) {
            outputText = text(currentOutput, 13, false, android.R.color.white);
            outputText.setTypeface(Typeface.MONOSPACE);
            outputText.setLineSpacing(5, 1f);
            outputText.setPadding(dp(14), dp(14), dp(14), dp(14));
            outputText.setBackgroundResource(R.drawable.output_bg);
            LinearLayout.LayoutParams outputLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            outputLp.setMargins(0, dp(12), 0, dp(12));
            card.addView(outputText, outputLp);
        } else {
            addEditor(card, "标题", titleEdit = input("标题", draftTitleValue), 1);
            addEditor(card, "开头钩子", hookEdit = input("开头钩子", draftHookValue), 3);
            addEditor(card, "正文", bodyEdit = input("正文", draftBodyValue), 8);
            addEditor(card, "CTA", ctaEdit = input("CTA", draftCtaValue), 2);
            addEditor(card, "标签", tagsEdit = input("标签", draftTagsValue), 2);
            addEditor(card, "多平台适配草稿", platformEdit = input("多平台适配草稿", draftPlatformValue), 8);

            LinearLayout rewriteRow = new LinearLayout(this);
            rewriteRow.setOrientation(LinearLayout.VERTICAL);
            rewriteRow.setPadding(0, dp(12), 0, 0);
            Button rewriteTitle = secondaryButton("重新生成标题");
            rewriteTitle.setOnClickListener(v -> regenerateTitle());
            rewriteRow.addView(rewriteTitle);
            Button rewriteHook = secondaryButton("重新生成开头");
            rewriteHook.setOnClickListener(v -> regenerateHook());
            rewriteRow.addView(withTopMargin(rewriteHook, 8));
            Button rewriteTags = secondaryButton("重新生成标签");
            rewriteTags.setOnClickListener(v -> regenerateTags());
            rewriteRow.addView(withTopMargin(rewriteTags, 8));
            card.addView(rewriteRow);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(12), 0, 0);
        Button copy = secondaryButton(lastResult == null ? "复制结果" : "复制草稿");
        copy.setOnClickListener(v -> copyResult());
        actions.addView(copy, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button share = secondaryButton("人工确认发布/分享");
        share.setOnClickListener(v -> shareResult());
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        shareLp.setMargins(dp(10), 0, 0, 0);
        actions.addView(share, shareLp);
        card.addView(actions);

        Button save = primaryButton(lastResult == null ? "读取最近项目" : "保存到内容库");
        save.setOnClickListener(v -> {
            if (lastResult == null) {
                loadHistory();
            } else {
                saveCurrentDraftToLibrary();
            }
        });
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        saveLp.setMargins(0, dp(10), 0, 0);
        card.addView(save, saveLp);

        Button library = secondaryButton("打开内容库");
        library.setOnClickListener(v -> showPage(3));
        card.addView(withTopMargin(library, 10));
        return withTopMargin(card, 12);
    }

    private void addEditor(LinearLayout parent, String label, EditText editText, int minLines) {
        parent.addView(label(label));
        editText.setMinLines(minLines);
        editText.setGravity(Gravity.TOP | Gravity.START);
        parent.addView(editText);
    }

    private void buildLibraryPage(LinearLayout main) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int count = prefs.getInt(KEY_HISTORY_COUNT, 0);

        LinearLayout header = card();
        header.addView(text("内容库 / 历史记录", 19, true, R.color.text_primary));
        TextView desc = text("这里会保存每次生成或手动保存的方案。你可以加载到流程页继续复制/分享。", 14, false, R.color.text_secondary);
        desc.setPadding(0, dp(6), 0, dp(10));
        desc.setLineSpacing(4, 1f);
        header.addView(desc);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button newDraft = primaryButton("新建生成");
        newDraft.setOnClickListener(v -> showPage(1));
        row.addView(newDraft, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button clear = secondaryButton("清空内容库");
        clear.setOnClickListener(v -> clearLibrary());
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        clearLp.setMargins(dp(10), 0, 0, 0);
        row.addView(clear, clearLp);
        header.addView(row);
        main.addView(withTopMargin(header, 18));

        if (count == 0) {
            LinearLayout empty = card();
            empty.addView(text("暂无保存内容", 18, true, R.color.text_primary));
            TextView tip = text("生成第一条方案后，系统会自动保存到这里。", 14, false, R.color.text_secondary);
            tip.setPadding(0, dp(8), 0, 0);
            empty.addView(tip);
            main.addView(withTopMargin(empty, 12));
            return;
        }

        for (int i = 0; i < count; i++) {
            final int index = i;
            String title = prefs.getString(KEY_HISTORY_TITLE + i, "未命名方案");
            String created = prefs.getString(KEY_HISTORY_CREATED + i, "未知时间");
            int score = prefs.getInt(KEY_HISTORY_SCORE + i, 0);
            String markdown = prefs.getString(KEY_HISTORY_MARKDOWN + i, "");

            LinearLayout item = card();
            item.addView(text(title, 17, true, R.color.text_primary));
            item.addView(metaLine("时间：" + created + "｜质量评分：" + score + "/100"));
            TextView preview = text(shortPreview(markdown), 13, false, R.color.text_secondary);
            preview.setPadding(0, dp(8), 0, dp(10));
            preview.setLineSpacing(4, 1f);
            item.addView(preview);

            LinearLayout buttons = new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            Button load = primaryButton("加载");
            load.setOnClickListener(v -> loadLibraryItem(index));
            buttons.addView(load, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button share = secondaryButton("分享");
            share.setOnClickListener(v -> shareLibraryItem(index));
            LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            shareLp.setMargins(dp(10), 0, 0, 0);
            buttons.addView(share, shareLp);
            item.addView(buttons);
            main.addView(withTopMargin(item, 12));
        }
    }


    private void buildAiSettingsPage(LinearLayout main) {
        AiConfig config = AiConfig.load(this);

        LinearLayout card = card();
        card.addView(text("AI 设置", 19, true, R.color.text_primary));
        TextView desc = text("配置后，内容生成、标题重写、开头重写、标签重写会优先调用 AI。现在支持 OpenAI 兼容 Chat Completions，也支持 Claude / Anthropic Messages API。正式上线建议改成你的后端中转地址，不要在客户端内置固定密钥。", 14, false, R.color.text_secondary);
        desc.setPadding(0, dp(6), 0, dp(10));
        desc.setLineSpacing(4, 1f);
        card.addView(desc);

        TextView status = text("当前状态：" + config.statusText(), 14, true, config.enabled && config.hasRequiredFields() ? R.color.primary : R.color.text_secondary);
        status.setPadding(0, dp(4), 0, dp(8));
        status.setLineSpacing(4, 1f);
        card.addView(status);
        card.addView(metaLine("接口类型：" + config.providerDisplayName()));
        card.addView(metaLine("Key 状态：" + config.maskedKey()));

        Button toggle = config.enabled ? secondaryButton("关闭 AI 接入") : primaryButton("启用 AI 接入");
        toggle.setOnClickListener(v -> {
            AiConfig current = readAiConfigFromInputs(config).withEnabled(!config.enabled);
            current.save(this);
            Toast.makeText(this, current.enabled ? "已启用 AI 接入" : "已关闭 AI 接入", Toast.LENGTH_SHORT).show();
            buildUi();
        });
        card.addView(withTopMargin(toggle, 12));

        LinearLayout providerRow = new LinearLayout(this);
        providerRow.setOrientation(LinearLayout.HORIZONTAL);
        providerRow.setPadding(0, dp(12), 0, 0);
        Button openAiPreset = AiConfig.PROVIDER_OPENAI.equals(config.provider) ? primaryButton("OpenAI兼容") : secondaryButton("OpenAI兼容");
        openAiPreset.setOnClickListener(v -> applyAiProviderPreset(AiConfig.PROVIDER_OPENAI));
        providerRow.addView(openAiPreset, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button claudePreset = AiConfig.PROVIDER_CLAUDE.equals(config.provider) ? primaryButton("Claude") : secondaryButton("Claude");
        claudePreset.setOnClickListener(v -> applyAiProviderPreset(AiConfig.PROVIDER_CLAUDE));
        LinearLayout.LayoutParams claudeLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        claudeLp.setMargins(dp(10), 0, 0, 0);
        providerRow.addView(claudePreset, claudeLp);
        card.addView(providerRow);

        aiProviderInput = input("接口类型：openai 或 claude", config.provider);
        aiEndpointInput = input("AI 接口地址", config.endpoint);
        aiApiKeyInput = passwordInput("API Key", config.apiKey);
        aiModelInput = input("模型名", config.model);
        aiTemperatureInput = input("温度，例如 0.7", String.valueOf(config.temperature));
        aiSystemPromptInput = input("系统提示词", config.systemPrompt);
        aiSystemPromptInput.setMinLines(4);
        aiSystemPromptInput.setGravity(Gravity.TOP | Gravity.START);

        card.addView(label("接口类型"));
        card.addView(aiProviderInput);
        card.addView(label("接口地址（可填 /v1 基础地址）"));
        card.addView(aiEndpointInput);

        LinearLayout endpointRow = new LinearLayout(this);
        endpointRow.setOrientation(LinearLayout.HORIZONTAL);
        endpointRow.setPadding(0, dp(10), 0, 0);
        Button autoEndpoint = secondaryButton("自动补全链接");
        autoEndpoint.setOnClickListener(v -> autocompleteAiEndpoint());
        endpointRow.addView(autoEndpoint, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button modelscopeEndpoint = secondaryButton("ModelScope示例");
        modelscopeEndpoint.setOnClickListener(v -> {
            if (aiProviderInput != null) aiProviderInput.setText(AiConfig.PROVIDER_OPENAI);
            if (aiEndpointInput != null) aiEndpointInput.setText("https://api-inference.modelscope.cn/v1/chat/completions");
            Toast.makeText(this, "已填入 ModelScope OpenAI 兼容接口", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams modelscopeLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        modelscopeLp.setMargins(dp(10), 0, 0, 0);
        endpointRow.addView(modelscopeEndpoint, modelscopeLp);
        card.addView(endpointRow);
        card.addView(metaLine("自动补全示例：https://api-inference.modelscope.cn/v1 → https://api-inference.modelscope.cn/v1/chat/completions"));

        card.addView(label("API Key"));
        card.addView(aiApiKeyInput);
        card.addView(label("模型"));
        card.addView(aiModelInput);

        LinearLayout modelRow = new LinearLayout(this);
        modelRow.setOrientation(LinearLayout.HORIZONTAL);
        modelRow.setPadding(0, dp(10), 0, 0);
        Button fetchModels = secondaryButton("获取可用模型");
        fetchModels.setOnClickListener(v -> fetchAvailableModels());
        modelRow.addView(fetchModels, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button modelTip = secondaryButton("手动填写");
        modelTip.setOnClickListener(v -> Toast.makeText(this, "无法获取列表时，可继续手动填写模型 ID", Toast.LENGTH_SHORT).show());
        LinearLayout.LayoutParams modelTipLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        modelTipLp.setMargins(dp(10), 0, 0, 0);
        modelRow.addView(modelTip, modelTipLp);
        card.addView(modelRow);
        card.addView(metaLine("模型列表会根据接口地址自动请求 /models；例如 /v1 或 /v1/chat/completions 会转为 /v1/models。"));

        card.addView(label("温度"));
        card.addView(aiTemperatureInput);
        card.addView(label("系统提示词"));
        card.addView(aiSystemPromptInput);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(14), 0, 0);
        Button save = primaryButton("保存设置");
        save.setOnClickListener(v -> saveAiSettings());
        row.addView(save, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button test = secondaryButton("测试连接");
        test.setOnClickListener(v -> testAiConnection());
        LinearLayout.LayoutParams testLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        testLp.setMargins(dp(10), 0, 0, 0);
        row.addView(test, testLp);
        card.addView(row);

        Button clear = secondaryButton("清除 API Key");
        clear.setOnClickListener(v -> {
            if (aiApiKeyInput != null) aiApiKeyInput.setText("");
            saveAiSettings();
        });
        card.addView(withTopMargin(clear, 10));

        main.addView(withTopMargin(card, 18));

        LinearLayout guide = card();
        guide.addView(text("接入说明", 18, true, R.color.text_primary));
        TextView guideText = text("1. OpenAI兼容：可直接填 /v1 基础地址，App 会自动补全为 /v1/chat/completions；例如 ModelScope 可填 https://api-inference.modelscope.cn/v1。\n2. 点击“获取可用模型”会自动请求 /models，并弹出模型列表供选择；如果你的服务不支持 /models，可继续手动填写模型 ID。\n3. Claude：可直接填 https://api.anthropic.com/v1，App 会自动补全为 /v1/messages；使用 x-api-key 和 anthropic-version 请求头，解析 content[].text。\n4. 正式产品：推荐填写你自己的后端代理地址，由后端保存密钥并调用模型。\n5. AI 请求失败时，App 会自动回退到本地规则引擎，保证流程不中断。", 14, false, R.color.text_secondary);
        guideText.setPadding(0, dp(8), 0, 0);
        guideText.setLineSpacing(5, 1f);
        guide.addView(guideText);
        main.addView(withTopMargin(guide, 12));
    }

    private AiConfig readAiConfigFromInputs(AiConfig fallback) {
        String provider = aiProviderInput == null ? fallback.provider : aiProviderInput.getText().toString();
        String endpoint = aiEndpointInput == null ? fallback.endpoint : aiEndpointInput.getText().toString();
        String apiKey = aiApiKeyInput == null ? fallback.apiKey : aiApiKeyInput.getText().toString();
        String model = aiModelInput == null ? fallback.model : aiModelInput.getText().toString();
        String temperature = aiTemperatureInput == null ? String.valueOf(fallback.temperature) : aiTemperatureInput.getText().toString();
        String systemPrompt = aiSystemPromptInput == null ? fallback.systemPrompt : aiSystemPromptInput.getText().toString();
        return new AiConfig(fallback.enabled, provider, endpoint, apiKey, model, AiConfig.parseTemperature(temperature), systemPrompt);
    }

    private void applyAiProviderPreset(String provider) {
        AiConfig current = readAiConfigFromInputs(AiConfig.load(this)).withProviderPreset(provider);
        if (aiProviderInput != null) aiProviderInput.setText(current.provider);
        if (aiEndpointInput != null) aiEndpointInput.setText(current.endpoint);
        if (aiModelInput != null) aiModelInput.setText(current.model);
        Toast.makeText(this, "已切换为 " + current.providerDisplayName(), Toast.LENGTH_SHORT).show();
    }

    private void autocompleteAiEndpoint() {
        AiConfig current = readAiConfigFromInputs(AiConfig.load(this));
        if (aiProviderInput != null) aiProviderInput.setText(current.provider);
        if (aiEndpointInput != null) {
            aiEndpointInput.setText(current.endpoint);
            aiEndpointInput.setSelection(aiEndpointInput.getText().length());
        }
        Toast.makeText(this, "接口地址已自动补全", Toast.LENGTH_SHORT).show();
    }

    private void saveAiSettings() {
        AiConfig saved = readAiConfigFromInputs(AiConfig.load(this));
        saved.save(this);
        Toast.makeText(this, "AI 设置已保存", Toast.LENGTH_SHORT).show();
        buildUi();
    }


    private void fetchAvailableModels() {
        AiConfig config = readAiConfigFromInputs(AiConfig.load(this)).withEnabled(true);
        config.save(this);
        if (aiEndpointInput != null) aiEndpointInput.setText(config.endpoint);
        if (config.endpoint.length() == 0 || config.apiKey.length() == 0) {
            Toast.makeText(this, "请先填写接口地址和 API Key", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "正在获取可用模型……", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                List<String> models = aiClient.fetchAvailableModels(config);
                handler.post(() -> showModelPicker(models));
            } catch (Exception e) {
                String error = simpleError(e.getMessage());
                handler.post(() -> Toast.makeText(this, "获取模型失败：" + error, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void showModelPicker(List<String> models) {
        if (models == null || models.isEmpty()) {
            Toast.makeText(this, "没有获取到可用模型", Toast.LENGTH_LONG).show();
            return;
        }
        String[] items = models.toArray(new String[0]);
        String current = aiModelInput == null ? "" : aiModelInput.getText().toString().trim();
        int checked = -1;
        for (int i = 0; i < items.length; i++) {
            if (items[i].equals(current)) {
                checked = i;
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("选择可用模型")
                .setSingleChoiceItems(items, checked, (dialog, which) -> {
                    if (aiModelInput != null) {
                        aiModelInput.setText(items[which]);
                    }
                    dialog.dismiss();
                    Toast.makeText(this, "已选择模型：" + items[which], Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void testAiConnection() {
        AiConfig config = readAiConfigFromInputs(AiConfig.load(this)).withEnabled(true);
        config.save(this);
        if (aiEndpointInput != null) aiEndpointInput.setText(config.endpoint);
        if (!config.hasRequiredFields()) {
            Toast.makeText(this, "请先填写接口类型、接口地址、API Key 和模型名", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "正在测试 AI 连接……", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String message = aiClient.testConnection(config);
                handler.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                String error = simpleError(e.getMessage());
                handler.post(() -> Toast.makeText(this, "连接失败：" + error, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void startPipeline() {
        syncInputValues();
        handler.removeCallbacksAndMessages(null);

        final AiConfig aiConfig = AiConfig.load(this);
        final boolean aiReady = aiConfig.enabled && aiConfig.hasRequiredFields();

        currentOutput = "正在启动自动化任务……\n\n数据源：" + (aiReady ? "本地规则引擎 + AI 模型" : "本地规则引擎 + 原型热点池")
                + "\n状态：准备生成热点、选题、竞品和平台草稿。";
        currentStatus = "当前状态：任务启动中";
        activeStep = -1;
        lastResult = null;
        showPage(2);

        final String[] messages = {
                "正在监测热点：计算来源、更新时间、热度趋势和内容切口……",
                "正在推荐选题：生成标题、排序优先级和内容角度……",
                "正在分析竞品：识别强项、弱项、差异化机会……",
                aiReady ? "正在调用 AI：生成标题、开头、正文、CTA 和标签……" : "正在生成内容：拆分标题、开头、正文、CTA 和标签……",
                aiReady ? "正在优化 AI 草稿：检查钩子、可信度、风险词和转化路径……" : "正在质量优化：检查钩子、可信度、风险词和转化路径……",
                "正在适配平台草稿：生成公众号、小红书、抖音/视频号、B站版本……"
        };
        for (int i = 0; i < messages.length; i++) {
            final int index = i;
            handler.postDelayed(() -> {
                activeStep = index;
                currentStatus = messages[index];
                currentOutput = messages[index] + "\n\n请稍候，系统正在串联上下游结果。";
                applyProcessState();
            }, 360L * (i + 1));
        }

        final long startedAt = System.currentTimeMillis();
        final long minDurationMs = 360L * (messages.length + 2);

        new Thread(() -> {
            PipelineResult computed = engine.run(
                    productValue,
                    audienceValue,
                    competitorValue,
                    toneValue,
                    topicValue
            );
            String finishNote = "";
            boolean usedAi = false;

            if (aiConfig.enabled && !aiConfig.hasRequiredFields()) {
                finishNote = "AI 已启用但配置不完整，已自动使用本地规则引擎。";
                computed = computed.copyWithQualityNote(finishNote);
            } else if (aiReady) {
                handler.post(() -> {
                    currentStatus = "AI 已接入：正在请求模型生成可编辑草稿……";
                    currentOutput = "AI 已接入，正在生成标题、开头、正文、CTA、标签和多平台适配草稿。\n\n接口类型：" + aiConfig.providerDisplayName() + "\n接口地址：" + aiConfig.endpoint + "\n模型：" + aiConfig.model;
                    applyProcessState();
                });
                try {
                    AiDraftResponse aiDraft = aiClient.generateDraft(aiConfig, computed);
                    finishNote = "AI 接入成功：草稿由模型生成，本地规则引擎负责热点、流程和兜底。";
                    computed = computed.copyWithAiDraft(aiDraft, finishNote);
                    usedAi = true;
                } catch (Exception e) {
                    finishNote = "AI 请求失败，已自动回退本地规则引擎：" + simpleError(e.getMessage());
                    computed = computed.copyWithQualityNote(finishNote);
                }
            }

            final PipelineResult finalResult = computed;
            final String finalNote = finishNote;
            final boolean finalUsedAi = usedAi;
            long elapsed = System.currentTimeMillis() - startedAt;
            long delay = Math.max(0, minDurationMs - elapsed);
            handler.postDelayed(() -> finishPipeline(finalResult, finalNote, finalUsedAi), delay);
        }).start();
    }

    private void finishPipeline(PipelineResult computed, String note, boolean usedAi) {
        lastResult = computed;
        setDraftValues(computed.draftSections);
        currentOutput = composeCurrentMarkdown();
        String source = usedAi ? "AI生成" : "本地生成";
        currentStatus = "完成：" + source + "｜质量评分 " + computed.qualityScore + "/100｜已生成 " + computed.platformVariants.size() + " 个平台适配草稿";
        if (note != null && note.length() > 0) {
            currentStatus += "｜" + note;
        }
        activeStep = 5;
        saveMarkdown(currentOutput);
        saveToLibrary(draftTitleValue, currentOutput, computed.createdAt, computed.qualityScore);
        buildUi();
        Toast.makeText(this, usedAi ? "AI 方案已生成并保存到内容库" : "方案已生成并保存到内容库", Toast.LENGTH_SHORT).show();
    }

    private void setDraftValues(DraftSections sections) {
        draftTitleValue = sections.title;
        draftHookValue = sections.hook;
        draftBodyValue = sections.body;
        draftCtaValue = sections.cta;
        draftTagsValue = sections.tags;
        draftPlatformValue = sections.platformDrafts;
    }

    private void syncDraftEditors() {
        if (titleEdit == null) return;
        draftTitleValue = titleEdit.getText().toString();
        draftHookValue = hookEdit.getText().toString();
        draftBodyValue = bodyEdit.getText().toString();
        draftCtaValue = ctaEdit.getText().toString();
        draftTagsValue = tagsEdit.getText().toString();
        draftPlatformValue = platformEdit.getText().toString();
        if (lastResult != null) {
            currentOutput = composeCurrentMarkdown();
        }
    }

    private String composeCurrentMarkdown() {
        if (lastResult == null) return currentOutput;
        return lastResult.toMarkdownWithSections(
                draftTitleValue,
                draftHookValue,
                draftBodyValue,
                draftCtaValue,
                draftTagsValue,
                draftPlatformValue
        );
    }

    private void regenerateTitle() {
        if (lastResult == null || titleEdit == null) return;
        AiConfig config = AiConfig.load(this);
        if (config.enabled && config.hasRequiredFields()) {
            rewriteWithAi("标题", "title", titleEdit);
            return;
        }
        rewriteRound++;
        titleEdit.setText(engine.rewriteTitle(lastResult, rewriteRound));
        titleEdit.setSelection(titleEdit.getText().length());
        syncDraftEditors();
        Toast.makeText(this, "已重新生成标题", Toast.LENGTH_SHORT).show();
    }

    private void regenerateHook() {
        if (lastResult == null || hookEdit == null) return;
        AiConfig config = AiConfig.load(this);
        if (config.enabled && config.hasRequiredFields()) {
            rewriteWithAi("开头", "hook", hookEdit);
            return;
        }
        rewriteRound++;
        hookEdit.setText(engine.rewriteHook(lastResult, rewriteRound));
        hookEdit.setSelection(hookEdit.getText().length());
        syncDraftEditors();
        Toast.makeText(this, "已重新生成开头", Toast.LENGTH_SHORT).show();
    }

    private void regenerateTags() {
        if (lastResult == null || tagsEdit == null) return;
        AiConfig config = AiConfig.load(this);
        if (config.enabled && config.hasRequiredFields()) {
            rewriteWithAi("标签", "tags", tagsEdit);
            return;
        }
        rewriteRound++;
        tagsEdit.setText(engine.rewriteTags(lastResult, rewriteRound));
        tagsEdit.setSelection(tagsEdit.getText().length());
        syncDraftEditors();
        Toast.makeText(this, "已重新生成标签", Toast.LENGTH_SHORT).show();
    }

    private void rewriteWithAi(String label, String field, EditText target) {
        AiConfig config = AiConfig.load(this);
        syncDraftEditors();
        String currentMarkdown = composeCurrentMarkdown();
        Toast.makeText(this, "AI 正在重新生成" + label + "……", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String rewritten = aiClient.rewriteField(config, lastResult, field, currentMarkdown);
                handler.post(() -> {
                    target.setText(rewritten);
                    target.setSelection(target.getText().length());
                    syncDraftEditors();
                    Toast.makeText(this, "AI 已重新生成" + label, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                String error = simpleError(e.getMessage());
                handler.post(() -> Toast.makeText(this, "AI 重写失败：" + error, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void applyProcessState() {
        if (scoreText != null) {
            scoreText.setText(currentStatus);
        }
        if (outputText != null) {
            outputText.setText(currentOutput);
        }
        updateStep(activeStep);
    }

    private void updateStep(int activeIndex) {
        for (int i = 0; i < stepViews.size(); i++) {
            TextView step = stepViews.get(i);
            if (activeIndex >= i) {
                step.setBackgroundResource(R.drawable.step_active);
                step.setTextColor(getColor(android.R.color.white));
            } else {
                step.setBackgroundResource(R.drawable.step_idle);
                step.setTextColor(getColor(R.color.text_secondary));
            }
        }
    }

    private void copyResult() {
        String content = getCurrentContentForAction();
        if (!isReadyContent(content)) {
            Toast.makeText(this, "请先生成方案", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("ContentPilot draft", content));
        Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
    }

    private void shareResult() {
        String content = getCurrentContentForAction();
        if (!isReadyContent(content)) {
            Toast.makeText(this, "请先生成方案", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "ContentPilot 多平台适配草稿");
        sendIntent.putExtra(Intent.EXTRA_TEXT, content + "\n\n发布提醒：请人工确认事实、敏感词、素材版权和账号规则后再发布。");
        startActivity(Intent.createChooser(sendIntent, "人工确认发布/分享草稿"));
    }

    private String getCurrentContentForAction() {
        syncDraftEditors();
        if (lastResult != null) return composeCurrentMarkdown();
        return currentOutput;
    }

    private boolean isReadyContent(String content) {
        return content != null && content.length() > 0 && !content.startsWith("还没有") && !content.startsWith("正在");
    }

    private void saveCurrentDraftToLibrary() {
        String content = getCurrentContentForAction();
        if (!isReadyContent(content) || lastResult == null) {
            Toast.makeText(this, "请先生成方案", Toast.LENGTH_SHORT).show();
            return;
        }
        saveMarkdown(content);
        saveToLibrary(draftTitleValue, content, lastResult.createdAt, lastResult.qualityScore);
        Toast.makeText(this, "已保存到内容库", Toast.LENGTH_SHORT).show();
    }

    private void saveMarkdown(String markdown) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putString(KEY_LAST_MARKDOWN, markdown).apply();
    }

    private void saveToLibrary(String title, String markdown, String createdAt, int score) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        int count = Math.min(prefs.getInt(KEY_HISTORY_COUNT, 0), MAX_HISTORY - 1);
        for (int i = count - 1; i >= 0; i--) {
            editor.putString(KEY_HISTORY_TITLE + (i + 1), prefs.getString(KEY_HISTORY_TITLE + i, ""));
            editor.putString(KEY_HISTORY_MARKDOWN + (i + 1), prefs.getString(KEY_HISTORY_MARKDOWN + i, ""));
            editor.putString(KEY_HISTORY_CREATED + (i + 1), prefs.getString(KEY_HISTORY_CREATED + i, ""));
            editor.putInt(KEY_HISTORY_SCORE + (i + 1), prefs.getInt(KEY_HISTORY_SCORE + i, 0));
        }
        editor.putString(KEY_HISTORY_TITLE + 0, title.length() == 0 ? "未命名方案" : title);
        editor.putString(KEY_HISTORY_MARKDOWN + 0, markdown);
        editor.putString(KEY_HISTORY_CREATED + 0, createdAt);
        editor.putInt(KEY_HISTORY_SCORE + 0, score);
        editor.putInt(KEY_HISTORY_COUNT, Math.min(count + 1, MAX_HISTORY));
        editor.apply();
    }

    private void loadHistory() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String markdown = prefs.getString(KEY_LAST_MARKDOWN, "");
        if (markdown.length() == 0) {
            Toast.makeText(this, "暂无历史结果", Toast.LENGTH_SHORT).show();
            return;
        }
        lastResult = null;
        currentOutput = markdown;
        currentStatus = "已读取最近项目";
        activeStep = 5;
        applyProcessState();
    }

    private void loadLibraryItem(int index) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String markdown = prefs.getString(KEY_HISTORY_MARKDOWN + index, "");
        if (markdown.length() == 0) {
            Toast.makeText(this, "内容不存在", Toast.LENGTH_SHORT).show();
            return;
        }
        lastResult = null;
        currentOutput = markdown;
        currentStatus = "已从内容库加载项目";
        activeStep = 5;
        saveMarkdown(markdown);
        showPage(2);
    }

    private void shareLibraryItem(int index) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String markdown = prefs.getString(KEY_HISTORY_MARKDOWN + index, "");
        if (markdown.length() == 0) {
            Toast.makeText(this, "内容不存在", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "ContentPilot 内容库草稿");
        sendIntent.putExtra(Intent.EXTRA_TEXT, markdown);
        startActivity(Intent.createChooser(sendIntent, "分享内容库草稿"));
    }

    private void clearLibrary() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int count = prefs.getInt(KEY_HISTORY_COUNT, 0);
        SharedPreferences.Editor editor = prefs.edit();
        for (int i = 0; i < count; i++) {
            editor.remove(KEY_HISTORY_TITLE + i);
            editor.remove(KEY_HISTORY_MARKDOWN + i);
            editor.remove(KEY_HISTORY_CREATED + i);
            editor.remove(KEY_HISTORY_SCORE + i);
        }
        editor.putInt(KEY_HISTORY_COUNT, 0);
        editor.apply();
        Toast.makeText(this, "内容库已清空", Toast.LENGTH_SHORT).show();
        buildUi();
    }

    private String shortPreview(String markdown) {
        String cleaned = markdown.replace("#", "").replace("\n", " ").trim();
        if (cleaned.length() > 110) return cleaned.substring(0, 110) + "...";
        return cleaned;
    }

    private void restoreSample() {
        productValue = "AI内容运营助手";
        audienceValue = "小微企业主、内容运营、独立创作者";
        competitorValue = "同行账号、行业大号、同类SaaS工具";
        toneValue = "专业、克制、有执行感";
        topicValue = "AI效率, 低成本获客, 多平台适配, 内容自动化";
        if (productInput != null) productInput.setText(productValue);
        if (audienceInput != null) audienceInput.setText(audienceValue);
        if (competitorInput != null) competitorInput.setText(competitorValue);
        if (toneInput != null) toneInput.setText(toneValue);
        if (topicInput != null) topicInput.setText(topicValue);
        Toast.makeText(this, "已恢复示例配置", Toast.LENGTH_SHORT).show();
    }

    private void syncInputValues() {
        if (productInput == null) return;
        productValue = productInput.getText().toString();
        audienceValue = audienceInput.getText().toString();
        competitorValue = competitorInput.getText().toString();
        toneValue = toneInput.getText().toString();
        topicValue = topicInput.getText().toString();
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.card_bg);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        return card;
    }

    private View withTopMargin(View view, int marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(marginDp), 0, 0);
        view.setLayoutParams(lp);
        return view;
    }

    private TextView text(String value, int sp, boolean bold, int colorRes) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(getColor(colorRes));
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private TextView pill(String value) {
        TextView tv = text(value, 13, true, R.color.primary);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundResource(R.drawable.pill_bg);
        tv.setPadding(dp(12), dp(7), dp(12), dp(7));
        return tv;
    }

    private TextView label(String value) {
        TextView label = text(value, 13, true, R.color.text_primary);
        label.setPadding(0, dp(12), 0, dp(5));
        return label;
    }

    private EditText input(String hint, String defaultValue) {
        EditText editText = new EditText(this);
        editText.setText(defaultValue);
        editText.setHint(hint);
        editText.setTextSize(15);
        editText.setSingleLine(false);
        editText.setMinLines(1);
        editText.setBackgroundResource(R.drawable.input_bg);
        editText.setTextColor(getColor(R.color.text_primary));
        editText.setHintTextColor(getColor(R.color.text_secondary));
        editText.setPadding(dp(12), dp(10), dp(12), dp(10));
        return editText;
    }


    private EditText passwordInput(String hint, String defaultValue) {
        EditText editText = input(hint, defaultValue);
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        editText.setSingleLine(true);
        return editText;
    }

    private String simpleError(String message) {
        if (message == null || message.trim().length() == 0) return "未知错误";
        String cleaned = message.replace('\n', ' ').trim();
        if (cleaned.length() > 120) return cleaned.substring(0, 120) + "...";
        return cleaned;
    }

    private Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(getColor(android.R.color.white));
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackgroundResource(R.drawable.button_primary);
        return button;
    }

    private Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(getColor(R.color.primary));
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackgroundResource(R.drawable.button_secondary);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
