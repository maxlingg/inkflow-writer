#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "未找到 gradle。请安装 Gradle 9.4.1，或直接推送到 GitHub 让 Actions 自动构建。"
  exit 1
fi

if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo "未设置 ANDROID_HOME/ANDROID_SDK_ROOT。请先安装 Android SDK。"
  exit 1
fi

gradle :app:assembleDebug :app:assembleRelease --no-daemon

echo "APK 输出目录：app/build/outputs/apk/"
