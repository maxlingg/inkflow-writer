#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "用法: ./scripts/push_to_github.sh git@github.com:<你的用户名>/<仓库名>.git"
  echo "或:   ./scripts/push_to_github.sh https://github.com/<你的用户名>/<仓库名>.git"
  exit 1
fi

REMOTE_URL="$1"
BRANCH="${2:-main}"

git init
git add .
git commit -m "Initial ContentPilot Android MVP" || true
git branch -M "$BRANCH"
git remote remove origin 2>/dev/null || true
git remote add origin "$REMOTE_URL"
git push -u origin "$BRANCH"

echo "已推送到 $REMOTE_URL"
echo "进入 GitHub > Actions > Build Android APK，下载 ContentPilot-APKs artifact。"
