import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/ai_skill.dart';
import '../services/app_settings.dart';
import 'skills_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.settings});

  final AppSettings settings;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  List<AiSkill> _skills = const [];
  Set<String> _activeSkillIds = const {};
  bool _loadingSkills = true;

  AppSettings get settings => widget.settings;

  @override
  void initState() {
    super.initState();
    _loadSkills();
  }

  Future<void> _loadSkills() async {
    final skills = await AiSkillStore.loadAllSkills();
    final activeIds = await AiSkillStore.loadActiveSkillIds();
    if (!mounted) return;
    setState(() {
      _skills = skills;
      _activeSkillIds = activeIds;
      _loadingSkills = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('设置')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            children: [
              _SystemPromptCard(
                prompt: settings.systemPrompt,
                onEdit: () => _editSystemPrompt(context),
                onReset: () async {
                  await settings.resetSystemPrompt();
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('已恢复默认系统提示词')),
                  );
                },
              ),
              const SizedBox(height: 12),
              _SkillManagerCard(
                skills: _skills,
                activeIds: _activeSkillIds,
                loading: _loadingSkills,
                onImportFile: _importSkillFile,
                onImportDirectory: _importSkillDirectory,
                onOpenLibrary: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SkillsScreen()),
                  );
                  await _loadSkills();
                },
                onOpenSkill: (skill) async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => SkillsScreen(initialSkillId: skill.id)),
                  );
                  await _loadSkills();
                },
                onToggle: (skill, active) async {
                  await AiSkillStore.setSkillActive(skill.id, active);
                  await _loadSkills();
                },
                onDelete: (skill) async {
                  await _deleteCustomSkill(skill);
                },
              ),
              const SizedBox(height: 12),
              _AppearanceCard(settings: settings),
              const SizedBox(height: 12),
              _FontSizeCard(settings: settings),
              const SizedBox(height: 12),
              _AiServiceCard(
                settings: settings,
                onEditApiKey: () => _editValue(
                  context: context,
                  title: 'API Key',
                  initialValue: settings.aiApiKey,
                  hintText: 'sk-...',
                  obscureText: true,
                  onSave: settings.setAiApiKey,
                ),
                onEditBaseUrl: () => _editValue(
                  context: context,
                  title: '接口地址',
                  initialValue: settings.aiBaseUrl,
                  hintText: 'https://api.openai.com/v1',
                  onSave: settings.setAiBaseUrl,
                ),
                onEditModel: () => _editValue(
                  context: context,
                  title: '模型名',
                  initialValue: settings.aiModel,
                  hintText: 'gpt-4o-mini',
                  onSave: settings.setAiModel,
                ),
              ),
              const SizedBox(height: 12),
              _AiParameterCard(settings: settings),
              const SizedBox(height: 12),
              const Card(
                child: ListTile(
                  leading: Icon(Icons.verified_user_rounded),
                  title: Text('隐私与数据'),
                  subtitle: Text('作品默认保存在本机；API Key 已通过系统安全存储保存。使用联网 AI 时，当前任务相关的章节、资料和提示词会发送给你配置的接口服务商。'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _editSystemPrompt(BuildContext context) async {
    final controller = TextEditingController(text: settings.systemPrompt);
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (context) {
        final bottom = MediaQuery.of(context).viewInsets.bottom;
        return Padding(
          padding: EdgeInsets.fromLTRB(18, 18, 18, bottom + 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '系统提示词',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              Text(
                '这是所有 AI 请求的总规则。激活的 Skill 会自动追加在后面。',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                minLines: 10,
                maxLines: 18,
                autofocus: true,
                decoration: const InputDecoration(hintText: AppSettings.defaultSystemPrompt),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('取消'),
                  ),
                  const Spacer(),
                  FilledButton(
                    onPressed: () => Navigator.pop(context, controller.text),
                    child: const Text('保存提示词'),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
    if (result == null) return;
    await settings.setSystemPrompt(result);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('系统提示词已保存')),
    );
  }

  Future<void> _importSkillFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip', 'json', 'skill', 'md', 'txt'],
    );
    final path = result?.files.single.path;
    if (path == null) return;
    await _runImport(() => AiSkillStore.importFromFilePath(path));
  }

  Future<void> _importSkillDirectory() async {
    final path = await FilePicker.platform.getDirectoryPath(dialogTitle: '选择 Skill 目录');
    if (path == null) return;
    await _runImport(() => AiSkillStore.importFromDirectory(path));
  }

  Future<void> _runImport(Future<int> Function() action) async {
    try {
      final count = await action();
      await _loadSkills();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已导入 $count 个 Skill。为安全起见，新导入 Skill 默认未激活，请检查提示词后手动启用。')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('导入失败：$error')),
      );
    }
  }

  Future<void> _deleteCustomSkill(AiSkill skill) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${skill.name}」？'),
        content: const Text('只会删除你创建或导入的 Skill，不影响内置 Skill。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton.tonal(onPressed: () => Navigator.pop(context, true), child: const Text('删除')),
        ],
      ),
    );
    if (shouldDelete != true) return;
    await AiSkillStore.deleteCustomSkill(skill.id);
    await _loadSkills();
  }

  Future<void> _editValue({
    required BuildContext context,
    required String title,
    required String initialValue,
    required String hintText,
    required Future<void> Function(String value) onSave,
    bool obscureText = false,
  }) async {
    final controller = TextEditingController(text: initialValue);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          obscureText: obscureText,
          decoration: InputDecoration(hintText: hintText),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('保存')),
        ],
      ),
    );
    if (value == null) return;
    await onSave(value);
  }
}

class _SystemPromptCard extends StatelessWidget {
  const _SystemPromptCard({required this.prompt, required this.onEdit, required this.onReset});

  final String prompt;
  final VoidCallback onEdit;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle(title: '系统提示词'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '自定义 AI 助手的行为，留空则使用默认的小说写作助手提示词。',
                  style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: colors.surfaceContainerHighest.withOpacity(0.48),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Text(
                    prompt,
                    maxLines: 6,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.55),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: onEdit,
                        icon: const Icon(Icons.edit_note_rounded),
                        label: const Text('编辑提示词'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.outlined(
                      onPressed: onReset,
                      tooltip: '恢复默认',
                      icon: const Icon(Icons.restore_rounded),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SkillManagerCard extends StatelessWidget {
  const _SkillManagerCard({
    required this.skills,
    required this.activeIds,
    required this.loading,
    required this.onImportFile,
    required this.onImportDirectory,
    required this.onOpenLibrary,
    required this.onOpenSkill,
    required this.onToggle,
    required this.onDelete,
  });

  final List<AiSkill> skills;
  final Set<String> activeIds;
  final bool loading;
  final VoidCallback onImportFile;
  final VoidCallback onImportDirectory;
  final VoidCallback onOpenLibrary;
  final ValueChanged<AiSkill> onOpenSkill;
  final Future<void> Function(AiSkill skill, bool active) onToggle;
  final Future<void> Function(AiSkill skill) onDelete;

  @override
  Widget build(BuildContext context) {
    final shown = skills.take(8).toList();
    final activeCount = skills.where((skill) => activeIds.contains(skill.id)).length;
    final colors = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle(title: 'Skill 管理'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Skill 定义 AI 的工作流程和行为规范。点开任意 Skill 可查看提示词；自定义 Skill 可直接修改，内置 Skill 可复制成自定义后修改。',
                  style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700, height: 1.45),
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    OutlinedButton.icon(
                      onPressed: onImportFile,
                      icon: const Icon(Icons.upload_file_rounded),
                      label: const Text('导入压缩包'),
                    ),
                    OutlinedButton.icon(
                      onPressed: onImportDirectory,
                      icon: const Icon(Icons.folder_open_rounded),
                      label: const Text('导入目录'),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: onOpenLibrary,
                      icon: const Icon(Icons.auto_awesome_rounded),
                      label: const Text('技能库'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  loading ? '正在读取 Skill…' : '已激活 $activeCount / ${skills.length} 个 Skill',
                  style: TextStyle(color: colors.onSurfaceVariant),
                ),
                const SizedBox(height: 10),
                if (loading)
                  const Center(child: Padding(padding: EdgeInsets.all(18), child: CircularProgressIndicator()))
                else
                  ...shown.map(
                    (skill) => _SkillSettingTile(
                      skill: skill,
                      active: activeIds.contains(skill.id),
                      onOpen: () => onOpenSkill(skill),
                      onToggle: (active) => onToggle(skill, active),
                      onDelete: skill.isCustom ? () => onDelete(skill) : null,
                    ),
                  ),
                if (!loading && skills.length > shown.length)
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: onOpenLibrary,
                      child: Text('查看全部 ${skills.length} 个'),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _SkillSettingTile extends StatelessWidget {
  const _SkillSettingTile({
    required this.skill,
    required this.active,
    required this.onOpen,
    required this.onToggle,
    this.onDelete,
  });

  final AiSkill skill;
  final bool active;
  final VoidCallback onOpen;
  final ValueChanged<bool> onToggle;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      decoration: BoxDecoration(
        border: Border.all(color: active ? colors.primary : colors.outlineVariant),
        borderRadius: BorderRadius.circular(18),
        color: active ? colors.primaryContainer.withOpacity(0.18) : colors.surface,
      ),
      child: ListTile(
        onTap: onOpen,
        leading: CircleAvatar(
          backgroundColor: colors.primaryContainer.withOpacity(0.55),
          child: Text(skill.icon),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                skill.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
            if (!skill.isCustom) const _Badge(text: '内置'),
            if (active) ...[
              const SizedBox(width: 6),
              const _Badge(text: '激活'),
            ],
          ],
        ),
        subtitle: Text(
          '${skill.shortDescription} · 点开查看/修改',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Wrap(
          spacing: 0,
          children: [
            IconButton(
              onPressed: () => onToggle(!active),
              tooltip: active ? '停用' : '激活',
              icon: Icon(active ? Icons.pause_circle_filled_rounded : Icons.play_arrow_rounded),
            ),
            if (onDelete != null)
              IconButton(
                onPressed: onDelete,
                tooltip: '删除',
                icon: const Icon(Icons.delete_outline_rounded),
              ),
          ],
        ),
      ),
    );
  }
}

class _AppearanceCard extends StatelessWidget {
  const _AppearanceCard({required this.settings});

  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('外观', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            RadioListTile<ThemeMode>(
              value: ThemeMode.system,
              groupValue: settings.themeMode,
              onChanged: (value) {
                if (value != null) settings.setThemeMode(value);
              },
              title: const Text('跟随系统'),
            ),
            RadioListTile<ThemeMode>(
              value: ThemeMode.light,
              groupValue: settings.themeMode,
              onChanged: (value) {
                if (value != null) settings.setThemeMode(value);
              },
              title: const Text('浅色'),
            ),
            RadioListTile<ThemeMode>(
              value: ThemeMode.dark,
              groupValue: settings.themeMode,
              onChanged: (value) {
                if (value != null) settings.setThemeMode(value);
              },
              title: const Text('深色'),
            ),
          ],
        ),
      ),
    );
  }
}

class _FontSizeCard extends StatelessWidget {
  const _FontSizeCard({required this.settings});

  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '编辑器字号：${settings.editorFontSize.toStringAsFixed(0)}',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
            Slider(
              value: settings.editorFontSize,
              min: 14,
              max: 28,
              divisions: 14,
              label: settings.editorFontSize.toStringAsFixed(0),
              onChanged: settings.setEditorFontSize,
            ),
          ],
        ),
      ),
    );
  }
}

class _AiServiceCard extends StatelessWidget {
  const _AiServiceCard({
    required this.settings,
    required this.onEditApiKey,
    required this.onEditBaseUrl,
    required this.onEditModel,
  });

  final AppSettings settings;
  final VoidCallback onEditApiKey;
  final VoidCallback onEditBaseUrl;
  final VoidCallback onEditModel;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: Column(
          children: [
            ListTile(
              leading: Icon(settings.hasAiApiKey ? Icons.cloud_done_rounded : Icons.offline_bolt_rounded),
              title: const Text('AI 服务'),
              subtitle: Text(settings.hasAiApiKey ? '已填写 API Key，将使用联网生成。' : '未填写 API Key，AI 创作台会使用本地模板。'),
            ),
            const Divider(height: 1),
            ListTile(
              title: const Text('API Key'),
              subtitle: Text(settings.hasAiApiKey ? '已保存，点此修改' : '点此填写'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: onEditApiKey,
            ),
            ListTile(
              title: const Text('接口地址'),
              subtitle: Text(settings.aiBaseUrl),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: onEditBaseUrl,
            ),
            ListTile(
              title: const Text('模型名'),
              subtitle: Text(settings.aiModel),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: onEditModel,
            ),
          ],
        ),
      ),
    );
  }
}


class _AiParameterCard extends StatefulWidget {
  const _AiParameterCard({required this.settings});

  final AppSettings settings;

  @override
  State<_AiParameterCard> createState() => _AiParameterCardState();
}

class _AiParameterCardState extends State<_AiParameterCard> {
  late double _temperature;
  late bool _autoCleanup;
  late bool _distillEnabled;
  late TextEditingController _thresholdController;
  late TextEditingController _distillTriggerController;
  late TextEditingController _distillTargetController;

  @override
  void initState() {
    super.initState();
    _temperature = widget.settings.aiTemperature;
    _autoCleanup = widget.settings.contextAutoCleanupEnabled;
    _distillEnabled = widget.settings.distillMemoryEnabled;
    _thresholdController = TextEditingController(
      text: widget.settings.contextCleanupThresholdTokens.toString(),
    );
    _distillTriggerController = TextEditingController(
      text: widget.settings.distillTriggerTokens.toString(),
    );
    _distillTargetController = TextEditingController(
      text: widget.settings.distillTargetTokens.toString(),
    );
  }

  @override
  void didUpdateWidget(covariant _AiParameterCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.settings != widget.settings) {
      _temperature = widget.settings.aiTemperature;
      _autoCleanup = widget.settings.contextAutoCleanupEnabled;
      _distillEnabled = widget.settings.distillMemoryEnabled;
      _thresholdController.text = widget.settings.contextCleanupThresholdTokens.toString();
      _distillTriggerController.text = widget.settings.distillTriggerTokens.toString();
      _distillTargetController.text = widget.settings.distillTargetTokens.toString();
    }
  }

  @override
  void dispose() {
    _thresholdController.dispose();
    _distillTriggerController.dispose();
    _distillTargetController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final raw = _thresholdController.text.replaceAll(RegExp(r'[^0-9]'), '');
    final threshold = int.tryParse(raw) ?? widget.settings.contextCleanupThresholdTokens;
    final distillTriggerRaw = _distillTriggerController.text.replaceAll(RegExp(r'[^0-9]'), '');
    final distillTargetRaw = _distillTargetController.text.replaceAll(RegExp(r'[^0-9]'), '');
    final distillTrigger = int.tryParse(distillTriggerRaw) ?? widget.settings.distillTriggerTokens;
    final distillTarget = int.tryParse(distillTargetRaw) ?? widget.settings.distillTargetTokens;
    await widget.settings.setAiTemperature(_temperature);
    await widget.settings.setContextAutoCleanupEnabled(_autoCleanup);
    await widget.settings.setContextCleanupThresholdTokens(threshold);
    await widget.settings.setDistillMemoryEnabled(_distillEnabled);
    await widget.settings.setDistillTriggerTokens(distillTrigger);
    await widget.settings.setDistillTargetTokens(distillTarget);
    _thresholdController.text = widget.settings.contextCleanupThresholdTokens.toString();
    _distillTriggerController.text = widget.settings.distillTriggerTokens.toString();
    _distillTargetController.text = widget.settings.distillTargetTokens.toString();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('AI 参数已保存')),
    );
  }

  Future<void> _reset() async {
    await widget.settings.resetAiParameters();
    setState(() {
      _temperature = widget.settings.aiTemperature;
      _autoCleanup = widget.settings.contextAutoCleanupEnabled;
      _distillEnabled = widget.settings.distillMemoryEnabled;
      _thresholdController.text = widget.settings.contextCleanupThresholdTokens.toString();
      _distillTriggerController.text = widget.settings.distillTriggerTokens.toString();
      _distillTargetController.text = widget.settings.distillTargetTokens.toString();
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已恢复默认 AI 参数')),
    );
  }

  void _showTemperatureHelp() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('温度说明'),
        content: const Text(
          '控制 AI 回复的随机性：\n\n'
          '• 0.0：最确定、最保守，适合校对和资料整理。\n'
          '• 1.0：默认值，创意和稳定性比较平衡。\n'
          '• 1.5：更有创意、更多样，适合灵感、脑洞和桥段设计。',
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('知道了')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle(title: '参数设置'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      '温度',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                    ),
                    IconButton(
                      onPressed: _showTemperatureHelp,
                      tooltip: '温度说明',
                      icon: const Icon(Icons.help_outline_rounded),
                    ),
                    const Spacer(),
                    Text(
                      _temperature.toStringAsFixed(1),
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: colors.primary,
                            fontWeight: FontWeight.w900,
                          ),
                    ),
                  ],
                ),
                Slider(
                  value: _temperature.clamp(0.0, 1.5).toDouble(),
                  min: 0,
                  max: 1.5,
                  divisions: 15,
                  label: _temperature.toStringAsFixed(1),
                  onChanged: (value) => setState(() => _temperature = value),
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: const [
                    _HintChip(text: '0.0 最确定'),
                    _HintChip(text: '1.0 平衡'),
                    _HintChip(text: '1.5 更有创意'),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(height: 1),
                const SizedBox(height: 14),
                Text(
                  '上下文自动清理',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  '当对话、小说资料、章节内容拼接后超过设定阈值时，自动压缩较早上下文，保留任务说明、当前章节和最近内容，避免超过模型上下文限制。',
                  style: TextStyle(color: colors.onSurfaceVariant, height: 1.45),
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _autoCleanup,
                  controlAffinity: ListTileControlAffinity.leading,
                  title: const Text('启用自动清理', style: TextStyle(fontWeight: FontWeight.w900)),
                  onChanged: (value) => setState(() => _autoCleanup = value ?? true),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '触发阈值（tokens）',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                      ),
                    ),
                    SizedBox(
                      width: 150,
                      child: TextField(
                        controller: _thresholdController,
                        enabled: _autoCleanup,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(hintText: '200000'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '建议按模型上下文窗口设置，例如 GLM-5 可填 200000；较小模型可填 16000～64000。',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant),
                ),
                const SizedBox(height: 14),
                const Divider(height: 1),
                const SizedBox(height: 14),
                Text(
                  '蒸馏记忆',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  '把超长上下文、章节和对话压缩成「蒸馏记忆.md」。后续 AI 写作会优先读取它，减少遗忘、重复和设定漂移。',
                  style: TextStyle(color: colors.onSurfaceVariant, height: 1.45),
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _distillEnabled,
                  controlAffinity: ListTileControlAffinity.leading,
                  title: const Text('启用蒸馏记忆', style: TextStyle(fontWeight: FontWeight.w900)),
                  onChanged: (value) => setState(() => _distillEnabled = value ?? true),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '蒸馏触发阈值',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                      ),
                    ),
                    SizedBox(
                      width: 150,
                      child: TextField(
                        controller: _distillTriggerController,
                        enabled: _distillEnabled,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(hintText: '60000'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '目标记忆长度',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900),
                      ),
                    ),
                    SizedBox(
                      width: 150,
                      child: TextField(
                        controller: _distillTargetController,
                        enabled: _distillEnabled,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(hintText: '4000'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '建议：触发阈值 30000～80000，目标长度 3000～8000。长篇越长，越应该定期手动蒸馏。',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    TextButton.icon(
                      onPressed: _reset,
                      icon: const Icon(Icons.restore_rounded),
                      label: const Text('恢复默认'),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton(
                        onPressed: _save,
                        child: const Text('保存参数'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _HintChip extends StatelessWidget {
  const _HintChip({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: colors.primaryContainer.withOpacity(0.55),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(
              color: colors.onPrimaryContainer,
              fontWeight: FontWeight.w800,
            ),
      ),
    );
  }
}


class _Badge extends StatelessWidget {
  const _Badge({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: colors.primaryContainer,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: Theme.of(context).textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w800)),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 4, 2, 8),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 24,
            decoration: BoxDecoration(
              color: colors.primary,
              borderRadius: BorderRadius.circular(99),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: colors.primary,
                  fontWeight: FontWeight.w900,
                ),
          ),
        ],
      ),
    );
  }
}
