import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/chat_session.dart';
import '../models/writing_project.dart';
import '../services/ai_service.dart';
import '../services/app_settings.dart';
import '../services/chat_session_store.dart';
import '../services/storage_service.dart';
import '../widgets/app_bottom_bar.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.settings, this.initialProject});

  final AppSettings settings;
  final WritingProject? initialProject;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _inputController = TextEditingController();
  final _scrollController = ScrollController();
  List<ChatSession> _sessions = [];
  List<WritingProject> _projects = [];
  ChatSession? _session;
  WritingProject? _project;
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final sessions = await ChatSessionStore.loadSessions();
    final projects = await StorageService.instance.loadProjects();
    var currentProject = widget.initialProject;

    ChatSession current;
    if (sessions.isNotEmpty) {
      current = sessions.first;
      if (current.projectId != null) {
        final matches = projects.where((item) => item.id == current.projectId).toList();
        if (matches.isNotEmpty) currentProject = matches.first;
      }
    } else {
      if (currentProject == null && projects.isNotEmpty) currentProject = projects.first;
      current = _newSession(currentProject);
      await ChatSessionStore.upsert(current);
      sessions.add(current);
    }

    if (!mounted) return;
    setState(() {
      _sessions = sessions;
      _projects = projects;
      _session = current;
      _project = currentProject;
      _loading = false;
    });
  }

  ChatSession _newSession(WritingProject? project) {
    final now = DateTime.now();
    return ChatSession(
      id: newChatId('chat'),
      title: project == null ? '创作对话' : '关于《${project.title}》',
      projectId: project?.id,
      messages: [
        ChatMessage(
          id: newChatId('msg'),
          role: 'assistant',
          content: '我是 AI 创作台。顶部的小说标签用于切换/查看注入上下文，模式标签用于配置联网 AI。你可以让我做大纲、人物、世界观、续写、质检、拆章，也可以把输出保存到资料库。',
          createdAt: now,
        ),
      ],
      createdAt: now,
      updatedAt: now,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final session = _session;
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 创作台'),
        actions: [
          IconButton(
            tooltip: '切换对话',
            onPressed: _sessions.length <= 1 ? null : _showSessionPicker,
            icon: const Icon(Icons.forum_outlined),
          ),
          IconButton(
            tooltip: '绑定小说',
            onPressed: _showProjectPicker,
            icon: const Icon(Icons.auto_stories_outlined),
          ),
          IconButton.filledTonal(
            tooltip: '新对话',
            onPressed: _createNewSession,
            icon: const Icon(Icons.add_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      bottomNavigationBar: InkFlowBottomBar(settings: widget.settings, selectedIndex: 0),
      body: _loading || session == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
                  color: colors.surface,
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      ActionChip(
                        avatar: const Icon(Icons.auto_stories_rounded, size: 18),
                        label: Text(_project == null ? '选择小说上下文' : '《${_project!.title}》'),
                        onPressed: _showProjectPicker,
                      ),
                      if (_project != null)
                        ActionChip(
                          avatar: const Icon(Icons.fact_check_outlined, size: 18),
                          label: const Text('查看上下文'),
                          onPressed: _showProjectContext,
                        ),
                      ActionChip(
                        avatar: Icon(
                          widget.settings.hasAiApiKey
                              ? Icons.cloud_done_rounded
                              : Icons.offline_bolt_rounded,
                          size: 18,
                        ),
                        label: Text(
                          widget.settings.hasAiApiKey
                              ? '联网 AI：${widget.settings.aiModel}'
                              : '本地模板模式，点此配置 AI',
                        ),
                        onPressed: _openAiSettings,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    controller: _scrollController,
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
                    itemCount: session.messages.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final message = session.messages[index];
                      return _MessageBubble(
                        message: message,
                        onCopy: () => Clipboard.setData(ClipboardData(text: message.content)),
                        onSaveToDraft: message.isUser ? null : () => _saveAssistantMessage(message),
                      );
                    },
                  ),
                ),
                _QuickPrompts(onPick: (value) => _inputController.text = value),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _inputController,
                            minLines: 1,
                            maxLines: 5,
                            decoration: const InputDecoration(
                              hintText: '输入创作需求，例如：帮我拆这本书前三十章……',
                            ),
                            onSubmitted: (_) => _send(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton.filled(
                          onPressed: _sending ? null : _send,
                          icon: _sending
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.send_rounded),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _send() async {
    final text = _inputController.text.trim();
    final session = _session;
    if (text.isEmpty || session == null) return;
    _inputController.clear();
    final now = DateTime.now();
    final userMessage = ChatMessage(id: newChatId('msg'), role: 'user', content: text, createdAt: now);
    final nextSession = session.copyWith(messages: [...session.messages, userMessage], updatedAt: now);
    setState(() {
      _session = nextSession;
      _sending = true;
    });
    await ChatSessionStore.upsert(nextSession);
    _jumpToBottom();

    try {
      final history = nextSession.messages
          .map((item) => '${item.role == 'user' ? '用户' : '助手'}：${item.content}')
          .toList();
      final answer = await AiService.instance.sendChat(
        settings: widget.settings,
        message: text,
        project: _project,
        history: history,
      );
      final assistant = ChatMessage(
        id: newChatId('msg'),
        role: 'assistant',
        content: answer,
        createdAt: DateTime.now(),
      );
      final saved = nextSession.copyWith(
        title: _makeTitle(text),
        messages: [...nextSession.messages, assistant],
        updatedAt: DateTime.now(),
      );
      await ChatSessionStore.upsert(saved);
      if (!mounted) return;
      setState(() {
        _session = saved;
        _sessions = [saved, ..._sessions.where((item) => item.id != saved.id)];
      });
      _jumpToBottom();
    } catch (error) {
      final failed = ChatMessage(
        id: newChatId('msg'),
        role: 'assistant',
        content: '请求失败：$error',
        createdAt: DateTime.now(),
      );
      final saved = nextSession.copyWith(messages: [...nextSession.messages, failed], updatedAt: DateTime.now());
      await ChatSessionStore.upsert(saved);
      if (!mounted) return;
      setState(() => _session = saved);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  String _makeTitle(String text) {
    final compact = text.replaceAll(RegExp(r'\s+'), '');
    if (compact.length <= 14) return compact;
    return '${compact.substring(0, 14)}…';
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent + 240,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _saveAssistantMessage(ChatMessage message) async {
    final project = _project;
    if (project == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('请先绑定小说')));
      return;
    }
    final next = await StorageService.instance.appendMaterial(
      project: project,
      title: 'AI草稿',
      content: '\n## ${DateTime.now().toIso8601String()}\n\n${message.content}',
      tag: 'AI',
    );
    if (!mounted) return;
    setState(() => _project = next);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已保存到 小说资料/AI草稿.md')));
  }

  Future<void> _createNewSession() async {
    final session = _newSession(_project);
    await ChatSessionStore.upsert(session);
    if (!mounted) return;
    setState(() {
      _session = session;
      _sessions = [session, ..._sessions];
    });
  }

  Future<void> _showSessionPicker() async {
    final picked = await showModalBottomSheet<ChatSession>(
      context: context,
      showDragHandle: true,
      builder: (context) => ListView.separated(
        shrinkWrap: true,
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
        itemCount: _sessions.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final session = _sessions[index];
          return ListTile(
            title: Text(session.title),
            subtitle: Text('${session.messages.length} 条消息'),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline_rounded),
              onPressed: () async {
                await ChatSessionStore.delete(session.id);
                if (mounted) Navigator.pop(context);
                await _load();
              },
            ),
            onTap: () => Navigator.pop(context, session),
          );
        },
      ),
    );
    if (picked == null) return;
    setState(() => _session = picked);
  }

  Future<void> _showProjectPicker() async {
    final result = await showModalBottomSheet<_ProjectPickResult>(
      context: context,
      showDragHandle: true,
      builder: (context) => ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
        children: [
          ListTile(
            leading: const Icon(Icons.link_off_rounded),
            title: const Text('不绑定小说'),
            subtitle: const Text('只进行普通 AI 对话，不注入作品资料。'),
            onTap: () => Navigator.pop(context, const _ProjectPickResult.clear()),
          ),
          for (final project in _projects)
            ListTile(
              leading: const Icon(Icons.auto_stories_rounded),
              title: Text(project.title),
              subtitle: Text('${project.chapters.length} 章 · ${project.notes.length} 份资料'),
              selected: _project?.id == project.id,
              onTap: () => Navigator.pop(context, _ProjectPickResult.project(project)),
            ),
        ],
      ),
    );
    if (result == null) return;

    final picked = result.project;
    setState(() => _project = picked);
    final session = _session;
    if (session != null) {
      final next = session.copyWith(
        projectId: picked?.id,
        clearProjectId: picked == null,
        title: picked == null ? '创作对话' : '关于《${picked.title}》',
        updatedAt: DateTime.now(),
      );
      setState(() => _session = next);
      await ChatSessionStore.upsert(next);
    }
  }

  Future<void> _openAiSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SettingsScreen(settings: widget.settings)),
    );
    if (mounted) setState(() {});
  }

  Future<void> _showProjectContext() async {
    final project = _project;
    if (project == null) return;
    final notes = project.notes
        .take(12)
        .map((note) => '## ${note.title}\n${_clip(note.body, 360)}')
        .join('\n\n');
    final chapters = project.chapters
        .take(20)
        .map((chapter) => '- ${chapter.title}：${_clip(chapter.content, 220)}')
        .join('\n');
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.72,
          maxChildSize: 0.92,
          minChildSize: 0.38,
          builder: (context, controller) {
            return ListView(
              controller: controller,
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
              children: [
                Text(
                  '将注入 AI 的小说上下文',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 10),
                _ContextBlock(
                  title: '作品',
                  content: '《${project.title}》\n类型：${project.genre}\n简介：${project.description.isEmpty ? '无' : project.description}',
                ),
                _ContextBlock(title: '小说资料', content: notes.isEmpty ? '无' : notes),
                _ContextBlock(title: '章节节选', content: chapters.isEmpty ? '无' : chapters),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    _showProjectPicker();
                  },
                  icon: const Icon(Icons.swap_horiz_rounded),
                  label: const Text('更换绑定小说'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  String _clip(String text, int maxChars) {
    final value = text.trim();
    if (value.length <= maxChars) return value;
    return '${value.substring(0, maxChars)}…';
  }
}

class _ProjectPickResult {
  const _ProjectPickResult.project(this.project);
  const _ProjectPickResult.clear() : project = null;

  final WritingProject? project;
}

class _ContextBlock extends StatelessWidget {
  const _ContextBlock({required this.title, required this.content});

  final String title;
  final String content;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest.withOpacity(0.48),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          SelectableText(content.isEmpty ? '无' : content),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message, required this.onCopy, this.onSaveToDraft});

  final ChatMessage message;
  final VoidCallback onCopy;
  final VoidCallback? onSaveToDraft;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isUser = message.isUser;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 10, 8),
          decoration: BoxDecoration(
            color: isUser ? colors.primaryContainer : colors.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SelectableText(
                message.content,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.55),
              ),
              const SizedBox(height: 4),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextButton.icon(
                    onPressed: onCopy,
                    icon: const Icon(Icons.copy_rounded, size: 16),
                    label: const Text('复制'),
                  ),
                  if (onSaveToDraft != null)
                    TextButton.icon(
                      onPressed: onSaveToDraft,
                      icon: const Icon(Icons.save_alt_rounded, size: 16),
                      label: const Text('存草稿'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickPrompts extends StatelessWidget {
  const _QuickPrompts({required this.onPick});

  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    const prompts = [
      '帮我把这本小说拆成30章，每章给目标、冲突和结尾钩子',
      '根据当前设定生成主角、反派和三名关键配角',
      '帮我设计一个爽点更强的开篇前三章',
      '把当前世界观补全规则、代价和漏洞',
    ];
    return SizedBox(
      height: 46,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        scrollDirection: Axis.horizontal,
        itemCount: prompts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) => ActionChip(
          label: Text(prompts[index]),
          onPressed: () => onPick(prompts[index]),
        ),
      ),
    );
  }
}
