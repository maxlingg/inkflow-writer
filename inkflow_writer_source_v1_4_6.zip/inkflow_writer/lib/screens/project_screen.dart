import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../widgets/app_bottom_bar.dart';
import 'book_analysis_screen.dart';
import 'chat_screen.dart';
import 'creative_flow_screen.dart';
import 'editor_screen.dart';
import 'note_editor_screen.dart';
import 'long_form_mode_screen.dart';
import 'project_folder_screen.dart';

class ProjectScreen extends StatefulWidget {
  const ProjectScreen({super.key, required this.project, required this.settings});

  final WritingProject project;
  final AppSettings settings;

  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  late WritingProject _project;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _refresh();
  }

  Future<void> _refresh() async {
    final projects = await StorageService.instance.loadProjects();
    final fresh = projects.where((item) => item.id == _project.id).toList();
    if (fresh.isEmpty || !mounted) return;
    setState(() => _project = fresh.first);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 72,
        leading: Padding(
          padding: const EdgeInsets.only(left: 18, top: 6, bottom: 6),
          child: IconButton.filledTonal(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        title: Text(_project.title),
        titleTextStyle: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w900,
              color: colors.onSurface,
            ),
        actions: [
          IconButton(
            tooltip: '拆书分析（爆款拆解）',
            onPressed: _openBookAnalysis,
            icon: const Icon(Icons.local_fire_department_rounded),
          ),
          IconButton(
            tooltip: 'AI 创作台',
            onPressed: _openChat,
            icon: const Icon(Icons.auto_awesome_rounded),
          ),
          IconButton.filledTonal(
            tooltip: '新增',
            onPressed: _showAddSheet,
            icon: const Icon(Icons.add_rounded),
          ),
          PopupMenuButton<String>(
            tooltip: '更多',
            onSelected: (value) async {
              if (value == 'flow') await _openFlow();
              if (value == 'book_analysis') await _openBookAnalysis();
              if (value == 'longform') await _openLongForm();
              if (value == 'refresh') await _refresh();
              if (value == 'paste') await _createChapterFromClipboard();
              if (value == 'import') await _importFileAsChapter();
              if (value == 'txt') await _export(ExportFormat.txt);
              if (value == 'md') await _export(ExportFormat.markdown);
              if (value == 'docx') await _export(ExportFormat.docx);
              if (value == 'path') await _showProjectPath();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'flow', child: Text('创作流程')),
              PopupMenuItem(value: 'book_analysis', child: Text('拆书分析（爆款拆解）')),
              PopupMenuItem(value: 'longform', child: Text('AI 长篇创作模式')),
              PopupMenuItem(value: 'refresh', child: Text('重新读取本地文件')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'import', child: Text('导入 TXT / MD / DOCX')),
              PopupMenuItem(value: 'paste', child: Text('从剪贴板导入章节')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'path', child: Text('查看本地路径')),
              PopupMenuItem(value: 'docx', child: Text('导出 Word DOCX')),
              PopupMenuItem(value: 'md', child: Text('导出 Markdown')),
              PopupMenuItem(value: 'txt', child: Text('导出 TXT')),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      bottomNavigationBar: InkFlowBottomBar(settings: widget.settings),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 24),
          children: [
            _ProjectSummary(project: _project, onOpenFlow: _openFlow, onOpenAi: _openChat, onOpenLongForm: _openLongForm),
            const SizedBox(height: 18),
            _FolderRow(
              title: '小说资料',
              subtitle: '${_project.notes.length} 个 Markdown 文件 · 世界观/人物库/大纲/摘要',
              icon: Icons.folder_rounded,
              onTap: () => _openFolder(ProjectFolderType.materials),
            ),
            const SizedBox(height: 18),
            _FolderRow(
              title: '章节内容',
              subtitle: '${_project.chapters.length} 个 Markdown 文件 · 正文自动保存',
              icon: Icons.folder_rounded,
              onTap: () => _openFolder(ProjectFolderType.chapters),
            ),
          ],
        ),
      ),
      backgroundColor: colors.surfaceContainerLowest,
    );
  }

  Future<void> _openFolder(ProjectFolderType type) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProjectFolderScreen(project: _project, type: type, settings: widget.settings),
      ),
    );
    await _refresh();
  }

  Future<void> _openBookAnalysis() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => BookAnalysisScreen(settings: widget.settings, initialProject: _project)),
    );
    await _refresh();
  }

  Future<void> _openChat() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ChatScreen(settings: widget.settings, initialProject: _project)),
    );
    await _refresh();
  }

  Future<void> _openFlow() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => CreativeFlowScreen(project: _project, settings: widget.settings)),
    );
    await _refresh();
  }

  Future<void> _openLongForm() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => LongFormModeScreen(project: _project, settings: widget.settings)),
    );
    await _refresh();
  }

  Future<void> _showAddSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
          children: [
            ListTile(
              leading: const Icon(Icons.note_add_rounded),
              title: const Text('新建章节文件'),
              subtitle: const Text('保存到 章节内容 文件夹'),
              onTap: () {
                Navigator.pop(context);
                _createChapter(openAfterCreate: true);
              },
            ),
            ListTile(
              leading: const Icon(Icons.description_rounded),
              title: const Text('新建资料文件'),
              subtitle: const Text('保存到 小说资料 文件夹'),
              onTap: () {
                Navigator.pop(context);
                _createMaterial(openAfterCreate: true);
              },
            ),
            ListTile(
              leading: const Icon(Icons.upload_file_rounded),
              title: const Text('导入文件为章节'),
              subtitle: const Text('支持 TXT / MD / DOCX'),
              onTap: () {
                Navigator.pop(context);
                _importFileAsChapter();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _createChapter({bool openAfterCreate = false}) async {
    final controller = TextEditingController(text: '第${_project.chapters.length + 1}章');
    final title = await _askTitle('新建章节', '章节文件名', controller);
    if (title == null || title.isEmpty) return;

    final now = DateTime.now();
    final chapter = Chapter(
      id: newEntityId('chapter'),
      title: _stripKnownExtension(title),
      content: '',
      createdAt: now,
      updatedAt: now,
    );
    final next = _project.copyWith(chapters: [..._project.chapters, chapter], updatedAt: now);
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);

    if (openAfterCreate) {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => EditorScreen(project: next, chapterId: chapter.id, settings: widget.settings)),
      );
      await _refresh();
    }
  }

  Future<void> _createMaterial({bool openAfterCreate = false}) async {
    final controller = TextEditingController(text: '新资料');
    final title = await _askTitle('新建资料', '资料文件名', controller);
    if (title == null || title.isEmpty) return;

    final now = DateTime.now();
    final note = ProjectNote(
      id: newEntityId('note'),
      title: _stripKnownExtension(title),
      body: '',
      tag: '资料',
      createdAt: now,
      updatedAt: now,
    );
    final next = _project.copyWith(notes: [..._project.notes, note], updatedAt: now);
    await StorageService.instance.upsertProject(next);
    if (!mounted) return;
    setState(() => _project = next);

    if (openAfterCreate) {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => NoteEditorScreen(project: next, noteId: note.id, settings: widget.settings)),
      );
      await _refresh();
    }
  }

  Future<void> _importFileAsChapter() async {
    try {
      final picked = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['txt', 'md', 'docx'],
        allowMultiple: false,
      );
      final path = picked?.files.single.path;
      if (path == null) return;
      final next = await StorageService.instance.importFileAsChapter(_project, path);
      if (!mounted) return;
      setState(() => _project = next);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已导入为章节')));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('导入失败：$error')));
    }
  }

  Future<void> _createChapterFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim();
    if (text == null || text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('剪贴板里没有可导入的文本')));
      return;
    }

    final controller = TextEditingController(text: '导入章节${_project.chapters.length + 1}');
    final title = await _askTitle('从剪贴板导入章节', '章节文件名', controller);
    if (title == null || title.isEmpty) return;

    final next = await StorageService.instance.addTextAsChapter(
      project: _project,
      title: title,
      content: text,
    );
    if (!mounted) return;
    setState(() => _project = next);
  }

  Future<String?> _askTitle(String title, String label, TextEditingController controller) {
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(labelText: label)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('确定')),
        ],
      ),
    );
  }

  Future<void> _export(ExportFormat format) async {
    await _refresh();
    try {
      final path = await StorageService.instance.exportProject(_project, format: format);
      await Share.shareXFiles([XFile(path)], text: '「${_project.title}」已导出 ${format.label}');
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('导出失败：$error')));
    }
  }

  Future<void> _showProjectPath() async {
    final path = await StorageService.instance.projectDirectoryPath(_project);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('小说本地路径'),
        content: SelectableText(path),
        actions: [
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: path));
              if (context.mounted) Navigator.pop(context);
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('路径已复制')));
            },
            child: const Text('复制路径'),
          ),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('知道了')),
        ],
      ),
    );
  }

  String _stripKnownExtension(String title) {
    var trimmed = title.trim();
    for (final ext in const ['.md', '.txt', '.docx']) {
      if (trimmed.toLowerCase().endsWith(ext)) trimmed = trimmed.substring(0, trimmed.length - ext.length);
    }
    return trimmed;
  }
}

class _ProjectSummary extends StatelessWidget {
  const _ProjectSummary({required this.project, required this.onOpenFlow, required this.onOpenAi, required this.onOpenLongForm});

  final WritingProject project;
  final VoidCallback onOpenFlow;
  final VoidCallback onOpenAi;
  final VoidCallback onOpenLongForm;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: colors.primaryContainer.withOpacity(0.45),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('创作工作台', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(label: Text('${project.chapters.length} 章')),
                Chip(label: Text('${project.notes.length} 份资料')),
                Chip(label: Text('${project.totalCharacters} 字符')),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton.tonal(
                    onPressed: onOpenFlow,
                    child: const Text('流程'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: onOpenAi,
                    icon: const Icon(Icons.auto_awesome_rounded),
                    label: const Text('AI'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onOpenLongForm,
                    icon: const Icon(Icons.psychology_rounded),
                    label: const Text('长篇'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _FolderRow extends StatelessWidget {
  const _FolderRow({required this.title, required this.subtitle, required this.icon, required this.onTap});

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: colors.primaryContainer.withOpacity(0.52),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(icon, color: colors.primary, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900, color: colors.onSurface),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: colors.onSurfaceVariant, size: 30),
            ],
          ),
        ),
      ),
    );
  }
}
