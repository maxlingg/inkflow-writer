# v1.4.4 构建修复

- 修复 `AiService._localDistillFallback` 缺失导致的 analyze 失败。
- 打包脚本删除 Flutter 默认 `test/` 目录，避免默认测试引用旧包名导致 analyze 失败。
- 版本号更新为 `1.4.4+19`。
