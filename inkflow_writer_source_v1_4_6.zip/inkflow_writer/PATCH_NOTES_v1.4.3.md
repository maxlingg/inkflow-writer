# v1.4.3 Build Hotfix

- 修复 TXT/MD GB18030 解码函数参数类型，避免 Flutter analyze/build 因 `List<int>` 与 `Uint8List` 类型不匹配失败。
- 更新版本号为 `1.4.3+18`。
- 打包脚本优先识别 `inkflow_writer_source_v1_4_3.zip`。
