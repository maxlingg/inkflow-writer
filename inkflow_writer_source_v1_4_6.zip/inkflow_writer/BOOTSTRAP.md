# 手机云端构建步骤 v0.8

1. 删除 GitHub 仓库里的旧 `inkflow_writer_source_*.zip`。
2. 上传 `inkflow_writer_source_v0_8.zip`。
3. 打开 `.github/workflows/build-apk.yml`。
4. 用 `build-apk-v0.8.yml` 的内容替换旧内容。
5. Commit changes。
6. 打开 Actions，运行 Build Android APK。
7. 下载 artifact：`inkflow-writer-apk-v0-8`。
8. 解压后安装 `app-release.apk`。

## 测试重点

- AI 创作台顶部「小说」标签是否能切换/解绑。
- 「查看上下文」是否能显示资料和章节节选。
- 「本地模板模式」是否能进入 AI 服务设置。
- 设置页 Skill 条目是否能点开。
- 自定义 Skill 是否能点开修改。
- 内置 Skill 是否能复制并修改成自定义 Skill。
