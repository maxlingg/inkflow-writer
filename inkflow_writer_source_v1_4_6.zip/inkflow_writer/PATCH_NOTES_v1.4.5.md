# InkFlow Writer v1.4.5

- Exclude generated Flutter template tests from analyzer.
- Workflow removes `test/` defensively and analyzes `lib/` only.
- Version bumped to `1.4.5+20`.
