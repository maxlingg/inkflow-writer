import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/writing_project.dart';
import '../services/app_settings.dart';
import '../services/storage_service.dart';
import '../utils/text_stats.dart';

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({
    super.key,
    required this.project,
    required this.noteId,
    required this.settings,
  });

  final WritingProject project;
  final String noteId;
  final AppSettings settings;

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late WritingProject _project;
  late ProjectNote _note;
  late TextEditingController _titleController;
  late TextEditingController _bodyController;
  Timer? _saveTimer;
  bool _saving = false;
  bool _saveAgain = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _note = _project.notes.firstWhere((item) => item.id == widget.noteId);
    _titleController = TextEditingController(text: _note.title);
    _bodyController = TextEditingController(text: _note.body);
    _titleController.addListener(_scheduleSave);
    _bodyController.addListener(_scheduleSave);
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _titleController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final body = _bodyController.text;

    return WillPopScope(
      onWillPop: () async {
        await _saveNow();
        return true;
      },
      child: AnimatedBuilder(
        animation: widget.settings,
        builder: (context, _) {
          return Scaffold(
            appBar: AppBar(
              leadingWidth: 72,
              leading: Padding(
                padding: const EdgeInsets.only(left: 18, top: 6, bottom: 6),
                child: IconButton.filledTonal(
                  onPressed: () async {
                    await _saveNow();
                    if (context.mounted) Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
              ),
              title: Text(_saving ? '正在保存…' : _dirty ? '未保存更改' : '已自动保存'),
              actions: [
                IconButton(
                  tooltip: '复制全文',
                  onPressed: _copyNote,
                  icon: const Icon(Icons.copy_rounded),
                ),
                IconButton(
                  tooltip: '立即保存',
                  onPressed: _saveNow,
                  icon: const Icon(Icons.save_rounded),
                ),
                const SizedBox(width: 8),
              ],
            ),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                  child: TextField(
                    controller: _titleController,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                    decoration: const InputDecoration(
                      hintText: '资料标题',
                      suffixText: '.md',
                      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
                    child: TextField(
                      controller: _bodyController,
                      expands: true,
                      maxLines: null,
                      minLines: null,
                      textAlignVertical: TextAlignVertical.top,
                      keyboardType: TextInputType.multiline,
                      style: TextStyle(
                        fontSize: widget.settings.editorFontSize,
                        height: 1.75,
                      ),
                      decoration: InputDecoration(
                        hintText: '记录人物、设定、世界观、大纲、伏笔……',
                        filled: true,
                        fillColor: colors.surfaceContainerHighest.withOpacity(0.34),
                        contentPadding: const EdgeInsets.all(16),
                      ),
                    ),
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: colors.outlineVariant.withOpacity(0.5)),
                      ),
                    ),
                    child: Row(
                      children: [
                        _EditorStat(label: '字符', value: '${TextStats.characters(body)}'),
                        const SizedBox(width: 8),
                        _EditorStat(label: '词/字', value: '${TextStats.words(body)}'),
                        const Spacer(),
                        FilledButton.tonalIcon(
                          onPressed: _saveNow,
                          icon: const Icon(Icons.save_rounded, size: 18),
                          label: const Text('保存'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _scheduleSave() {
    if (!_dirty && mounted) setState(() => _dirty = true);
    if (_saving) {
      _saveAgain = true;
      return;
    }
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 650), _saveNow);
  }

  Future<void> _saveNow() async {
    _saveTimer?.cancel();
    if (_saving) {
      _saveAgain = true;
      return;
    }
    if (mounted) setState(() => _saving = true);

    try {
      do {
        _saveAgain = false;
        final now = DateTime.now();
        final nextNote = _note.copyWith(
          title: _stripMarkdownExtension(_titleController.text).isEmpty
              ? '未命名资料'
              : _stripMarkdownExtension(_titleController.text),
          body: _bodyController.text,
          tag: '资料',
          updatedAt: now,
        );
        final savedProject = await StorageService.instance.upsertMaterialNote(
          project: _project,
          note: nextNote,
        );
        _note = nextNote;
        _project = savedProject;
      } while (_saveAgain);
    } finally {
      if (!mounted) return;
      setState(() {
        final currentTitle = _stripMarkdownExtension(_titleController.text).isEmpty
            ? '未命名资料'
            : _stripMarkdownExtension(_titleController.text);
        _saving = false;
        _dirty = currentTitle != _note.title ||
            _bodyController.text != _note.body;
      });
    }
  }

  Future<void> _copyNote() async {
    final title = _stripMarkdownExtension(_titleController.text).trim();
    final body = _bodyController.text;
    await Clipboard.setData(ClipboardData(text: '# $title\n\n$body'));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('资料内容已复制')),
    );
  }

  String _stripMarkdownExtension(String title) {
    final trimmed = title.trim();
    return trimmed.toLowerCase().endsWith('.md')
        ? trimmed.substring(0, trimmed.length - 3)
        : trimmed;
  }
}

class _EditorStat extends StatelessWidget {
  const _EditorStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text('$label $value', style: Theme.of(context).textTheme.labelMedium),
    );
  }
}
